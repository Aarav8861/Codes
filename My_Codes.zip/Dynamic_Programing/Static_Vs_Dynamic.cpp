#include <bits/stdc++.h>
using namespace std;

int main()
{
    // static
    // Allocation + Deallocation = Compiler
    int b[100] = {0};
    cout << sizeof(b)<< endl; // size of the entire array
    cout << b << endl; // Address stored at the symbol table
    // Here b can't be overwritten , b is a part of read only memory


    // Dynamic memory allocation (Run Time)
    // Can reuse after deleting
    // Deallocated by the user itself
    int n;
    cin>>n;
       int *a =                    new int[n]{0}; // To initialize at run time.
    // stored in static         // stored in heap Address is returned
    cout << sizeof(a) << endl; // From static 
    cout << a << endl; // From Heap
    // variable a that is created in the static memory can be overwritten

    // a = new char[30] :- should do not as we will loose the previous allocated address -> memory wastage.

    // No change
    for(int i = 0 ; i<n;i++)
    {
        cin >> i[a] ;
        cout << a[i] << " ";
    }

    // Free up space
    delete [] a;
    return 0;
}