#include <iostream>
using namespace std;
void increment(int &i)
{
    i++;
}
int main()
{
    int i=10;
    increment(i);
    cout<<i<<endl;
}