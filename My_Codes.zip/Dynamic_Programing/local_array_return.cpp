#include <bits/stdc++.h>
using namespace std;
// static
/*int *fun()
{
    int a[] ={1,2,3,4,5};
    cout << a << endl;
    cout << a[0] << endl;

    // We should never return a local variable as the memory in static allocation is deallocated once the function call is over.
    return a;
}

int main()
{
    int *b = fun();
    cout << b << endl;
    cout << b[0] << endl;// may return garbage or segementation fault as the array a is lost.

    return 0;
}*/
// Dynamic
int *fun()
{
    int *a = new int[5];
    a[0] = 11;
    a[1] = 2;
    cout << a << endl;
    cout << a[0] << endl;
    return a;
}

int main()
{
    int *b = fun();
    cout << b << endl;
    cout << b[0] << endl;
    cout << b[1] << endl;

    delete[] b; // deletes the Heap memory

    return 0; // will delete the local variable b after program ends
}