#include <iostream>
using namespace std;

int length(char input[])
{
    int count = 0, i = 0;
    while (input[i] != '\0')
    {
        count++;
        i++;
    }
    return count;
}

void reversewords(char input[], int i, int j)
{
    int count = length(input);
    while (i < j)
    {
        char temp = input[i];
        input[i] = input[j];
        input[j] = temp;
        i++;
        j--;
    }
}
void reverseStringWordWise(char input[])
{
    // Write your code here
    int count = length(input);
    int k = 0, j = count - 1;
    while (k < j)
    {
        char temp = input[k];
        input[k] = input[j];
        input[j] = temp;
        k++;
        j--;
    }
    int start = 0, end = 0, m = 0;
    for (int i = 0; i < count; i++)
    {
        if (input[i] == ' ')
        {
            end = i - 1;
            reversewords(input, start, end);
            start = i + 1;
            end = i + 1;
        }
        m = i;
    }

    end = m;
    reversewords(input, start, end);
}
int main()
{
    char input[1000];
    cin.getline(input, 1000);
    reverseStringWordWise(input);
    cout << input << endl;
}