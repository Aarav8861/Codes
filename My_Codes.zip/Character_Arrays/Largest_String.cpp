#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int max_length = INT_MIN;
    char largest[1000];
    cin.get(); // as first string is a null string so to take n strings as an input and not n-1 we consume the null string using cin.get()
    for (int i = 0; i < n; i++)
    {
        char a[1000];
        cin.getline(a, 1000);
        int current = strlen(a);
        if (current > max_length)
        {
            max_length = current;
            strcpy(largest, a);
        }
    }
    cout << largest << " and " << max_length << endl;
}