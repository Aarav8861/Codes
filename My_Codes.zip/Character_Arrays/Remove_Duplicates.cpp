#include <bits/stdc++.h>
using namespace std;

void remove(char arr[])
{
    int i = 0;
    int j = 1;
    int n = strlen(arr);
    if (n == 0 || n == 1)
    {
        return;
    }
    while (j != n)
    {
        if (arr[i] != arr[j])
        {
            i++;
            swap(arr[i], arr[j]);
        }
        j++;
    }
    arr[i + 1] = '\0';
}

int main()
{
    char a[1000];
    cin.getline(a, 1000);
    remove(a);
    cout << a << endl;
}
