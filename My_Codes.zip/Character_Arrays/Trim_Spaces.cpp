#include <iostream>
#include <cstring>
using namespace std;

void trimSpaces(char input[])
{
    // Write your code here
    int count = 0, i = 0;
    while (input[i] != 0)
    {
        count++;
        i++;
    }
    for (int i = 0; i < count - 1; i++)
    {
        if (input[i] == ' ')
        {
            for (int k = i; k < count - 1; k++)
            {
                input[k] = input[k + 1];
            }
            count--;
            input[count] = '\0';
        }
    }
}

int main()
{
    char input[1000000];
    cin.getline(input, 1000000);
    trimSpaces(input);
    cout << input << endl;
}
