#include <iostream>
#include <deque>
using namespace std;
int main()
{
    int n;
    cin >> n;
    int arr[100000];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    int k;
    cin >> k;

    deque<int> q;
    int i;
    for (i = 0; i < k; i++)
    {
        while (!q.empty() && arr[i] > arr[q.back()])
        {
            q.pop_back();
        }
        q.push_back(i);
    }
    // Processing the remaining elements
    for (; i < n; i++)
    {
        cout << arr[q.front()] << " ";
        // 1. Remove the elements which are not the part of the sliding window(Contraction)
        while (!q.empty() && q.front() <= i - k)
        {
            q.pop_front();
        }
        // 2. Remove the elements which are not useful and are not in the window.
        while (!q.empty() && arr[i] >= arr[q.back()])
        {
            q.pop_back();
        }

        // 3. Add the new elements(Expansion)
        q.push_back(i);
    }
    cout << arr[q.front()] << endl;
}