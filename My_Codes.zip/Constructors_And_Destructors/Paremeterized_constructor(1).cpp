#include <iostream>
using namespace std;

class complex
{
    int a;
    int b;
    public :
    complex (int,int);
    void print(void)
    {
        cout<<a<<"+"<<b<<"i"<<endl;
    }
};
complex::complex(int x,int y)  // has no return type
{
    a=x;
    b=y;    
}

int main()
{
    complex c1(5,6);
    c1.print();

    complex c2=complex(4,3);
    c2.print();

    return 0;
}