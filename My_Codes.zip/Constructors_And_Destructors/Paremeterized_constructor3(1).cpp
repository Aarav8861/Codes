#include <iostream>
#include <math.h>
using namespace std;

class points
{
    int x;
    int y;

public:
    points();
    points(int a, int b)
    {
        x = a;
        y = b;
    }

    int distance(points c, points c3)
    {
        return sqrt(((c.x - c3.x) * (c.x - c3.x)) + ((c.y - c3.y) * (c.y - c3.y)));
    }
};

int main()
{
    int x;
    points c(1, 1);
    points c3(1, 31);
    points c2;
    x = c2.distance(c, c3);
    cout << "The value is" << x;
    return 0;
}
