#include <iostream>
#include <string>
using namespace std;


class Visitor
{
private:
    string roll_no;
    string name;
    string department;
    float cgpa;
    int no_of_arrays;

public:
    friend class staff;
    Visitor();
    Visitor(string, string, string, float);
};

Visitor::Visitor(string r, string n, string d, float c)
{
    this->roll_no = r;
    this->name = n;
    this->department = d;
    this->cgpa = c;
}
class staff
{
    string department;

public:
    staff(string d)
    {
        this->department = d;
        cout << department;
    }   
    void displaystudentdetails(void);
};
void staff::displaystudentdetails()
{
        cout<<roll_no;
        cout<<name;
        cout<<department;
        cout<<cgpa;
}

int main()
{
    int n;
    string r, n1, d;
    float c;
    cout << "Enter the number of students";
    cin >> n;
    cout << "Enter the Roll no\n";
    cin >> r;
    cout << "Enter the name\n";
    cin >> n1;
    cout << "Enter the department\n";
    cin >> d;
    cout << "Enter the cgpa\n";
    cin >> c;

    Visitor v[n];
    for (int i = 0; i < n; i++)
    {
        v[i] = Visitor(r, n1, d, c);
    }

    staff s(d);
    for (int i = 0; i < n; i++)
    {
        v[i].displaystudentdetails();
    }
}