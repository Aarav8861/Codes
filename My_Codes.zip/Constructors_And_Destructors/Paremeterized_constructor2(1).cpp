#include <iostream>
using namespace std;

class point {

    int x;
    int y;
    public:
    point(int a,int b)
    {
        x=a;
        y=b;
    }

    void print()
    {
        cout<<"("<<x<<","<<y<<")"<<endl;
    }
};

int main()
{
    point a(3,2);
    a.print();

    point b(6,9);
    b.print();

    return 0;
}