#include <iostream>
using namespace std;

class num
{
 static int count;
    public:
    num()
    {
        count++;
        cout<<"The constructor is called for object number\t"<<count<<endl;
    }
    ~num()// Destructor never takes an argument nor does it return any value ...
    {
        cout<<"The destructor is called for object number\t"<<count<<endl;
        count--;
    }
};
int num::count;

int main()
{
    cout<<"Welcome to main"<<endl;
    cout<<"Creating our first object"<<endl;
    num n1;
    {
        cout<<"Entering the block for first object"<<endl;
        num n2,n3;
        cout<<"Exiting the other two objects"<<endl;
    }
    cout<<"Back to main function"<<endl;
    return 0;
}