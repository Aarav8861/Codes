#include<iostream> 
using namespace std; 
class student{ 
 
    //int name;  //  bytes 
    //int rollNo;   // 4 bytes 
    //double averageMarks; // 8 bytes 
 
 
}; 
 
int main(){ 
 
    //student std1, std2; 
    cout << sizeof(student) << endl; // combination of string+int+double  
    // when class is empty default value for sizeof() is = 1
    /*cout << sizeof(string) << endl; 
    cout << sizeof(int)  << endl; 
    cout << sizeof(double) << endl;*/ 
    return 0; 
}