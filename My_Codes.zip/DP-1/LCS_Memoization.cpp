#include <bits/stdc++.h>
using namespace std;

int LCS_helper(string s1, string s2, int **output)
{
    int m = s1.size();
    int n = s2.size();
    if (output[m][n] != 0)
    {
        return output[m][n];
    }

    if (s1.size() == 0 || s2.size() == 0)
    {
        return 0;
    }
    int ans;
    if (s1[0] == s2[0])
    {
        ans = 1 + LCS_helper(s1.substr(1), s2.substr(1), output);
    }
    else
    {
        int a = LCS_helper(s1.substr(1), s2, output);
        int b = LCS_helper(s1, s2.substr(1), output);
        int c = LCS_helper(s1.substr(1), s2.substr(1), output); // No need to write this step as the recursion will handle it in a and b
        ans = max(a, max(b, c));
    }
    output[m][n] = ans;
    return ans;
}
int LCS(string s1, string s2)
{
    int m = s1.size();
    int n = s2.size();
    int **output = new int *[m + 1];
    for (int i = 0; i < m + 1; i++)
    {
        output[i] = new int[n + 1];
        for (int j = 0; j < n + 1; j++)
        {
            output[i][j] = 0;
        }
    }
    return LCS_helper(s1, s2, output);
}

int main()
{
    string s1, s2;
    cin >> s1;
    cin >> s2;
    cout << LCS(s1, s2) << endl;
}