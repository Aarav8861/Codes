#include <iostream>
using namespace std;
int fibonacci(int n, int *arr)
{
    if (n == 1 || n == 0)
    {
        return n;
    }

    if (arr[n] != 0)
    {
        return arr[n];
    }
    int a = fibonacci(n - 1, arr) + fibonacci(n - 2, arr);
    arr[n] = a;
    return a;
}

int fib_helper(int n)
{
    int *arr = new int[n + 1];
    for (int i = 0; i <= n; i++)
    {
        arr[i] = 0;
    }
    return fibonacci(n, arr);
}

int main()
{
    int n;
    cin >> n;
    cout << fib_helper(n) << endl;
}