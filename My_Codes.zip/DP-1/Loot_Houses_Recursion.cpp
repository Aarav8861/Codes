#include <iostream>
using namespace std;
int maxMoneyLootedHelper(int *arr, int start, int n)
{
    if (start >= n)
    {
        return 0;
    }
    return max(maxMoneyLootedHelper(arr, start + 1, n), arr[start] + maxMoneyLootedHelper(arr, start + 2, n));
}
int maxMoneyLooted(int *arr, int n)
{
    // Write your code here
    return maxMoneyLootedHelper(arr, 0, n);
}

int main()
{
    int n;
    cin >> n;
    int *arr = new int[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }

    cout << maxMoneyLooted(arr, n);

    delete[] arr;
}