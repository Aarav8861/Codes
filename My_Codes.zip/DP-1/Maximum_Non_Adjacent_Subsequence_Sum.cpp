// Recursion
int solve(vector<int> &nums, int index)
{
    if (index == 0)
    {
        return nums[index];
    }
    if (index < 0)
        return 0;

    int pick = solve(nums, index - 2) + nums[index];
    int notpick = solve(nums, index - 1);
    return max(pick, notpick);
}
int maximumNonAdjacentSum(vector<int> &nums)
{
    // Write your code here.
    int index = nums.size() - 1;
    return solve(nums, index);
}
// Memosization
int solve(vector<int> &nums, int index, vector<int> &dp)
{
    if (index == 0)
    {
        return nums[index];
    }
    if (index < 0)
        return 0;
    if (dp[index] != -1)
    {
        return dp[index];
    }
    int pick = solve(nums, index - 2, dp) + nums[index];
    int notpick = solve(nums, index - 1, dp);
    dp[index] = max(pick, notpick);
    return dp[index];
}
int maximumNonAdjacentSum(vector<int> &nums)
{
    // Write your code here.
    vector<int> dp(nums.size(), -1);
    int index = nums.size() - 1;
    return solve(nums, index, dp);
}
// Tabulation
int maximumNonAdjacentSum(vector<int> &nums)
{
    // Write your code here.
    int n = nums.size();
    if (n == 1)
    {
        return nums[0];
    }
    vector<int> dp(n);
    dp[0] = 0;
    dp[1] = nums[0];
    for (int i = 2; i <= n; i++)
    {
        dp[i] = max(dp[i - 1] + 0, dp[i - 2] + nums[i - 1]);
    }
    return dp[n];
}
// Space Optimization
int maximumNonAdjacentSum(vector<int> &nums)
{
    // Write your code here.
    int n = nums.size();
    if (n == 1)
    {
        return nums[0];
    }
    vector<int> dp(n);
    int prev1 = 0;
    int prev2 = nums[0];
    for (int i = 2; i <= n; i++)
    {
        int curr = max(prev2 + 0, prev1 + nums[i - 1]);
        prev1 = prev2;
        prev2 = curr;
    }
    return prev2;
}