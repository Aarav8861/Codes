#include <bits/stdc++.h>
using namespace std;

int min_count(int n)
{
    if (n == 1)
    {
        return 1;
    }
    int min = INT_MAX;
    for (int i = 1; i < sqrt(n); i++)
    {
        int x = min_count(n - pow(i, 2)) + pow(i,2);
        if (x < min)
        {
            min = x;
        }
    }
    return min;
}

int main()
{
    int n;
    cin >> n;
    cout << min_count(n) << endl;
}