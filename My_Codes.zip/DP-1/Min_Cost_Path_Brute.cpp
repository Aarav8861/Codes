#include <bits/stdc++.h>
using namespace std;
int minCostPathHelper(int **input, int s, int e, int m, int n)
{
    if (s == m - 1 && e == n - 1)
    {
        return input[s][e];
    }
    int x, y, z;
    x = y = z = INT_MAX;
    if (s < m - 1)
    {
        x = minCostPathHelper(input, s + 1, e, m, n);
    }
    if (e < n - 1)
    {
        z = minCostPathHelper(input, s, e + 1, m, n);
    }
    if (s < m - 1 && e < n - 1)
    {
        y = minCostPathHelper(input, s + 1, e + 1, m, n);
    }

    int small = min(x, min(y, z));
    return small + input[s][e];
}

int minCostPath(int **input, int m, int n)
{
    return minCostPathHelper(input, 0, 0, m, n);
}

int main()
{
    int **arr, n, m;
    cin >> n >> m;
    arr = new int *[n];
    for (int i = 0; i < n; i++)
    {
        arr[i] = new int[m];
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> arr[i][j];
        }
    }
    cout << minCostPath(arr, n, m) << endl;
}