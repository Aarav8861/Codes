int frogJump(int n, vector<int> &heights, int k)
{
    // Write your code here.
    vector<int> dp(n + 1, INT_MAX);
    dp[0] = 0;
    dp[1] = 0;
    dp[2] = abs(heights[1] - heights[0]);
    for (int i = 3; i <= n; i++)
    {
        for (int j = 1; j <= k; j++)
        {
            if (dp[i - j] != INT_MAX)
            {
                dp[i] = min(dp[i], dp[i - j] + abs(heights[i - 1] - heights[i - j - 1]));
            }
        }
    }
    return dp[n];
}

template <typename T>
void pop_front(std::vector<T> &v)
{
    if (v.size() > 0)
    {
        v.front() = std::move(v.back());
        v.pop_back();
    }
}
int frogJump(int n, vector<int> &heights)
{
    // Write your code here.
    vector<int> dp(k, INT_MAX);
    dp[0] = 0;
    dp[1] = 0;
    dp[2] = abs(heights[1] - heights[0]);
    for (int i = 3; i <= n; i++)
    {
        for (int j = 1; j <= k; j++)
        {
            if (dp[i - j] != INT_MAX)
            {
                dp[i] = min(dp[i], dp[i - j] + abs(heights[i - 1] - heights[i - j - 1]));
                pop_front(dp);
            }
        }
    }
    return dp[n];
}

// Space optimazation
template <typename T>
void pop_front(std::vector<T> &v)
{
    if (v.size() > 0)
    {
        v.front() = std::move(v.back());
        v.pop_back();
    }
}
int frogJump(int n, vector<int> &heights)
{
    // Write your code here.
    vector<int> dp(2, INT_MAX);
    dp[0] = 0;
    dp[1] = abs(heights[1] - heights[0]);
    int c;
    for (int i = 3; i <= n; i++)
    {
        int val = INT_MAX;
        int d = k;
        for (int j = 1; j <= k; j++)
        {
            val = min(val, dp[k - 1] + abs(heights[i - 1] - heights[i - j - 1]));
            k--;
            c = val;
        }
        pop_front(dp);
        dp.push_back(val);
    }
    return c;
}