#include <bits/stdc++.h>
using namespace std;

int Edit_Distance_Helper(string s1, string s2, int **output)
{
    int m = s1.size();
    int n = s2.size();
    if (output[m][n] != 0)
    {
        return output[m][n];
    }

    if (s1.size() == 0 || s2.size() == 0)
    {
        return max(s1.size(), s2.size());
    }

    int ans;
    if (s1[0] == s2[0])
    {
        ans = Edit_Distance_Helper(s1.substr(1), s2.substr(1), output);
    }
    else
    {
        int insert = 1 + Edit_Distance_Helper(s1.substr(1), s2, output);           // Element insetred in second string
        int remove = 1 + Edit_Distance_Helper(s1, s2.substr(1), output);           // Element removed from second string
        int update = 1 + Edit_Distance_Helper(s1.substr(1), s2.substr(1), output); // First element of secong string updated

        ans = min(insert, min(remove, update));
    }
    output[m][n] = ans;
    return ans;
}
int Edit_Distance(string s1, string s2)
{
    int m = s1.size();
    int n = s2.size();
    int **output = new int *[m + 1];
    for (int i = 0; i < m + 1; i++)
    {
        output[i] = new int[n + 1];
        for (int j = 0; j < n + 1; j++)
        {
            output[i][j] = 0;
        }
    }
    return Edit_Distance_Helper(s1,s2,output);
}
int main()
{
    string s1, s2;
    cin >> s1 >> s2;
    cout << Edit_Distance(s1, s2) << endl;
    return 0;
}