
// You are given an integer array cost where cost[i] is the cost of ith step on a staircase.Once you pay the cost, you can either climb one or two steps.
// You can either start from the step with index 0, or the step with index 1.
// Return the minimum cost to reach the top of the floor.

#include <algorithm>
#include <bits/stdc++.h>
class Solution
{
public:
    int solve(vector<int> &cost, vector<int> &dp, int n)
    {
        if (dp[n] != -1)
        {
            return dp[n];
        }
        dp[n] = min(solve(cost, dp, n - 1), solve(cost, dp, n - 2)) + cost[n]; // as har floor <n ke liye uske khudh ki bhi cost consider hoge.
        return dp[n];
    }
    int minCostClimbingStairs(vector<int> &cost)
    {
        int n = cost.size();
        vector<int> dp(n + 1, -1);
        dp[0] = cost[0];
        dp[1] = cost[1];
        solve(cost, dp, n - 1);           // as top vale floor ki cost consider nhi hogi aur < n ke liye hoge toh function call n-1 tak ke liye ke.
        return min(dp[n - 1], dp[n - 2]); // as last vale floor ki cost consider nhi hogi
    }
};