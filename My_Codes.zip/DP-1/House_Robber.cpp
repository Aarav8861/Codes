// Same as Maximum_Non_Adjacent_Subsequence just the first and last house are connectd i.e houses are in circle

long long int solve(vector<int> &nums)
{
    // Write your code here.
    int n = nums.size();
    if (n == 1)
    {
        return nums[0];
    }
    vector<int> dp(n);
    long long int prev1 = 0;
    long long int prev2 = nums[0];
    for (int i = 2; i <= n; i++)
    {
        long long int curr = max(prev2 + 0, prev1 + nums[i - 1]);
        prev1 = prev2;
        prev2 = curr;
    }
    return prev2;
}
long long int houseRobber(vector<int> &valueInHouse)
{
    // Write your code here.
    vector<int> temp1, temp2;
    if (valueInHouse.size() == 1)
    {
        return valueInHouse[0];
    }
    for (int i = 0; i < valueInHouse.size(); i++)
    {
        if (i != 0) // to exclude the first house
        {
            temp1.push_back(valueInHouse[i]);
        }
        if (i != valueInHouse.size() - 1) // to exclude the last house
        {
            temp2.push_back(valueInHouse[i]);
        }
    }
    long long int ans1 = solve(temp1);
    long long int ans2 = solve(temp2);
    return max(ans1, ans2); // as first and last house can never be robbed together.
}