#include <bits/stdc++.h>
using namespace std;
int solvememo(int n, vector<int> heights, vector<int> &dp)
{
    if (n == 1)
    {
        return 0;
    }
    if (dp[n] != -1)
    {
        return dp[n];
    }
    int ans1 = solve(n - 1, heights, dp) + abs(heights[n - 1] - heights[n - 2]);
    int ans2 = INT_MAX;
    if (n > 2)
        ans2 = solve(n - 2, heights, dp) + abs(heights[n - 1] - heights[n - 3]);
    dp[n] = min(ans1, ans2);
    return dp[n];
}

int frogJump(int n, vector<int> &heights)
{
    // Write your code here.
    vector<int> dp(n + 1);
    //     return solve(n,heights,dp);
    dp[0] = 0;
    dp[1] = 0;
    dp[2] = abs(heights[1] - heights[0]);
    for (int i = 3; i <= n; i++)
    {
        dp[i] = min(dp[i - 1] + abs(heights[i - 1] - heights[i - 2]), dp[i - 2] + abs(heights[i - 1] - heights[i - 3]));
    }
    return dp[n];
}

// Space Optimizaion
int frogJump(int n, vector<int> &heights)
{
    // Write your code here.
    int prev1 = 0;
    int prev2 = abs(heights[1] - heights[0]);
    int curr = 0;
    for (int i = 3; i <= n; i++)
    {
        curr = min(prev2 + abs(heights[i - 1] - heights[i - 2]), prev1 + abs(heights[i - 1] - heights[i - 3]));
        prev1 = prev2;
        prev2 = curr;
    }
    return curr;
}