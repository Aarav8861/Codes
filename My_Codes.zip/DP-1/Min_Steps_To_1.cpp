#include <bits/stdc++.h>
using namespace std;

int Min_Steps_To_1(int n)
{
    if (n == 1)
    {
        return 0;
    }
    int c = Min_Steps_To_1(n - 1);
    int a = INT_MAX, b = INT_MAX;
    if (n % 2 == 0)
    {
        b = Min_Steps_To_1(n / 2);
    }
    if (n % 3 == 0)
    {
        a = Min_Steps_To_1(n / 3);
    }

    return min(c,min(a,b)) + 1;
}
int main()
{
    int n;
    cin >> n;
    cout << Min_Steps_To_1(n);
}