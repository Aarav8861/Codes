#include <bits/stdc++.h>
int minCostPathHelper(int **input, int s, int e, int m, int n, int **arr)
{
    if (s == m - 1 && e == n - 1)
    {
        return input[s][e];
    }
    if (s >= m || e >= n)
    {
        return INT_MAX;
    }
    if (arr[s][e] != 0)
    {
        return arr[s][e];
    }
    int x, y, z;
    x = y = z = INT_MAX;
    if (s < m - 1)
    {
        x = minCostPathHelper(input, s + 1, e, m, n, arr);
    }
    if (e < n - 1)
    {
        z = minCostPathHelper(input, s, e + 1, m, n, arr);
    }
    if (s < m - 1 && e < n - 1)
    {
        y = minCostPathHelper(input, s + 1, e + 1, m, n, arr);
    }

    int small = min(x, min(y, z));
    int k = small + input[s][e];
    arr[s][e] = k;
    return k;
}

int minCostPath(int **input, int m, int n)
{
    int **arr = NULL;
    arr = new int *[m];
    for (int i = 0; i < m; i++)
    {
        arr[i] = new int[n];
        for (int j = 0; j < n; j++)
        {
            arr[i][j] = 0; // we pass values to dynamcic 2d array like this at the point of declaration
        }
    }
    // and not as arr[i][j] = {0}
    return minCostPathHelper(input, 0, 0, m, n, arr);
}

int main()
{
    int **arr, n, m;
    cin >> n >> m;
    arr = new int *[n];
    for (int i = 0; i < n; i++)
    {
        arr[i] = new int[m];
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> arr[i][j];
        }
    }
    cout << minCostPath(arr, n, m) << endl;
}