//Recursion
void solve(vector<int> &a, int i, long long sum, long long &ans)
{
    if (i > a.size() - 1)
    {
        return;
    }
    sum = min(a[i], a[i] + (int)sum);
    ans = (min(ans, sum));
    solve(a, i + 1, sum, ans);
}

// Tabulation
int smallestSumSubarray(vector<int> &a)
{
    // long long ans = INT_MAX;
    // solve(a, 0, 0, ans);
    // return (int)ans;
    long long sum = 0;
    long long ans = INT_MAX;
    for(int i = 0 ; i < a.size();i++)
    {
        sum = min(a[i],a[i]+(int)sum);
        ans = min(ans,sum);
    }
    return (int)ans;