#include <bits/stdc++.h>
using namespace std;

int Min_Steps_To_1_helper(int arr[], int n)
{
    if (n == 1)
    {
        return 0;
    }
    if (arr[n - 1] != 0)
    {
        return arr[n - 1];
    }
    int c = Min_Steps_To_1_helper(n - 1, arr);
    int a = INT_MAX, b = INT_MAX;
    if (n % 2 == 0)
    {
        b = Min_Steps_To_1_helper(n / 2, arr);
    }
    if (n % 3 == 0)
    {
        a = Min_Steps_To_1_helper(n / 3, arr);
    }

    int ans = min(c, min(a, b)) + 1;
    arr[n - 1] = ans;
    return ans;
}
int Min_Steps_To_1(int n)
{
    int arr[n] = {0};
    Min_Steps_To_1_helper(n, arr);
}
int main()
{
    int n;
    cin >> n;
    cout << Min_Steps_To_1(n);
}