#include <bits/stdc++.h>
class Solution

{
public:
    int minCostClimbingStairs(vector<int> &cost)
    {
        int n = cost.size();
        vector<int> dp(n + 1, -1);
        int prev = cost[0];
        int prev1 = cst[1];
        ;
        int curr;
        for (int i = 2; i < n; i++)
        {
            curr = min(prev, prev1) + cost[i]; // as haar stair ki cost aayege except the last stair
            prev = prev1;
            prev1 = curr;
        }
        return min(prev, prev1); // for last stair
    }
};