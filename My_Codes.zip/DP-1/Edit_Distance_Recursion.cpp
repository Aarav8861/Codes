#include <bits/stdc++.h>
using namespace std;

int Edit_Distance(string s1, string s2)
{
    if (s1.size() == 0 || s2.size() == 0)
    {
        return max(s1.size(), s2.size());
    }

    if (s1[0] == s2[0])
    {
        return Edit_Distance(s1.substr(1), s2.substr(1));
    }
    else
    {
        int insert = 1 + Edit_Distance(s1.substr(1), s2);           // Element inserted in second string
        int remove = 1 + Edit_Distance(s1, s2.substr(1));           // Element removed from second string
        int update = 1 + Edit_Distance(s1.substr(1), s2.substr(1)); // First element of secong string updated

        return min(insert, min(remove, update));
    }
}

int main()
{
    string s1, s2;
    cin >> s1 >> s2;
    cout << Edit_Distance(s1, s2) << endl;
    return 0;
}