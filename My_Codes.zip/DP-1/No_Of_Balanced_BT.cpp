#include <iostream>
using namespace std;
#include <cmath>
int balancedBTs(int h)
{
    if (h <= 1)
        return 1;

    int x = balancedBTs(h - 1);
    int y = balancedBTs(h - 2);
    int mod = (int)(pow(10, 9) + 7); // So that the value does not go out of bounds of integer

    // First int is for typecasting the long buffer to int.
    // the value x*x is stored in another box of type long so that it also does not go out of bounds.
    // the multiplication of a long and an int will give a long.
    // then we take mod so that the result also does not go out of bounds.
    // and finally we typecast the whole resukt to an integer so that it can finally be stored in an integer variable.
    int temp1 = (int)(((long)(x)*x) % mod);   
    int temp2 = (int)((2 * (long)(x)*y) % mod);

    int ans = (temp1 + temp2) % mod;

    return ans;
}
int main()
{
    int n;
    cin >> n;
    cout << balancedBTs(n);
}