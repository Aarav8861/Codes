#include <climits>

// Memo      
int solve(int n, vector<vector<int>> &points, int last, vector<vector<int>> &dp)
{
    if (n == 0)
    {
        int maxi = INT_MIN;
        for (int task = 0; task < points[0].size(); task++)
        {
            if (task != last)
            {
                maxi = max(maxi, points[0][task]);
            }
        }
        return maxi;
    }
    if (dp[n][last] != -1)
    {
        return dp[n][last];
    }
    int maxim = INT_MIN;
    for (int task = 0; task < points[0].size(); task++)
    {
        if (task != last)
        {
            int point = points[n][task] + solve(n - 1, points, task, dp);
            maxim = max(maxim, point);
        }
    }
    dp[n][last] = maxim;
    return maxim;
}

int ninjaTraining(int n, vector<vector<int>> &points)
{
    // Write your code here.
    int m = points[0].size();
    vector<vector<int>> dp(n, vector<int>(m + 1, -1));
    return solve(n - 1, points, points[0].size(), dp);
}

// TABULATION

int ninjaTraining(int n, vector<vector<int>> &points)
{
    // Write your code here.
    int m = points[0].size();
    //     vector<vector<int>> dp(n,vector<int> (m+1,-1));
    //     return solve(n-1,points,points[0].size(),dp);
    // int prev,last = points[0].size();
    vector<vector<int>> dp(n, vector<int>(m + 1, INT_MIN));
        for(int i = 0 ; i < points[0].size();i++)
        {
            for(int j = 0 ; j< points[0].size();j++)
            {
                if(j!=i)
                    dp[0][i] = max(points[0][j],dp[0][i]);
            }
        }
    // dp[0][0] = max(points[0][1], points[0][2]);
    // dp[0][1] = max(points[0][0], points[0][2]);
    // dp[0][2] = max(points[0][0], points[0][1]);
    // dp[0][3] = max(points[0][1], max(points[0][1], points[0][2]));
    for (int i = 1; i < n; i++)
    {
        for (int last = 0; last < points[0].size() + 1; last++)
        {
            dp[i][last] = 0;
            for (int task = 0; task < points[0].size(); task++)
            {
                if (task != last)
                    dp[i][last] = max(dp[i][last], dp[i - 1][task] + points[i][task]);
            }
        }
    }
    return dp[n - 1][points[0].size()];
}

// Space Optimization.
 
 *-+
 +
 
int ninjaTraining(int n, vector<vector<int>> &points)
{
    // Write your code here.
    int m = points[0].size();
    //     vector<vector<int>> dp(n,vector<int> (m+1,-1));
    //     return solve(n-1,points,points[0].size(),dp);
    // int prev,last = points[0].size();
    vector<int> prev(m + 1, INT_MIN);
    //     for(int i = 0 ; i < points[0].size();i++)
    //     {
    //         for(int j = 0 ; j< points[0].size();j++)
    //         {
    //             if(j!=i)
    //                 dp[0][i] = max(points[0][j],dp[0][i]);
    //         }
    //     }
    prev[0] = max(points[0][1], points[0][2]);
    prev[1] = max(points[0][0], points[0][2]);
    prev[2] = max(points[0][0], points[0][1]);
    prev[3] = max(points[0][1], max(points[0][1], points[0][2]));
    for (int i = 1; i < n; i++)
    {
        vector<int> temp(m + 1, INT_MIN);
        for (int last = 0; last < points[0].size() + 1; last++)
        {
            temp[last] = 0;
            for (int task = 0; task < points[0].size(); task++)
            {
                if (task != last)
                    temp[last] = max(temp[last], prev[task] + points[i][task]);
            }
        }
        prev = temp;
    }
    return prev[m];
}