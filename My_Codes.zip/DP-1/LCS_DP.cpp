#include <bits/stdc++.h>
using namespace std;

int Edit_Distance(string s1, string s2)
{
    int m = s1.size();
    int n = s2.size();
    int **output = new int *[m + 1];
    for (int i = 0; i < m + 1; i++)
    {
        output[i] = new int[n + 1];
    }

    // Filling First Row
    for (int i = 0; i < n + 1; i++)
    {
        output[0][i] = i;
    }

    // Filling First Column
    for (int i = 0; i < m + 1; i++)
    {
        output[i][0] = i;
    }

    // Filling other elements
    for (int i = 1; i < m + 1; i++)
    {
        for (int j = 1; j < n + 1; j++)
        {
            if (s1[m - i] == s2[n - j])
            {
                output[i][j] =  output[i - 1][j - 1];
            }
            else
            {
                int insert = 1+ output[i-1][j];           // Element insetred in second string
                int remove = 1 + output[i][j-1];           // Element removed from second string
                int update = 1 + output[i-1][j-1]; // First element of secong string updated
                output[i][j] =  min(insert, min(remove, update));
            }
        }
    }
    return output[m][n];
}
