
    {
        b = Min_Steps_To_1(n / 2, arr);
    }
    if (n % 3 == 0)
    {
        a = Min_Steps_To_1(n / 3, arr);
    }

    int ans = min(c, min(a, b)) + 1;
    arr[n - 1] = ans;
    return ans;
}
int Min_Steps_To_1(int n)
{
    int arr[n] = {0};
    Min_Steps_To_1_helper(n,arr);
}
int main()
{
    int n;
    cin >> n;
    cout << Min_Steps_To_1(n);
}