
// same as unique paths only difference is that the path in the matrix can be blocked and marjed as -1

int mod = (int)(1e9 + 7);
int solve(vector<vector<int>> &mat, int i, int j, vector<vector<int>> &dp)
{
    if (i >= 0 && j >= 0 && mat[i][j] == -1)
    {
        return 0;
    }
    if (dp[i][j] != -1)
    {
        return dp[i][j];
    }
    if (i == 0 && j == 0)
    {
        return 1;
    }
    if (i < 0 || j < 0)
    {
        return 0;
    }
    int up = solve(mat, i - 1, j, dp);
    int left = solve(mat, i, j - 1, dp);
    dp[i][j] = (up + left) % mod;
    return dp[i][j];
}

int mazeObstacles(int n, int m, vector<vector<int>> &mat)
{
    // Write your code here
    int dp[n][m];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if (mat[i][j] == -1)
            {
                dp[i][j] = 0;
            }
            else if (i == 0 && j == 0)
            {
                dp[i][j] = 1;
            }
            else
            {
                int up = 0, left = 0;
                if (i > 0)
                    up = dp[i - 1][j];
                if (j > 0)
                    left = dp[i][j - 1];
                dp[i][j] = (up + left) % mod;
            }
        }
    }
    return dp[n - 1][m - 1];
}

int mazeObstacles(int n, int m, vector<vector<int>> &mat)
{
    // Write your code here
    vector<int> dp(m,0);
    for (int i = 0; i < n; i++)
    {
        vector<int> curr(m,0);
        for (int j = 0; j < m; j++)
        {
            if (mat[i][j] == -1)
            {
                curr[j] = 0;
            }
            else if (i == 0 && j == 0)
            {
                curr[j] = 1;
            }
            else
            {
                int up = 0, left = 0;
                if (i > 0)
                    up = dp[j];
                if (j > 0)
                    left = curr[j - 1];
                curr[j] = (up + left) % mod;
            }
        }
        dp = curr;
    }
    return dp[m - 1];
}