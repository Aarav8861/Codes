#include <bits/stdc++.h>
using namespace std;

class BinaryTree
{
public:
    int data;
    BinaryTree *left;
    BinaryTree *right;

    BinaryTree(int data)
    {
        this->data = data;
        left = NULL;
        right = NULL;
    }
};

BinaryTree *fromarray(int *arr, int s, int e)
{
    if (s > e)
    {
        return NULL;
    }
    int mid = (s + e) / 2;
    BinaryTree *root = new BinaryTree(arr[mid]);
    BinaryTree *leftchild = fromarray(arr, s, mid - 1);
    BinaryTree *rightchild = fromarray(arr, mid + 1, e);
    root->left = leftchild;
    root->right = rightchild;
    return root;
}

BinaryTree *takeinput()
{
    int data;
    cin >> data;
    BinaryTree *root = new BinaryTree(data);
    queue<BinaryTree *> q;
    q.push(root);
    while (!q.empty())
    {
        BinaryTree *front = q.front();
        q.pop();

        int leftdata;
        cout << "Enter the left node of " << front->data << endl;
        cin >> leftdata;
        if (leftdata != -1)
        {
            BinaryTree *leftnode = new BinaryTree(leftdata);
            front->left = leftnode;
            q.push(leftnode);
        }

        int rightdata;
        cout << "Enter the right node of " << front->data << endl;
        cin >> rightdata;
        if (rightdata != -1)
        {
            BinaryTree *rightnode = new BinaryTree(rightdata);
            front->right = rightnode;
            q.push(rightnode);
        }
    }
    return root;
}
void print(BinaryTree *root)
{
    if (root == NULL)
        return;
    queue<BinaryTree *> q;
    q.push(root);
    q.push(NULL);
    while (!q.empty())
    {
        BinaryTree *front = q.front();
        q.pop();
        if (front == NULL)
        {
            cout << endl;
            if (!q.empty())
            {
                q.push(NULL);
            }
        }
        else
        {
            cout << front->data << " ";
            if (front->left != NULL)
            {
                q.push(front->left);
            }
            if (front->right != NULL)
            {
                q.push(front->right);
            }
        }
    }
}

int main()
{
    int n;
    cin >> n;
    int arr[100000];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    BinaryTree *root = fromarray(arr, 0, n - 1);
    print(root);
}