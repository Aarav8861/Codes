#include <bits/stdc++.h>
using namespace std;
#include <queue>
template <typename T>
class BinaryNode
{
public:
    T data;
    BinaryNode<T> *left;
    BinaryNode<T> *right;

    BinaryNode(T data)
    {
        this->data = data;
        left = NULL;
        right = NULL;
    }
    ~BinaryNode()
    {
        delete left;
        delete right;
    }
};

BinaryNode<int> *takeInput()
{
    int rootData;
    cout << "Enter Root Data" << endl;
    cin >> rootData;
    BinaryNode<int> *root = new BinaryNode<int>(rootData);
    queue<BinaryNode<int> *> pendingNodes;
    pendingNodes.push(root);

    while (pendingNodes.size() != 0)
    {
        BinaryNode<int> *front = pendingNodes.front();
        pendingNodes.pop();
        int leftData;
        cout << "Enter left Node of " << front->data << endl;
        cin >> leftData;
        if (leftData != -1)
        {
            BinaryNode<int> *leftChild = new BinaryNode<int>(leftData);
            front->left = leftChild;
            pendingNodes.push(leftChild);
        }
        int rightData;
        cout << "Enter right Node of " << front->data << endl;
        cin >> rightData;
        if (rightData != -1)
        {
            BinaryNode<int> *rightChild = new BinaryNode<int>(rightData);
            front->right = rightChild;
            pendingNodes.push(rightChild);
        }
    }
    return root;
}
void print(BinaryNode<int> *root)
{
    // Write your code here
    if (root == NULL)
        return;
    queue<BinaryNode<int> *> pendingNodes;
    pendingNodes.push(root);
    while (!pendingNodes.empty())
    {
        BinaryNode<int> *front = pendingNodes.front();
        cout << front->data << ":";
        pendingNodes.pop();

        if (front->left != NULL)
        {
            cout << "L:" << front->left->data << ",";
            pendingNodes.push(front->left);
        }
        if (front->right != NULL)
        {
            cout << "R:" << front->right->data;
            pendingNodes.push(front->right);
        }

        cout << endl;
    }
}
int k = 0;

void convert(BinaryNode<int> *root, int *arr)
{
    if (root == NULL)
        return;
    arr[k++] = root->data;

    convert(root->left, arr);
    convert(root->right, arr);
}
int main()
{
    BinaryNode<int> *root = takeInput();
    print(root);
}