/*************************************************************
    Following is the Binary Tree node structure.

    class BinaryTreeNode {
      public :
        T data;
        BinaryTreeNode<T> *left;
        BinaryTreeNode<T> *right;

        BinaryTreeNode(T data) {
            this -> data = data;
            left = NULL;
            right = NULL;
        }

        ~BinaryTreeNode() {
            if (left){
                delete left;
            }
            if (right){
                delete right;
            }
        }
    };
*************************************************************/
vector<int> diagonalPath(BinaryTreeNode<int> *root)
{
    //      vector<int> ans;
    //         if (root == NULL)
    //             return ans;

    //         map<int,vector<int>,greater<int>> m;
    //         queue<pair<BinaryTreeNode<int> *, int>> q;

    //         q.push(make_pair(root,0));

    //         while (!q.empty())
    //         {
    //             pair<BinaryTreeNode<int> *, int> temp = q.front();
    //             BinaryTreeNode<int> *frontNode = temp.first;
    //             int hd = temp.second;
    //             //int lvl = temp.second.second;
    //             m[hd].push_back(frontNode->data);

    //             q.pop();

    //             if (frontNode->left)
    //             {
    //                 q.push(make_pair(frontNode->left, (hd-1)));
    //             }
    //             if (frontNode->right)
    //             {
    //                 q.push(make_pair(frontNode->right,hd));
    //             }
    //         }
    //         for (auto i : m)
    //         {
    //             for (auto j : i.second)
    //             {
    //                 // for (auto k : j.second)
    //                     ans.push_back(j);
    //             }
    //         }
    //         return ans;
    queue<BinaryTreeNode<int> *> q;
    vector<int> ans;
    if (!root)
        return ans;
    q.push(root);
    while (!q.empty())
    {
        BinaryTreeNode<int> *temp = q.front();
        q.pop();
        while (temp)
        {
            if (temp->left)
            {
                q.push(temp->left);
            }
            ans.push_back(temp->data);
            temp = temp->right;
        }
    }
    return ans;
}