#include <bits/stdc++.h>
using namespace std;

class BinaryTree
{
public:
    int data;
    BinaryTree *left;
    BinaryTree *right;

    BinaryTree(int data)
    {
        this->data = data;
        left = NULL;
        right = NULL;
    }
};

BinaryTree *takeinput()
{
    int data;
    cin >> data;
    if (data == -1)
    {
        return NULL;
    }
    BinaryTree *root = new BinaryTree(data);

    root->left = takeinput();
    root->right = takeinput();
    return root;
}

int height(BinaryTree *root)
{
    if (root == NULL)
    {
        return 0;
    }
    return max(height(root->left), height(root->right)) + 1;
}

void printKthlevel(BinaryTree *root, int k)
{
    if (root == NULL)
    {
        return;
    }
    if (k == 1)
    {
        cout << root->data << " ";
        return;
    }
    printKthlevel(root->left, k - 1);
    printKthlevel(root->right, k - 1);
    return;
}
void printAllLevels(BinaryTree *root)
{
    int h = height(root);
    for (int i = 1; i <= h; i++)
    {
        printKthlevel(root, i);
        cout << endl;
    }
}
int main()
{
    BinaryTree *root = takeinput();
    printAllLevels(root);
}