#include <bits/stdc++.h>
using namespace std;

class BinaryTree
{
public:
    int data;
    BinaryTree *left;
    BinaryTree *right;

    BinaryTree(int data)
    {
        this->data = data;
        left = NULL;
        right = NULL;
    }
};
BinaryTree *takeinput()
{
    int data;
    cin >> data;
    BinaryTree *root = new BinaryTree(data);
    queue<BinaryTree *> q;
    q.push(root);
    while (!q.empty())
    {
        BinaryTree *front = q.front();
        q.pop();

        int leftdata;
        cout << "Enter the left node of " << front->data << endl;
        cin >> leftdata;
        if (leftdata != -1)
        {
            BinaryTree *leftnode = new BinaryTree(leftdata);
            front->left = leftnode;
            q.push(leftnode);
        }

        int rightdata;
        cout << "Enter the right node of " << front->data << endl;
        cin >> rightdata;
        if (rightdata != -1)
        {
            BinaryTree *rightnode = new BinaryTree(rightdata);
            front->right = rightnode;
            q.push(rightnode);
        }
    }
    return root;
}
void print(BinaryTree *root)
{
    if (root == NULL)
        return;
    queue<BinaryTree *> q;
    q.push(root);
    q.push(NULL);
    while (!q.empty())
    {
        BinaryTree *front = q.front();
        q.pop();
        if (front == NULL)
        {
            cout << endl;
            if (!q.empty())
            {
                q.push(NULL);
            }
        }
        else
        {
            cout << front->data << " ";
            if (front->left != NULL)
            {
                q.push(front->left);
            }
            if (front->right != NULL)
            {
                q.push(front->right);
            }
        }
    }
}

void printKthlevel(BinaryTree *root, int k)
{
    if (root == NULL)
    {
        return;
    }
    if (k == 0)
    {
        cout << root->data << " ";
        return;
    }
    printKthlevel(root->left, k - 1);
    printKthlevel(root->right, k - 1);
    return;
}

int printatdistancek(BinaryTree *root, BinaryTree *target, int k)
{
    if (root == NULL)
    {
        return -1;
    }

    // reach the target node.
    if (root == target)
    {
        printKthlevel(target, k);
        return 0;
    }

    // next step - ancestor
    int DL = printatdistancek(root->left, target, k);

    if (DL != -1)
    {
        // Again there are two cases
        // Ancestors itself or you need to go to the right ancestor.
        if (DL + 1 == k)
        {
            cout << root->data << " ";
        }
        else
        {
            printKthlevel(root->right, k - 2 - DL);
        }
        return 1 + DL;
    }
    int DR = printatdistancek(root->right, target, k);

    if (DR != -1)
    {
        // Again there are two cases
        // Ancestors itself or you need to go to the right ancestor.
        if (DR + 1 == k)
        {
            cout << root->data << " ";
        }
        else
        {
            printKthlevel(root->left, k - 2 - DR);
        }
        return 1 + DR;
    }
    // Node was not present in left and right subtree of given tree.
    return -1;
}
int main()
{
    BinaryTree *root = takeinput();
    BinaryTree *target = root->left->left;
    int k;
    cin >> k;
    printatdistancek(root, target, k);
}