

// Given a binary tree, flatten it into linked list in-place. Usage of auxiliary data structure is not allowed.
// After flattening, left of each node should point to NULL and right should contain next node in preorder.

class Solution
{
public:
    void flatten(Node *root)
    {
        // code here
        Node *current = root;
        while (current != NULL)
        {
            if (current->left != NULL)
            {
                Node *predecessor = current->left;
                while (predecessor->right != NULL)
                {
                    predecessor = predecessor->right;
                }
                predecessor->right = current->right;
                current->right = current->left;
            }
            current = current->right;
        }

        // left part NULL
        current = root;
        while (current != NULL)
        {
            current->left = NULL;
            current = current->right;
        }
    }
};