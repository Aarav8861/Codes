Node *solve(int in[], int post[], int n, int s, int e, int &postindex)
{
    if (s > e || postindex < 0)
    {
        return NULL;
    }
    auto it = find(in + s, in + e + 1, post[postindex]);
    int index = it - in;
    Node *root = new Node(post[postindex--]);
    root->right = solve(in, post, n, index + 1, e, postindex);
    root->left = solve(in, post, n, s, index - 1, postindex);

    return root;
}

// Function to return a tree created from postorder and inoreder traversals.
Node *buildTree(int in[], int post[], int n)
{
    // Your code here
    int postindex = n - 1;
    Node *ans = solve(in, post, n, 0, n - 1, postindex);
    return ans;
}