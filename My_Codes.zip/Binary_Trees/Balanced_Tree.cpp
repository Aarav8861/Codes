#include <bits/stdc++.h>
using namespace std;

class BinaryTree
{
public:
    int data;
    BinaryTree *left;
    BinaryTree *right;

    BinaryTree(int data)
    {
        this->data = data;
        left = NULL;
        right = NULL;
    }
};

class HBpair
{
public:
    int height;
    bool balance;
};

HBpair Isbalanced(BinaryTree *root)
{
    HBpair p;
    if (root == NULL)
    {
        p.height = 0;
        p.balance = true;
        return p;
    }

    HBpair left = Isbalanced(root->left);
    HBpair right = Isbalanced(root->right);
    p.height = max(left.height, right.height) + 1;
    if (abs(left.height - right.height) <= 1 && left.balance && right.balance)
    {
        p.balance = true;
    }
    else
    {
        p.balance = false;
    }
    return p;
}

BinaryTree *takeinput()
{
    int data;
    cin >> data;
    BinaryTree *root = new BinaryTree(data);
    queue<BinaryTree *> q;
    q.push(root);
    while (!q.empty())
    {
        BinaryTree *front = q.front();
        q.pop();

        int leftdata;
        cout << "Enter the left node of " << front->data << endl;
        cin >> leftdata;
        if (leftdata != -1)
        {
            BinaryTree *leftnode = new BinaryTree(leftdata);
            front->left = leftnode;
            q.push(leftnode);
        }

        int rightdata;
        cout << "Enter the right node of " << front->data << endl;
        cin >> rightdata;
        if (rightdata != -1)
        {
            BinaryTree *rightnode = new BinaryTree(rightdata);
            front->right = rightnode;
            q.push(rightnode);
        }
    }
    return root;
}
void print(BinaryTree *root)
{
    if (root == NULL)
        return;
    queue<BinaryTree *> q;
    q.push(root);
    q.push(NULL);
    while (!q.empty())
    {
        BinaryTree *front = q.front();
        q.pop();
        if (front == NULL)
        {
            cout << endl;
            if (!q.empty())
            {
                q.push(NULL);
            }
        }
        else
        {
            cout << front->data << " ";
            if (front->left != NULL)
            {
                q.push(front->left);
            }
            if (front->right != NULL)
            {
                q.push(front->right);
            }
        }
    }
}

int replaceSum(BinaryTree *root)
{
    if (root == NULL)
    {
        return 0;
    }
    if (root->left == NULL && root->right == NULL)
    {
        return root->data;
    }

    // Recursive Part
    int leftSum = replaceSum(root->left);
    int rightSum = replaceSum(root->right);

    int temp = root->data;
    root->data = leftSum + rightSum;
    return temp + root->data;
}

int main()
{
    BinaryTree *root = takeinput();
    print(root);
    /*replaceSum(root);
    print(root);*/

    if (Isbalanced(root).balance)
    {
        cout << " Balanced" << endl;
    }
    else
    {
        cout << " The given binary Tree is not balanced" << endl;
    }
    return 0;
}