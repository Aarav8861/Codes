int solve(Node *root, int k, int node, vector<int> ans)
{
    if (root == NULL)
    {
        return -1;
    }

    ans.push_back(root->data);

    int leftans = solve(root->left, k, node, ans);
    int rightans = solve(root->right, k, node, ans);

    if (root->data == node)
    {
        int j = 0;
        int i = ans.size() - 1;
        if (k > i)
        {
            return -1;
        }
        for (; j != k; i--, j++)
        {
        }
        return ans[i];
    }
    if (leftans == -1)
    {
        return rightans;
    }
    else
    {
        return leftans;
    }
    ans.pop_back();
}

int kthAncestor(Node *root, int k, int node)
{
    // Code here
    vector<int> ans;
    return solve(root, k, node, ans);
}