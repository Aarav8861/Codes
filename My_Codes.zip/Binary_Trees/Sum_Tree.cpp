class Solution
{
public:
    pair<bool, int> sum(Node *root)
    {
        if (root == NULL)
        {
            pair<bool, int> p = make_pair(true, 0);
            return p;
        }
        if (root->left == NULL && root->right == NULL)
        {
            pair<bool, int> p = make_pair(true, root->data);
            return p;
        }
        pair<bool, int> left = sum(root->left);
        pair<bool, int> right = sum(root->right);
        pair<bool, int> ans;
        if (left.first && right.first && (root->data == left.second + right.second))
        {
            ans.first = true;
            ans.second = 2 * root->data;
        }
        else
        {
            ans.first = false;
        }
        return ans;
    }
    bool isSumTree(Node *root)
    {
        // Your code here
        return sum(root).first;
    }