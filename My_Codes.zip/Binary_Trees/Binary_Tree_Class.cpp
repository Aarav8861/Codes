#include <bits/stdc++.h>
using namespace std;
template <typename T>
class BinaryNode
{
public:
    T data;
    BinaryNode<T> *left;
    BinaryNode<T> *right;

    BinaryNode(T data)
    {
        this->data = data;
        left = NULL;
        right = NULL;
    }
    ~BinaryNode()
    {
        delete left;
        delete right;
    }
};