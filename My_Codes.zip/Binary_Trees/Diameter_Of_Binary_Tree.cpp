

#include <bits/stdc++.h>
using namespace std;
#include <queue>
template <typename T>
class BinaryNode
{
public:
    T data;
    BinaryNode<T> *left;
    BinaryNode<T> *right;

    BinaryNode(T data)
    {
        this->data = data;
        left = NULL;
        right = NULL;
    }
    ~BinaryNode()
    {
        delete left;
        delete right;
    }
};

BinaryNode<int> *takeInput()
{
    int rootData;
    cout << "Enter Root Data" << endl;
    cin >> rootData;
    BinaryNode<int> *root = new BinaryNode<int>(rootData);
    queue<BinaryNode<int> *> pendingNodes;
    pendingNodes.push(root);

    while (pendingNodes.size() != 0)
    {
        BinaryNode<int> *front = pendingNodes.front();
        pendingNodes.pop();
        int leftData;
        cout << "Enter left Node of " << front->data << endl;
        cin >> leftData;
        if (leftData != -1)
        {
            BinaryNode<int> *leftChild = new BinaryNode<int>(leftData);
            front->left = leftChild;
            pendingNodes.push(leftChild);
        }
        int rightData;
        cout << "Enter right Node of " << front->data << endl;
        cin >> rightData;
        if (rightData != -1)
        {
            BinaryNode<int> *rightChild = new BinaryNode<int>(rightData);
            front->right = rightChild;
            pendingNodes.push(rightChild);
        }
    }
    return root;
}
int height(BinaryNode<int> *root)
{
    if (root == NULL)
        return 0;

    return 1 + max(height(root->left), height(root->right));
}

// Maximum distance between two nodes in a binary Tree
int diameter(BinaryNode<int> *root)
{
    if (root == NULL)
        return 0;

    int option1 = height(root->left) + height(root->right); // If it passes through the root.
    int option2 = diameter(root->left);                     // If the diameter is in the left subtree.
    int option3 = diameter(root->right);                    // If the diameter is in the right subtree.

    return max(option1, max(option2, option3));
}
void print(BinaryNode<int> *root)
{
    // Write your code here
    if (root == NULL)
        return;
    queue<BinaryNode<int> *> pendingNodes;
    pendingNodes.push(root);
    while (!pendingNodes.empty())
    {
        BinaryNode<int> *front = pendingNodes.front();
        cout << front->data << ":";
        pendingNodes.pop();

        if (front->left != NULL)
        {
            cout << "L:" << front->left->data << ",";
            pendingNodes.push(front->left);
        }
        if (front->right != NULL)
        {
            cout << "R:" << front->right->data;
            pendingNodes.push(front->right);
        }

        cout << endl;
    }
}

int main()
{
    BinaryNode<int> *root = takeInput();
    print(root);
}