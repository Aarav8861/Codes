

// Different from other traversals as all other traversals (level,in,pre,post) have space complexity of O(n)
// but this traversal have a space complexity of order of O(1)
// Jahan par bhi space complexity O(1) likhe ho toh samjh jao ki voh Morris traversal ka question hai.

class Solution
{
public:
    Node *find(Node *current)
    {
        Node *predecessor = current->left;
        while (predecessor->right != NULL && predecessor->right != current)
        {
            predecessor = predecessor->right;
        }
        return predecessor;
    }
    vector<int> inOrder(Node *root)
    {
        // code here
        vector<int> ans;
        Node *current = root;
        while (current != NULL)
        {
            if (current->left == NULL)
            {
                ans.push_back(current->data);
                current = current->right;
            }
            else
            {
                Node *predecessor = find(current);
                if (predecessor->right == NULL)
                {
                    predecessor->right = current;
                    current = current->left; // Establishing temporary link
                }
                else
                {
                    predecessor->right = NULL; // Destroying the temporary link
                    ans.push_back(current->data);
                    current = current->right;
                }
            }
        }
        return ans;
    }
};