class Solution
{
public:
    Node *createnodetoparentmapping(Node *root, int target, map<Node *, Node *> &nodetoparent)
    {
        queue<Node *> q;
        q.push(root);
        Node *res = NULL;
        nodetoparent[root] = NULL;
        while (!q.empty())
        {
            Node *front = q.front();
            q.pop();

            if (front->data == target)
            {
                res = front;
            }
            if (front->left)
            {
                q.push(front->left);
                nodetoparent[front->left] = front;
            }
            if (front->right)
            {
                q.push(front->right);
                nodetoparent[front->right] = front;
            }
        }
        return res;
    }

    int burntree(Node *root, map<Node *, Node *> &nodetoparent)
    {
        map<Node *, bool> visited; // To store whether a particular node is visited or not.
        visited[root] = true;
        int ans = 0;
        queue<Node *> q;
        q.push(root);
        while (!q.empty())
        {
            bool flag = 0;
            int size = q.size();
            for (int i = 0; i < size; i++) // time ko increament karne ke liye yeh loop laga h coz time tabhi update hoga jabh queue mei present saare current ke neighbours burn ho jayenge.
            {
                Node *front = q.front();
                q.pop();
                if (front->left && !visited[front->left])
                {
                    q.push(front->left);
                    visited[front->left] = 1;
                    flag = 1;
                }
                if (front->right && !visited[front->right])
                {
                    q.push(front->right);
                    visited[front->right] = 1;
                    flag = 1;
                }
                if (nodetoparent[front] && !visited[nodetoparent[front]])
                {
                    q.push(nodetoparent[front]);
                    visited[nodetoparent[front]] = 1;
                    flag = 1;
                }
            }
            if (flag)
            {
                ans++;
            }
        }
        return ans;
    }
    int minTime(Node *root, int target)
    {
        // 3 steps
        // 1. Node to parent mapping
        // 2. Find the target node
        // 3. Burn the tree

        map<Node *, Node *> nodetoparent;
        Node *res = createnodetoparentmapping(root, target, nodetoparent);
        int ans = burntree(res, nodetoparent);
        return ans;
    }
};