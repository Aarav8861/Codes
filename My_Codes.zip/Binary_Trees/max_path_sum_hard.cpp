class Solution
{
public:
    int ans = INT_MIN;
    int helper(TreeNode *root)
    {
        if (root == NULL)
            return NULL;

        int a = helper(root->left);
        int b = helper(root->right);

        // case 1 it is in the path
        int ms1 = max(max(a, b) + root->val, root->val);

        // case 2 the node is the root of the tree
        int ms2 = max(a + b + root->val, ms1);
        ans = max(ms2, ans);
        return ms1;
    }
    int maxPathSum(TreeNode *root)
    {
        if (root->left == NULL && root->right == NULL)
            return root->val;
        helper(root);
        return ans;
    }
};