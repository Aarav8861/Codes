

#include <bits/stdc++.h>
using namespace std;
#include <queue>
template <typename T>
class BinaryNode
{
public:
    T data;
    BinaryNode<T> *left;
    BinaryNode<T> *right;

    BinaryNode(T data)
    {
        this->data = data;
        left = NULL;
        right = NULL;
    }
    ~BinaryNode()
    {
        delete left;
        delete right;
    }
};

BinaryNode<int> *takeInput()
{
    int rootData;
    cout << "Enter Root Data" << endl;
    cin >> rootData;
    BinaryNode<int> *root = new BinaryNode<int>(rootData);
    queue<BinaryNode<int> *> pendingNodes;
    pendingNodes.push(root);

    while (pendingNodes.size() != 0)
    {
        BinaryNode<int> *front = pendingNodes.front();
        pendingNodes.pop();
        int leftData;
        cout << "Enter left Node of " << front->data << endl;
        cin >> leftData;
        if (leftData != -1)
        {
            BinaryNode<int> *leftChild = new BinaryNode<int>(leftData);
            front->left = leftChild;
            pendingNodes.push(leftChild);
        }
        int rightData;
        cout << "Enter right Node of " << front->data << endl;
        cin >> rightData;
        if (rightData != -1)
        {
            BinaryNode<int> *rightChild = new BinaryNode<int>(rightData);
            front->right = rightChild;
            pendingNodes.push(rightChild);
        }
    }
    return root;
}

pair<int, int> heightDiameter(BinaryNode<int> *root)
{
    if (root == NULL)
    {
        pair<int, int> p;
        p.first = 0;
        p.second = 0;
        return p;
    }

    pair<int, int> leftAns = heightDiameter(root->left);
    pair<int, int> rightAns = heightDiameter(root->right);
    int lh = leftAns.first;
    int ld = leftAns.second;
    int rh = rightAns.first;
    int rd = rightAns.second;

    int height = 1 + max(lh, rh);
    int diameter = max(lh + rh, max(ld, rd));

    pair<int, int> p;
    p.first = height;
    p.second = diameter;
    return p;
}

void print(BinaryNode<int> *root)
{
    // Write your code here
    if (root == NULL)
        return;
    queue<BinaryNode<int> *> pendingNodes;
    pendingNodes.push(root);
    while (!pendingNodes.empty())
    {
        BinaryNode<int> *front = pendingNodes.front();
        cout << front->data << ":";
        pendingNodes.pop();

        if (front->left != NULL)
        {
            cout << "L:" << front->left->data << ",";
            pendingNodes.push(front->left);
        }
        if (front->right != NULL)
        {
            cout << "R:" << front->right->data;
            pendingNodes.push(front->right);
        }

        cout << endl;
    }
}

int main()
{
    BinaryNode<int> *root = takeInput();
    print(root);
}