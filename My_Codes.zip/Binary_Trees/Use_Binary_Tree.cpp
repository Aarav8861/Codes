#include <bits/stdc++.h>
using namespace std;
template <typename T>
class BinaryNode
{
public:
    T data;
    BinaryNode<T> *left;
    BinaryNode<T> *right;

    BinaryNode(T data)
    {
        this->data = data;
        left = NULL;
        right = NULL;
    }
    ~BinaryNode()
    {
        delete left;
        delete right;
    }
};

int main()
{
    BinaryNode<int> *root = new BinaryNode<int>(1);
    BinaryNode<int> *node1 = new BinaryNode<int>(2);
    BinaryNode<int> *node2 = new BinaryNode<int>(3);

    root->left = node1;
    root->right = node2;
}
