class Solution
{
public:
    // Function to return the maximum sum of non-adjacent nodes.
    pair<int, int> solve(Node *root)
    {
        pair<int, int> ans = make_pair(0, 0);
        if (root == NULL)
        {
            return ans;
        }
        pair<int, int> leftans = solve(root->left);
        pair<int, int> rightans = solve(root->right);

        ans.first = root->data + leftans.second + rightans.second;
        ans.second = max(leftans.first, leftans.second) + max(rightans.first, rightans.second);

        return ans;
    }
    int getMaxSum(Node *root)
    {
        // Add your code here
        pair<int, int> ans;
        ans = solve(root);
        return max(ans.first, ans.second);
    }
};