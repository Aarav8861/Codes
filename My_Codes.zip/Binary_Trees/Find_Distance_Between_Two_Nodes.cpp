#include <bits/stdc++.h>
using namespace std;
#include <queue>
template <typename T>
class BinaryNode
{
public:
    T data;
    BinaryNode<T> *left;
    BinaryNode<T> *right;

    BinaryNode(T data)
    {
        this->data = data;
        left = NULL;
        right = NULL;
    }
    ~BinaryNode()
    {
        delete left;
        delete right;
    }
};

BinaryNode<int> *takeInput()
{
    int rootData;
    cout << "Enter Root Data" << endl;
    cin >> rootData;
    BinaryNode<int> *root = new BinaryNode<int>(rootData);
    queue<BinaryNode<int> *> pendingNodes;
    pendingNodes.push(root);

    while (pendingNodes.size() != 0)
    {
        BinaryNode<int> *front = pendingNodes.front();
        pendingNodes.pop();
        int leftData;
        cout << "Enter left Node of " << front->data << endl;
        cin >> leftData;
        if (leftData != -1)
        {
            BinaryNode<int> *leftChild = new BinaryNode<int>(leftData);
            front->left = leftChild;
            pendingNodes.push(leftChild);
        }
        int rightData;
        cout << "Enter right Node of " << front->data << endl;
        cin >> rightData;
        if (rightData != -1)
        {
            BinaryNode<int> *rightChild = new BinaryNode<int>(rightData);
            front->right = rightChild;
            pendingNodes.push(rightChild);
        }
    }
    return root;
}
void print(BinaryNode<int> *root)
{
    // Write your code here
    if (root == NULL)
        return;
    queue<BinaryNode<int> *> pendingNodes;
    pendingNodes.push(root);
    while (!pendingNodes.empty())
    {
        BinaryNode<int> *front = pendingNodes.front();
        cout << front->data << ":";
        pendingNodes.pop();

        if (front->left != NULL)
        {
            cout << "L:" << front->left->data << ",";
            pendingNodes.push(front->left);
        }
        if (front->right != NULL)
        {
            cout << "R:" << front->right->data;
            pendingNodes.push(front->right);
        }

        cout << endl;
    }
}

BinaryNode<int> *LCA(BinaryNode<int> *root, int n1, int n2)
{
    if (root == NULL)
    {
        return NULL;
    }
    if (root->data == n1 || root->data == n2)
    {
        return root;
    }
    BinaryNode<int> *a = LCA(root->left, n1, n2);
    BinaryNode<int> *b = LCA(root->right, n1, n2);

    if (a == NULL && b != NULL)
    {
        return b;
    }
    else if (a != NULL && b == NULL)
    {
        return a;
    }
    else if (a == NULL && b == NULL)
    {
        return NULL;
    }
    else
    {
        return root;
    }
}

int search(BinaryNode *root, int key, int level)
{
    if (root == NULL)
    {
        return -1;
    }

    if (root->data == key)
    {
        return level;
    }

    int left = search(root->left, key, level + 1);
    if (left != -1)
    {
        return left;
    }
    return search(root->right, key, level + 1);
}
int findDistance(BinaryNode *root, int a, int b)
{
    BinaryNode *lca_node = LCA(root, a, b);

    int l1 = search(lca_node, a, 0);
    int l2 = search(lca_node, b, 0);

    return l1 + l2;
}
int main()
{
    BinaryNode<int> *root = takeInput();
    print(root);
    int n1, n2;
    cout << "Enter value" << endl;
    cin >> n1 >> n2;
    cout << LCA(root, n1, n2)->data;
}
// 1 2 3 4 5 -1 7 -1 -1 6 -1 8 9 -1 -1 -1 -1 -1 -1