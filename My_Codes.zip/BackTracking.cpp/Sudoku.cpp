#include <iostream>
#include <cmath>
using namespace std;

bool canPlace(int sudoku[][9], int i, int j, int n, int no)
{
    // Row and Column check
    for (int x = 0; x < n; x++)
    {
        if (sudoku[i][x] == no || sudoku[x][j] == no)
            t return false;
    }

    // Grid check
    int rn = sqrt(n);
    int sx = (i / rn) * rn;
    int sy = (j / rn) * rn;

    for (int x = sx; x < sx + rn; x++)
    {
        for (int y = sy; y < sy + rn; y++)
        {
            if (sudoku[x][y] == no)
                return false;
        }
    }
    return true;
}

bool solvesudoku(int sudoku[][9], int i, int j, int n)
{
    // Base Case
    if (i == n)
    {
        // Print the matrix
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                cout << sudoku[i][j] << " ";
            }
            cout << endl;
        }
        return true;
    }
    // Case Row End
    if (j == n)
        return solvesudoku(sudoku, i + 1, 0, n);

    // Skip the Pre-Filled Cells
    if (sudoku[i][j] != 0)
        return solvesudoku(sudoku, i, j + 1, n);

    // Rec
    // Fill the current cell with possible options
    for (int no = 1; no <= n; no++)
    {
        if (canPlace(sudoku, i, j, n, no))
        {
            // Assume
            sudoku[i][j] = no;
            bool couldwesolve = solvesudoku(sudoku, i, j + 1, n);
            if (couldwesolve == true)
                return true;
        }
    }
    // Backtracking
    sudoku[i][j] = 0;
    return false;
}
int main()
{

    int n;
    cin >> n;
    int sudoku[9][9];
    {
        for (int i = 0; i < 9; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                cin >> sudoku[i][j];
            }
        }
    }
    solvesudoku(sudoku, 0, 0, 9);
    return 0;
}