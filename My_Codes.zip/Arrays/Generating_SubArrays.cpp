#include <bits/stdc++.h>
using namespace std;
int main()
{
    // Subarrays are contiguous parts of an array
    int n;
    cin >> n;
    int *arr = new int[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }

    // Generating Subarrays
    for (int i = 0; i < n; i++) // To choose the starting element
    {
        for (int j = i; j < n; j++) // To choose the ending element
        {
            for (int k = i; k <= j; k++) // To print the subarray from i to k
            {
                cout << arr[k] << " ";
            }
            cout << "\t\t";
        }
        cout << endl;
    }
}