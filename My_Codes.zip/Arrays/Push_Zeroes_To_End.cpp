#include <iostream>
using namespace std;

void pushZeroesEnd(int *arr, int n)
{
    // Write your code here
    int i = 0, count = 0, j = 0;
    while (i < n)
    {
        if (arr[i] == 0)
        {
            count++;
        }
        else
        {
            arr[j] = arr[i];   // 0 1 2 0 3 5 0 0 4
            j++;
        }
        i++;
    }
    for (int i = 0; i < count; i++)
    {
        arr[j] = 0;
        j++;
    }
}

int main()
{

    int t;
    cin >> t;

    while (t--)
    {

        int size;

        cin >> size;
        int *input = new int[size];

        for (int i = 0; i < size; i++)
        {
            cin >> input[i];
        }

        pushZeroesEnd(input, size);

        for (int i = 0; i < size; i++)
        {
            cout << input[i] << " ";
        }

        cout << endl;
        delete[] input;
    }

    return 0;
}