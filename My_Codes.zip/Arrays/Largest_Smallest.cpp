#include <bits/stdc++.h>
using namespace std;

int main()
{
    int largest = INT_MIN;
    int smallest = INT_MAX;

    int arr[] = {1, 5, 3, 7, 9, 55, 24, 96, 75, 34};
    int n = sizeof(arr) / sizeof(int);

    for (int i = 0; i < n; i++)
    {
        largest = max(largest, arr[i]);
        smallest = min(smallest, arr[i]);
    }

    cout << largest << " " << smallest << endl;
}