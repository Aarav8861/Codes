#include <iostream>
using namespace std;
#include <climits>
int findSecondLargest(int arr[], int n)
{
    // Write your code here
    int largest = INT_MIN;
    int second = INT_MIN;

    for (int i = 0; i < n; i++)
    {

        if (arr[i] > largest)
        {
            second = largest;
            largest = arr[i];
        }
        else if (arr[i] < largest && arr[i] > second)
        {
            second = arr[i];
        }
    }
    return second;
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {

        int size;
        cin >> size;
        int *input = new int[size];

        for (int i = 0; i < size; i++)
        {
            cin >> input[i];
        }

        cout << findSecondLargest(input, size) << endl;

        delete[] input;
    }

    return 0;
}