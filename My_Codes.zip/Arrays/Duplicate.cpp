#include <iostream>
using namespace std;

int duplicateNumber(int input[], int size)
{
	for (int i = 0; i < size; i++)
	{
		int count = 0;
		int k = input[i];

		for (int j = i + 1; j < size; j++)
		{
			if (k == input[j])
			{
				return input[i];
			}
		}
	}
}

int main()
{

	int t;
	cin >> t;

	while (t--)
	{
		int size;
		cin >> size;
		int *input = new int[size];

		for (int i = 0; i < size; i++)
		{
			cin >> input[i];
		}

		cout << duplicateNumber(input, size) << endl;
	}

	return 0;
}