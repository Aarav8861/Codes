#include <iostream>
using namespace std;

void rotate(int *arr, int d, int n)
{
	// Write your code here
	int arr2[d];
	for (int i = 0; i < d; i++)
	{
		arr2[i] = arr[i];
	}
	int j = 0;
	for (int i = d; i < n; i++)
	{
		arr[j] = arr[i];
		j++;
	}
	int k = 0;
	for (int i = n - d; i < n; i++)
	{
		arr[i] = arr2[k];
		k++;
	}
}

int main()
{
	int t;
	cin >> t;

	while (t--)
	{
		int size;
		cin >> size;

		int *input = new int[size];

		for (int i = 0; i < size; ++i)
		{
			cin >> input[i];
		}

		int d;
		cin >> d;

		rotate(input, d, size);

		for (int i = 0; i < size; ++i)
		{
			cout << input[i] << " ";
		}

		delete[] input;
		cout << endl;
	}

	return 0;
}