#include <iostream>
#include <climits>
using namespace std;

void swap(int &a, int &b)
{
    int temp = a;
    a = b;
    b = temp;
}

int main()
{
    int n;
    cin >> n;
    int arr[10];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }

    int i = 0;
    while (i <= n - 1)
    {
        int min = INT_MAX;
        int j = 0;
        for (int k = i; k < n; k++)
        {
            if (arr[k] < min)
            {
                min = arr[k];
                j = k;
            }
        }
        swap(arr[i], arr[j]);
        i++;
    }
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << endl;
    }
}