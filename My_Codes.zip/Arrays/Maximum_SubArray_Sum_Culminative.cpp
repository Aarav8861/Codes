#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int *arr = new int[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    int cn[n];
    for (int i = 0; i < n; i++)
    {
        cn[i] = cn[i - 1] + arr[i];
    }
    int max_sum = INT_MIN;
    for (int i = 0; i < n; i++)
    {
        int sum = 0;
        for (int j = i; j < n; j++)
        {
            sum = cn[j] - cn[i - 1];
            max_sum = max(sum, max_sum);
        }
    }
    cout << "Max Sum: " << max_sum << endl;
}