#include <bits/stdc++.h>

// Given n and q, i.e, the number of ranges and number of queries, find the kth smallest element for each query (assume k>1).Print the value of kth smallest element if it exists, else print -1.

// Examples :

// Input : arr[] = {{1, 4}, {6, 8}}
//         queries[] = {2, 6, 10};
// Output : 2 7 - 1 After combining the given ranges, the numbers become 1 2 3 4 6 7 8. As here 2nd element is 2,
//     so we print 2. As 6th element is 7, so we print 7 and as 10th element doesn't exist, so we print - 1.

//                                                               Input : arr[] = {{2, 6}, {5, 7}} queries[] = {5, 8};
// Output : 6 - 1 After combining the given ranges, the numbers become 2 3 4 5 6 7. As here 5th element is 6,
//     so we print 6 and as 8th element doesn't exist,  so we print - 1.

vector<int> kthSmallest(vector<vector<int>> &ranges, vector<int> &queries)
{
    // Write your code here.
    vector<int> ans;
    // Step-1
    sort(ranges.begin(), ranges.end());
    int idx = 0;
    int n = ranges.size();
    // Step - 2 merging the common intervals
    for (int i = 1; i < n; i++)
    {
        if (ranges[idx][1] >= ranges[i][0])
        {
            ranges[idx][1] = max(ranges[idx][1], ranges[i][1]);
        }
        else
        {
            idx++;
            ranges[idx] = ranges[i];
        }
    } // Merge Operation Performed
    // Step -3 finding the Kth smallest elements
    int q = queries.size();

    for (int j = 0; j < q; j++)
    {
        //         int j=0;
        int kth = -1;
        int k = queries[j];
        for (int i = 0; i <= idx; i++)
        {
            int range_size = ranges[i][1] - ranges[i][0] + 1;
            if ((range_size) >= k)
            {

                kth = ranges[i][0] + k - 1;

                break;
            }
            else
            {

                k = k - range_size;
            }
        }
        ans.push_back(kth);
    }
    return ans;
}