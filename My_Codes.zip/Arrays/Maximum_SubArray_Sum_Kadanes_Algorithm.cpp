#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int *arr = new int[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    int currentSum = 0;
    int max_sum = INT_MIN;
    bool b = true;
    for (int i = 0; i < n; i++)
    {
        if (arr[i] > 0)
        {
            b = false;
        }
        currentSum += arr[i];
        if (currentSum < 0)
            currentSum = 0;
        max_sum = max(currentSum, max_sum);
    }
    if (b)
    {
        sort(arr, arr + n);
        cout << arr[n - 1];
    }
    cout << max_sum;
}