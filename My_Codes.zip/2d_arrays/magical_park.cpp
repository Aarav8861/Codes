#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n, m, k, p;
    cin >> n >> m >> k >> p;

    char a[n][m];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> a[i][j];
        }
    }
    bool success = true;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if(p<k)
            {
                success = false;
                break;
            }
            if (a[i][j] == '.')
            {
                p -= 2;
            }
            else if (a[i][j] == '*')
            {
                p += 5;
            }
            else
            {
                break;
            }
            if(j!=n-1)
            {
                p--;
            }
        }
    }
    if(success)
    {
        cout << "Yes" << endl;
        cout << p << endl;
    }
    else
    {
        cout << "No" << endl;
    }
}