#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n, m;
    cin >> n >> m;

    int arr[n][m];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            arr[i][j] = 1;
        }
    }
    int sum = 0;
    // submatrice sum
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            int top_left = (i + 1) * (j + 1);
            int bottom_right = (n - i) * (m - j);
            sum += arr[i][j]*top_left*bottom_right;
        }  // value of each element * contribution of each element
    }
    cout << sum << endl;
}