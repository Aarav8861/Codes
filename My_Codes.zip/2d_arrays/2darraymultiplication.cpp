#include <iostream>
using namespace std;
int main()
{
    int a,b,c,d,e,f;
    cout<<"enter the number of rows and columns for matrix 1\n";
    cin>>a>>b;
    int arr1[a][b];
    cout<<"enter the elements";
    for(int i=0;i<a;i++)
    {
        for(int j=0;j<b;j++)
        {
            cin>>arr1[i][j];
        }
    }
    cout<<"your matrix is\n";
    for(int i=0;i<a;i++)
    {
        for(int j=0;j<b;j++)
        {
            cout<< arr1[i][j]<<" ";
        }
        cout<<"\n";
    }
    cout<<"enter the number of rows and columns for matrix 2\n";
    cin>>d;
    int arr2[b][d];
    cout<<"enter the elements";
    for(int i=0;i<b;i++)
    {
        for(int j=0;j<d;j++)
        {
            cin>>arr2[i][j];
        }
    }
    cout<<"your matrix is\n";
    for(int i=0;i<b;i++)
    {
        for(int j=0;j<d;j++)
        {
            cout<< arr2[i][j]<<" ";
        }
        cout<<"\n";
    }
    int arr[a][d];
    for(int i=0;i<a;i++)
    {
        for(int j=0;j<d;j++)
        {
           arr[i][j]=0;
        }
    }    
    for(int i=0;i<a;i++)
    {
        for(int j=0;j<d;j++)
        {
            for(int k=0;k<b;k++)
            {
                arr[i][j] += arr1[i][k] * arr2[k][j];
            }
        }
    }
    cout<<"answer";
    for(int i=0;i<a;i++)
    {
        for(int j=0;j<d;j++)
        {
            cout<< arr[i][j]<<" ";
        }
        cout<<"\n";
    }
        return 0;
}