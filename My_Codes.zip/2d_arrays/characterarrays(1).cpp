#include <iostream>
using namespace std;

int main()
{
    char arr[10];
    cin>>arr;
    cout<<arr;
    return 0;
}

