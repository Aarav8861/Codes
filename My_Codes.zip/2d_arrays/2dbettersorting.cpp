#include <iostream>
using namespace std ;
int main()
{
    int key,r,c;
    cout<<"enter the number of rows and columns of array\n";
    cin>>r>>c;
    int arr[r][c];
    cout<<"enter the elements\n";
    for(int i=0;i<r;i++)
    {
       for(int j=0;j<c;j++)
       {
           cin>>arr[i][j];
       }
    }
    cout<<"your matrix is\n";
    for(int i=0;i<r;i++)
    {
       for(int j=0;j<c;j++)
       {
           cout<<arr[i][j]<<" ";
       }
       cout<<"\n";
    }
    cout<<"enter the element to be found\n";
    cin>>key;
    int i=0;
    int j=c-1;
  while(i<r && j>=0)
  {
      if(arr[r][c]==key)
      cout<<"element found";
      else if (arr[r][c]<key)
      j--;
      else if(arr[r][c]>key)
      i++;
      else
      cout<<"no such element";
  }
  return 0;
}
    
