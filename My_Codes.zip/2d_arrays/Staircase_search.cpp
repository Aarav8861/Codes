#include <bits/stdc++.h>
using namespace std;

int main()
{
    // array is sorted
    int n, m;
    cin >> n >> m;
    int arr[n][m];

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> arr[i][j];
        }
    }
    int k;
    cin >> k;
    int i = 0;
    int j = m - 1;
    while (i < n && j < m)
    {
        if (arr[i][j] == k)
        {
            break;
        }
        else if (arr[i][j] < k)
        {
            i++;
        }
        else
        {
            j--;
        }
    }
    cout << i << " " << j << endl;
}