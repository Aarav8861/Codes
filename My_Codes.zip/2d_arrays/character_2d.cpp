#include <bits/stdc++.h>
using namespace std;

int main()
{
    char a[][10] = {{'a', 'b', 'c', '\0'}, {'h', 'e', 'l', 'l', 'o', '\0'}};
    cout << a[0] << endl;
    cout << a[1] << endl;
    char b[][10] = {"hello", "good"};
    cout << b[0] << endl;
    cout << b[1] << endl;
}