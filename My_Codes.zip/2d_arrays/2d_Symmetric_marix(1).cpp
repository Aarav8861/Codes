#include <iostream>
using namespace std;

int main()
{
    int n,k=0,l=0;
    cin>>n;
    int arr[100];
    for(int i=0;i<(((n*(n+1))/2));i++)
    {
        cin>>arr[i];
    }

    for(int i=0;i<n;i++)
    {
          int l=i;
         int z=n-1;
        for(int j=0;j<n;j++)
        {
            if(i<=j)
            {
                cout<<arr[k]<<" ";
                k++;
            }
            else
            {
                cout<<arr[l]<<" ";
                l+=z;
                z--;
            }
        }
        cout<<endl;
    }
}