
#include <iostream>
using namespace std;
int main()
{
int n,m;
cout<<"enter the number of rows and columns\n";
cin>>n>>m;
int arr[n][m];
cout<<"enter the elements of array\n";
for(int i=0;i<n;i++)
{
    for(int j=0;j<m;j++)
    {
        cin>>arr[i][j];
    }
}
cout<<"the matrix is\n";
for(int i=0;i<n;i++)
{
    for(int j=0;j<m;j++)
    {
        cout<<arr[i][j]<<" ";
    }
    cout<<"\n";
}
    return 0;
}