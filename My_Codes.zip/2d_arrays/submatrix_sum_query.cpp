#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n, m;
    cin >> n >> m;
    pair<int, int> p1, p2;
    cin >> p1.first >> p1.second;
    cin >> p2.first >> p2.second;
    int arr[n][m];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            arr[i][j] = 1;
        }
    }
    int prefix[n][m];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if (j == 0)
            {
                prefix[i][j] = arr[i][j];
            }
            else
                prefix[i][j] = arr[i][j] + prefix[i][j - 1];
        }
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if (i == 0)
            {
                continue;
            }
            else
                prefix[i][j] = prefix[i][j] + prefix[i - 1][j];
        }
    }
    int sum = 0;
    sum = prefix[p2.first][p2.second] - prefix[p1.first - 1][p2.second] - prefix[p2.first][p1.second - 1] + prefix[p1.first - 1][p1.second - 1];
    cout << sum << endl;
}