#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n, m;
    cin >> n >> m;

    int arr[n][m];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> arr[i][j];
        }
    }

    int suffix[n][m] = {0};
    for (int i = n - 1; i >= 0; i--)
    {
        for (int j = m - 1; j >= 0; j--)
        {
            if (j == m - 1)
            {
                suffix[i][j] = arr[i][j];
            }
            else
                suffix[i][j] = suffix[i][j + 1] + arr[i][j];
        }
    }
    for (int i = n - 1; i >= 0; i--)
    {
        for (int j = m - 1; j >= 0; j--)
        {
            if (i == n - 1)
            {
                continue;
            }
            else
                suffix[i][j] = suffix[i + 1][j] + suffix[i][j];
        }
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cout << suffix[i][j] << " ";
        }
        cout << endl;
    }
    int max_sum = INT_MIN;
    for (int i = 0; i < n; i++)
    {
        int current = *max_element(suffix[i], suffix[i] + n);
        max_sum = max(current, max_sum);
    }
    cout << max_sum << endl;
}
