#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n, m;
    cin >> n >> m;

    int arr[n][m];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            arr[i][j] = 1;
        }
    }
    int prefix[n][m];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if (j == 0)
            {
                prefix[i][j] = arr[i][j];
            }
            else
                prefix[i][j] = arr[i][j] + prefix[i][j - 1];
        }
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if (i == 0)
            {
                continue;
            }
            else
                prefix[i][j] = prefix[i][j] + prefix[i - 1][j];
        }
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cout << prefix[i][j] << " ";
        }
        cout << endl;
    }

    int sum = 0;
    for (int li = 0; li < n; li++)
    {
        for (int lj = 0; lj < m; lj++)
        {
            for (int bi = li; bi < n; bi++)
            {
                for (int bj = lj; bj < m; bj++)
                {
                    sum += prefix[bi][bj] - prefix[li - 1][bj] - prefix[bi][lj - 1] + prefix[li - 1][lj - 1];
                }
            }
        }
    }
    cout << sum << endl;
}