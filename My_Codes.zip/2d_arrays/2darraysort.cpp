
#include <iostream>
using namespace std;

int main()
{
    int n,m,key;
    int arr[n][m];
    cout<<"enter the number of rows and columns\n";
    cin>>n>>m;
    cout<<"enter the elements\n";
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            cin>>arr[i][j];
        }
    }
    cout<<"enter the element to be found\n";
    cin>>key;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        if(arr[i][j]==key)
        cout<<"element found\n"<<key; 
    }   
    return 0;
}