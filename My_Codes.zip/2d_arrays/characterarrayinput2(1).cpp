#include <iostream>
using namespace std;

int main()
{
    int n ;
    cout<<"enter the number of characters";
    cin>>n;
    char arr[n+1];
    cin>>arr;
    cout<<"entered character is "<<arr;
    return 0;
}