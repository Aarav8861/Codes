#include <iostream>
using namespace std;

int main()
{
    int n,k=0;
    cin>>n;
    int arr[100];
    for(int i=0;i<(((n*(n+1))/2));i++)
    {
        cin>>arr[i];
    }

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(i<=j)
            {
                cout<<arr[k]<<" ";
                k++;
            }
            else 
            cout<<"0"<<" ";
        }
        cout<<endl;
    }
}