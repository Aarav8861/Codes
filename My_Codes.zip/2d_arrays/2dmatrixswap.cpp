#include <iostream>
using namespace std;
int main()
{
int n,m;
cout<<"enter the number of rows and columns\n";
cin>>n>>m;
int arr[n][m];
cout<<"enter the elements\n";
for(int i=0; i<n;i++)
{
    for(int j=0;j<m;j++)
    {
        cin>>arr[i][j];
    }
}
cout<<"your matix is\n";
for(int i=0;i<n;i++)
{
    for(int j=0;j<m;j++)
    {
        cout<<arr[i][j]<<" ";
    }
    cout<<"\n";
}
cout<<"matrix transpose is\n";
for(int i=0; i<n;i++)
{
    for(int j=0;j<m;j++)
    {
        if(i==j)
        {
            cout<<arr[i][j]<<" ";
        }
        else
        {
            cout<<arr[j][i]<<" ";
        }
    }
    cout<<"\n";
}
return 0;
}