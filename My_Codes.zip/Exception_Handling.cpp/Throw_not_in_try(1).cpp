#include <iostream>
using namespace std;
void divide(int x, int y, int z)
{
    cout << "inside the function\n";
    if ((x - y) != 0)
    {
        int R = z / (x - y);
        cout << "Result=" << R;
    }
    else
    {
        throw(x - y);// see only  the data type no use of arguements...   
    }
}

int main()
{
    try
    {
        cout << "inside try block\n";
        divide(10, 20, 30);
        divide(10, 10, 20);
    }
    catch (int i) //catches exception
    {
        cout << "\ncaught exception";
    }
    return 0;
}

