//demonstrates how we can restrict a function to throw only certain types and not all.
#include <iostream>
using namespace std;
void test(int x) throw(char, double)
{
    if (x == 0)
        throw 'x'; //char
    else if (x == 1)
        throw x; //int
    else if (x == -1)
        throw 1.0; //double
}

int main()
{
    try
    {
        cout << "Testing throw restrictions \n";
        cout << "x==0\n";
        test(0);
        cout << "x==1\n";
        test(1);
        cout << "x==-1\n";
        test(-1);
        cout << "x==2\n";
        test(2);
    }
    catch (char c)
    {
        cout << "caught a character\n";
    }
    catch (int m)
    {
        cout << "caught an integer\n";
    }

    catch (double d)
    {
        cout << "caught a double\n";
    }
    return 0;
}