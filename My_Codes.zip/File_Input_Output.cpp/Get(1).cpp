#include <iostream>
#include <fstream>
using namespace std;
int main()
{ fstream file;
char ch, fileName[51];
cout << "Enter a file name: ";
cin >> fileName;
file.open(fileName, ios::in);
 if (!file)
 { cout << fileName << "could not be opened.\n"; return 0; }
 file.get(ch); // Get a character
 while (!file.eof())
 { cout << ch; file.get(ch); // Get another character }
 file.close();}
 return 0; 
}