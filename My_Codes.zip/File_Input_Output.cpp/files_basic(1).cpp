#include <iostream>
#include <fstream>

using namespace std;

//These are some useful classes for working with files in C++
//
//fstreambase
//ifstream --> derived from fstreambase
//ofstream --> derived from fstreambase
//In order to work with files in C++, you will have to open it. Primarily, there are 2 ways to open a file:
//
//Using the constructor
//Using the member function open() of the class
//
int main()
{
    string st = "Harry bhai is badhiyaaa";
    // Opening files using constructor and writing it
    //1. fstream out ("sample.txt",ios::out);
    // out<<st;// object of derived class created... // Write operation// overwrites the previous input...--> can create new file if doen't exist //beforehand....
    // 2. ofstream out ("sample.txt");
    //out<<st;           The file is opened for output only. (Information maybe written to the file, but not read from the file.) If the file does not exist, it is created. If the file already exists, its contents are deleted (the file is truncated).
    //3. fstream out;
    //out.open("sample.txt", ios::out);
    //out << st; 
    /*4.*/ ofstream out;
    out.open("samp.txt");

    if(!out)
    {
        cout<<"error openeing the file";
    }
    out<<st;

    // Opening files using constructor and reading it...
    string st2;
    ifstream in("sample.txt"); // Read operation The file is opened for input only. (Information may be read from the file, but not written to it.) The file’s contents will be read from its beginning. If the file does not exist, the open function fails.`
     getline(in,st2);
    cout << st2;
    return 0;
}



