//This program writes information to a file, closes the file, then reopens it
//and appends more information.
#include <iostream>
#include <fstream>
using namespace std;
int main()
{ fstream dataFile;
dataFile.open("demofile.txt", ios::out);
dataFile << "Jones\n";
dataFile << "Smith\n";
dataFile.close();
 dataFile.open("demofile.txt", ios::app); //it does not overwrite...
 dataFile << "Willis\n";
 dataFile << "Davis\n";
 dataFile.close();
 
char name[81];
dataFile.open("demofile.txt", ios::in);
if (!dataFile)
{ cout << "File open error!" << endl; return 0; }
 cout << "File opened successfully.\n";
 cout << "Now reading information from the file.\n";
 for (int count = 0; count < 4; count++)
 { dataFile >> name; cout << name << endl; }
 dataFile.close();
 cout << "Done.\n";
 return 0; 
} 


