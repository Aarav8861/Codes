#include <iostream>
#include <fstream>
using namespace std;
 int main()
 { fstream dataFile("sentence.txt", ios::out);
 char ch;

cout << "Type a sentence and be sure to end it with a ";

cout << "period.\n";
while (1)
{ cin.get(ch);
dataFile.put(ch);
 if (ch == '.')
 break;
 }
 dataFile.close();
 return 0; }