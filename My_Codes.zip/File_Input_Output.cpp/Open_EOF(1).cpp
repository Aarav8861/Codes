#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
    string str2;
    cin>>str2;
    ofstream out;
    out.open("sample.txt");
    out<<str2;                                                                                                                                        
    /*out<<"This is me\n";                                                                                        
    out<<"This is also me\n";                                                                                        
    out<<"This is hii  me\n";                                                                                        
    out<<"This is yo me\n";  */                                                                                      

    out.close();

    ifstream in ("sample.txt");
    string str;
    in>>str2;
   // getline(in,str);
    cout<<str2<<endl;
    /*while(in.eof()==0)
    {
        getline(in,str);
        cout<<str<<endl;
    }*/
    in.close();


fstream dataFile("demofile.txt", ios::in);
char name[81];
if (!dataFile)
{ cout << "File open error!" << endl; return 0; }
 cout << "File opened successfully.\n";
 cout << "Reading information from the file.\n";
 dataFile >> name;// Read first name from the file
 while (!dataFile.eof())
 { 
 cout << name << endl;
 dataFile >> name;}
 dataFile.close();
 cout << "\nDone.\n";
 return 0; 
}