//This program demonstrates the close function.

 #include <iostream>
 #include <fstream>
 using namespace std;
 int main()
 { fstream dataFile;
 dataFile.open("testfile.txt", ios::out);
 if (!dataFile)
 { cout << "File open error!" << endl;
 }
 cout << "File was created successfully.\n";
  cout << "Now closing the file.\n";
  dataFile.close();
  return 0; }