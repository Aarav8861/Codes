#include <iostream>
using namespace std;
#include <algorithm>
#include <vector>
int main()
{
    int arr[] = {10, 20, 30, 40, 50};
    int n = sizeof(arr) / sizeof(int);

    rotate(arr, arr + 2, arr + n);

    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;

    //rotate vector
    vector<int> v = {1, 2, 3};
    rotate(v.begin(), v.begin()+2, v.end());

    for (int i = 0; i < v.capacity(); i++)
    {
        cout << v.at(i) << " ";
    }

    // next permutation
    next_permutation(v.begin(), v.end());
    next_permutation(v.begin(), v.end());

    cout<<endl;

    // vector iteration
    for(int x:v)
    {
        cout<<x<<" ";
    }
}