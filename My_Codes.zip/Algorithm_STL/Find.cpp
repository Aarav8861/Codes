#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int arr[] = {1, 2, 3, 4, 5};
    int n = sizeof(arr) / sizeof(int);

    int key;
    cin >> key;
    auto it = find(arr, arr + n, key);
    cout << arr << endl;
    cout << "address = " << it << endl;
    int index = (it - arr); // because we are subtracting two pointers and not two addresses . so we do not write like (it-arr)/sizeof(int)

    if (index == n)
    {
        cout << key << " is not present" << endl;
    }
    else
    {
        cout << key << " is present at index = " << index << endl;
    }
}