#include <iostream>
using namespace std;
#include <algorithm>
int main()
{
    int a = 10;
    int b = 20;
    swap(a, b);
    cout << max(a, b)<<endl;
    cout << min(a, b)<<endl;

    int arr[] = {10, 20, 30, 40, 50};
    int n=sizeof(arr)/sizeof(int);
    reverse(arr,arr+n);
    swap(arr[0],arr[1]);

    for(int i=0;i<sn;i++)
    {
        cout<<arr[i]<<" ";
    }

}