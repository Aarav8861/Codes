#include <bits/stdc++.h>
using namespace std;

int main()
{

    int arr[] = {20, 30, 40, 40, 40, 50, 1100};
    int n = sizeof(arr) / sizeof(int);
    int key;
    cin >> key;

    bool present = binary_search(arr, arr + n, key);
    if (present)
    {
        cout << "Element is present" << endl;
    }
    else
    {
        cout << "element is not present" << endl;
    }

    // Time compelxity : = logn

    auto lb = lower_bound(arr, arr + n, 40); // gives the address of first element >= key
    cout << "Lower Bound: " << lb - arr << endl;

    auto up = upper_bound(arr, arr + n, 40); // gives the address of the first element > key
    cout << "Upper Bound: " << up - arr << endl;

    // Frequency of element
    cout << "Frequency of element" << key << " " << up - lb << endl;

    return 0;
}
