#include <iostream>
#include <climits>
#include <queue>
using namespace std;

template <typename T>
class BinaryTreeNode
{
public:
    T data;
    BinaryTreeNode<T> *left;
    BinaryTreeNode<T> *right;

    BinaryTreeNode(T data)
    {
        this->data = data;
        left = NULL;
        right = NULL;
    }
};

BinaryTreeNode<int> *takeInput()
{
    int rootData;
    cout << "Enter Root Data" << endl;
    cin >> rootData;
    BinaryTreeNode<int> *root = new BinaryTreeNode<int>(rootData);
    queue<BinaryTreeNode<int> *> pendingNodes;
    pendingNodes.push(root);

    while (pendingNodes.size() != 0)
    {
        BinaryTreeNode<int> *front = pendingNodes.front();
        pendingNodes.pop();
        int leftData;
        cout << "Enter left Node of " << front->data << endl;
        cin >> leftData;
        if (leftData != -1)
        {
            BinaryTreeNode<int> *leftChild = new BinaryTreeNode<int>(leftData);
            front->left = leftChild;
            pendingNodes.push(leftChild);
        }
        int rightData;
        cout << "Enter right Node of " << front->data << endl;
        cin >> rightData;
        if (rightData != -1)
        {
            BinaryTreeNode<int> *rightChild = new BinaryTreeNode<int>(rightData);
            front->right = rightChild;
            pendingNodes.push(rightChild);
        }
    }
    return root;
}
class isBSTreturn
{
public:
    bool isBST;
    int maximum;
    int minimum;
};
isBSTreturn isBST2(BinaryTreeNode<int> *root)
{
    if (root == NULL)
    {
        isBSTreturn output;
        output.isBST = true;
        output.maximum = INT_MIN;
        output.minimum = INT_MAX;
        return output;
    }

    isBSTreturn leftOutput = isBST2(root->left);
    isBSTreturn rightOutput = isBST2(root->right);
    int maximum = max(root->data, max(leftOutput.maximum,rightOutput.maximum));
    int minimum = min(root->data,min(leftOutput.minimum,rightOutput.minimum));

    bool isBSTFinal = (root->data>leftOutput.maximum)&& (root->data<=rightOutput.minimum) && leftOutput.isBST && rightOutput.isBST;
    isBSTreturn output;
        output.isBST = isBSTFinal;
        output.maximum = maximum;
        output.minimum = minimum;
        return output;
}
int main()
{
    BinaryTreeNode<int> *root = takeInput();
}
// 4 2 6 1 3 5 7 -1 -1 -1 -1 -1 -1 -1 -1