/*************************************************************

    Following is the Binary Tree node structure

    template <typename T>

    class BinaryTreeNode
    {
    public :
        T data;
        BinaryTreeNode<T> *left;
        BinaryTreeNode<T> *right;

        BinaryTreeNode(T data) {
            this -> data = data;
            left = NULL;
            right = NULL;
        }

        ~BinaryTreeNode() {
            if (left)
            {
                delete left;
            }
            if (right)
            {
                delete right;
            }
        }
    };

*************************************************************/

pair<int, int> solve(BinaryTreeNode<int> *root, int key)
{
    // find key
    BinaryTreeNode<int> *temp = root;
    int pred = -1;
    int succ = -1;

    while (temp->data != key)
    {
        if (temp->data > key)
        {
            succ = temp->data;
            temp = temp->left;
        }
        else
        {
            pred = temp->data;
            temp = temp->right;
        }
    }

    // find pred and succ

    // pred
    BinaryTreeNode<int> *leftTree = temp->left;
    if (leftTree)
    {
        while (leftTree->right != NULL)
        {
            leftTree = leftTree->right;
        }
        pred = leftTree->data;
    }

    BinaryTreeNode<int> *rightTree = temp->right;
    if (rightTree)
    {
        while (rightTree->left != NULL)
        {
            rightTree = rightTree->left;
        }
        succ = rightTree->data;
    }

    pair<int, int> p = make_pair(pred, succ);
    return p;
}

pair<int, int> predecessorSuccessor(BinaryTreeNode<int> *root, int key)
{
    // Write your code here.
    pair<int, int> p = solve(root, key);
    return p;
}
