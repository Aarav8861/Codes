
// Property
// Inorder traveral of a BST is always sorted

vector<int> ans(BinaryTreeNode<int> *root, vector<int> &v)
{
    if (root == NULL)
    {
        return v;
    }
    ans(root->left, v);
    v.push_back(root->data);
    ans(root->right, v);
    return v;
}

int kthLargest(BinaryTreeNode<int> *root, int k)
{
    // Write your code here.
    if (k <= 0)
    {
        return -1;
    }
    if (root == NULL)
    {
        return -1;
    }

    vector<int> a;
    ans(root, a);
    if (a.size() < k)
    {
        return -1;
    }
    cout << endl;
    return a[n-k+1];
}