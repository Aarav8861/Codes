/*************************************************************

    Following is the Binary Tree node structure

    template <typename T>

    class BinaryTreeNode
    {
    public :
        T data;
        BinaryTreeNode<T> *left;
        BinaryTreeNode<T> *right;

        BinaryTreeNode(T data) {
            this -> data = data;
            left = NULL;
            right = NULL;
        }

        ~BinaryTreeNode() {
            if (left)
            {
                delete left;
            }
            if (right)
            {
                delete right;
            }
        }
    };

*************************************************************/

int minimum(BinaryTreeNode<int> *root)
{
    if (root == NULL)
    {
        return -1;
    }
    BinaryTreeNode<int> *temp = root;
    while (temp->left != NULL)
    {
        temp = temp->left;
    }
    return temp->data;
}
int maximum(BinaryTreeNode<int> *root)
{
    if (root == NULL)
    {
        return -1;
    }
    BinaryTreeNode<int> *temp = root;
    while (temp->right != NULL)
    {
        temp = temp->right;
    }
    return temp->data;
}
pair<int, int> ans(BinaryTreeNode<int> *root, int key, int &pre, int &suc)
{
    if (root == NULL)
    {
        pair<int, int> p;
        p.first = -1;
        p.second = -1;
        return p;
    }
    BinaryTreeNode<int> *temp = root;
    if (root->data == key)
    {
        if (temp->left)
        {
            pre = maximum(temp->left);
        }
        if (temp->right)
        {
            suc = minimum(temp->right);
        }
        pair<int, int> p = make_pair(pre, suc);
        return p;
    }
    else if (root->data > key)
    {
        suc = root->data;
        ans(root->left, key, pre, suc);
    }
    else
    {
        pre = root->data;
        ans(root->right, key, pre, suc);
    }
}

pair<int, int> predecessorSuccessor(BinaryTreeNode<int> *root, int key)
{
    // Write your code here.
    int pre = -1, suc = -1;
    pair<int, int> p = ans(root, key, pre, suc);
    return p;
}