/*************************************************************

    Following is the Binary Tree node structure:

    class TreeNode{

        public :
            int data;
            TreeNode *left;
            TreeNode *right;

            TreeNode(int data) {
                this -> data = data;
                left = NULL;
                right = NULL;
            }

            ~TreeNode() {
            if (left){
            delete left;
            }

            if (right){
            delete right;
            }
        }
    };

*************************************************************/
void inorder(TreeNode<int> *root, vector<int> &ans)
{
    if (root == NULL)
    {
        return;
    }
    inorder(root->left, ans);
    ans.push_back(root->data);
    inorder(root->right, ans);
    return;
}

vector<int> mergesorted(vector<int> &v1, vector<int> &v2)
{
    vector<int> v3(v1.size() + v2.size());
    int i = 0, j = 0, d = 0;
    int n1 = v1.size();
    int n2 = v2.size();
    while (i < n1 && j < n2)
    {
        if (v1[i] > v2[j])
        {
            v3[d++] = v2[j];
            j++;
        }
        else
        {
            v3[d++] = (v1[i]);
            i++;
        }
    }
    while (i < n1)
    {
        v3[d++] = v1[i];
        i++;
    }
    while (j < n2)
    {
        v3[d++] = (v2[j]);
        j++;
    }
    return v3;
}
TreeNode<int> *inordertobst(vector<int> &ans, int s, int e)
{
    if (s > e)
    {
        return NULL;
    }
    int mid = (s + e) / 2;
    TreeNode<int> *head = new TreeNode<int>(ans[mid]);
    TreeNode<int> *lefts = inordertobst(ans, s, mid - 1);
    TreeNode<int> *rights = inordertobst(ans, mid + 1, e);

    head->left = lefts;
    head->right = rights;
    return head;
}

TreeNode<int> *mergeBST(TreeNode<int> *root1, TreeNode<int> *root2)
{
    // Write your code here.
    if (root1 == NULL && root2 != NULL)
    {
        return root2;
    }
    else if (root1 != NULL && root2 == NULL)
    {
        return root1;
    }

    vector<int> ans1, ans2;
    inorder(root1, ans1);
    inorder(root2, ans2);
    vector<int> ans3 = mergesorted(ans1, ans2);
    return inordertobst(ans3, 0, ans3.size() - 1);
}