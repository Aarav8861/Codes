#include<climits>
#include<cmath>
#include <bits/stdc++.h>
using namespace std;
#include <queue>
template <typename T>
class BinaryNode
{
public:
    T data;
    BinaryNode<T> *left;
    BinaryNode<T> *right;

    BinaryNode(T data)
    {
        this->data = data;
        left = NULL;
        right = NULL;
    }
    ~BinaryNode()
    {
        delete left;
        delete right;
    }
};

BinaryNode<int> *takeInput()
{
    int rootData;
    cout << "Enter Root Data" << endl;
    cin >> rootData;
    BinaryNode<int> *root = new BinaryNode<int>(rootData);
    queue<BinaryNode<int> *> pendingNodes;
    pendingNodes.push(root);

    while (pendingNodes.size() != 0)
    {
        BinaryNode<int> *front = pendingNodes.front();
        pendingNodes.pop();
        int leftData;
        cout << "Enter left Node of " << front->data << endl;
        cin >> leftData;
        if (leftData != -1)
        {
            BinaryNode<int> *leftChild = new BinaryNode<int>(leftData);
            front->left = leftChild;
            pendingNodes.push(leftChild);
        }
        int rightData;
        cout << "Enter right Node of " << front->data << endl;
        cin >> rightData;
        if (rightData != -1)
        {
            BinaryNode<int> *rightChild = new BinaryNode<int>(rightData);
            front->right = rightChild;
            pendingNodes.push(rightChild);
        }
    }
    return root;
}
 void print(BinaryNode<int> *root) {
	// Write your code here
     if (root == NULL)
        return;
    queue<BinaryNode<int> *> pendingNodes;
    pendingNodes.push(root);
    while (!pendingNodes.empty())
    {
        BinaryNode<int> *front = pendingNodes.front();
        cout << front->data << ":";
        pendingNodes.pop();

        if(front->left!=NULL)
        {
            cout<<"L:"<<front->left->data<<",";
            pendingNodes.push(front->left);
        }
        if(front->right!=NULL)
        {
            cout<<"R:"<<front->right->data;
            pendingNodes.push(front->right);
        }

        cout << endl;
    }
  }

class Pair{
    
   public:
  int minimum;
  int maximum;
  bool bst;
   int height;
};

Pair BST(BinaryNode<int> *root)
{
    if(root==NULL)
    {
       Pair obj;
        obj.minimum =INT_MAX;
        obj.maximum = INT_MIN;
        obj.bst = true;
        obj.height=0;
    return obj;
    }
    
    Pair left= BST(root->left);
    Pair right =BST(root->right);
    
    int minimum=min(root->data,min(left.minimum,right.minimum));
    int maximum=max(root->data,max(left.maximum,right.maximum));
    bool  isBSTfinal=(root->data >left.maximum) && (root->data < right.minimum) && left.bst && right.bst;
   
    Pair obj;
    obj.minimum=minimum;
    obj.maximum=maximum;
    obj.bst=isBSTfinal;
    if(isBSTfinal)
    {
        obj.height= 1+max(left.height,right.height);
    }
    else   obj.height= max(left.height,right.height);
    return obj;
    
}

int largestBSTSubtree(BinaryNode<int> *root) {
    // Write your code here
    return BST(root).height;
    }
int main()
{
    BinaryNode<int> *root = takeInput();
    print(root);
}