/*
    Following is the class structure of BinaryTreeNode class for referance:

    class BinaryTreeNode {
       public :
        T data;
        BinaryTreeNode<T> *left;
        BinaryTreeNode<T> *right;

        BinaryTreeNode(T data) {
            this -> data = data;
            left = NULL;
            right = NULL;
        }

        ~BinaryTreeNode() {
            if (left){
                delete left;
            }
            if (right){
                delete right;
            }
        }
    };
*/

BinaryTreeNode<int> *solve(vector<int> &preorder, int min, int max, int &i)
{
    if (i >= preorder.size())
    {
        return NULL;
    }
    if (preorder[i] < min || preorder[i] > max)
    {
        return NULL;
    }
    BinaryTreeNode<int> *newNode = new BinaryTreeNode<int>(preorder[i]);
    i++;
    newNode->left = solve(preorder, min, newNode->data, i);
    newNode->right = solve(preorder, newNode->data, max, i);
    return newNode;
}

BinaryTreeNode<int> *preorderToBST(vector<int> &preorder)
{
    // Write your code here.
    int i = 0;
    int mini = INT_MIN;
    int maxi = INT_MAX;
    return solve(preorder, mini, maxi, i);
}