


#include <queue>

queue<BinaryNode*<int>> p;

p.push(root);
while(p!empty())
{
    front = p.top();
    cout<<front->data;
    p.pop();

    if()
    {       
        
    }
    
    


}
//1
2 3 
4 5 6 7
// 1 2 3 4 5 6 7 
count 