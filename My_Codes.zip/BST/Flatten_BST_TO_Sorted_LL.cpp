/************************************************************

    Following is the Binary Tree node structure

    template <typename T>
    class TreeNode {
        public :
        T data;
        TreeNode<T> *left;
        TreeNode<T> *right;

        TreeNode(T data) {
            this -> data = data;
            left = NULL;
            right = NULL;
        }

        ~TreeNode() {
            if(left)
                delete left;
            if(right)
                delete right;
        }
    };

************************************************************/
void inorder(TreeNode<int> *root, vector<int> &ans)
{
    if (root == NULL)
    {
        return;
    }
    inorder(root->left, ans);
    ans.push_back(root->data);
    inorder(root->right, ans);
}

TreeNode<int> *solve(TreeNode<int> *root)
{
    vector<int> ans;
    inorder(root, ans);

    TreeNode<int> *root1 = new TreeNode<int>(ans[0]);
    TreeNode<int> *temp = root1;
    for (int i = 1; i < ans.size(); i++)
    {
        TreeNode<int> *newroot = new TreeNode<int>(ans[i]);
        temp->left = NULL;
        temp->right = newroot;
        temp = newroot;
    }
    temp->left = NULL;
    temp->right = NULL;
    return root1;
}
TreeNode<int> *flatten(TreeNode<int> *root)
{
    // Write your code here
    TreeNode<int> *ans = solve(root);
    return ans;
}
