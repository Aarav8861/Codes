/************************************************************

    Following is the Binary Tree node structure

    template <typename T>
    class TreeNode {
        public :
        T data;
        TreeNode<T> *left;
        TreeNode<T> *right;

        TreeNode(T data) {
            this -> data = data;
            left = NULL;
            right = NULL;
        }

        ~TreeNode() {
            if(left)
                delete left;
            if(right)
                delete right;
        }
    };

************************************************************/

// Partially accepted.

pair<bool, int> checkBST(TreeNode<int> *root, int mini, int maxi, pair<bool, int> &ans)
{
    if (root == NULL)
    {
        pair<bool, int> p = make_pair(true, 0);
        return p;
    }
    if (root->data >= mini && root->data <= maxi)
    {
        pair<bool, int> lefts = checkBST(root->left, mini, root->data, ans);
        pair<bool, int> rights = checkBST(root->right, root->data, maxi, ans);
        ans.first = lefts.first && rights.first;
        ans.second = 1 + lefts.second + rights.second;
        return ans;
    }
    ans.first = false;
    return ans;
}

int largestBST(TreeNode<int> *root)
{
    // Write your code here.
    if (root == NULL)
    {
        return -1;
    }
    int mini = INT_MIN;
    int maxi = INT_MAX;
    pair<bool, int> p;
    checkBST(root, mini, maxi, p);
    if (p.first)
    {
        return p.second;
    }
    else
    {
        //         int lefts = largestBST(root->left);
        //         int rights = largestBST(root->right);
        //         if(lefts!= -1 && rights!=-1)
        //         {
        //             return max(lefts,rights);
        //         }
        //         else if(lefts!=-1)
        //         {
        //            return lefts;
        //         }
        //         else if (rights!=-1)
        //         {
        //             return rights;
        //         }
        //         else
        //         {
        //             return -1;
        //         }
        return max(largestBST(root->right), largestBST(root->left));
    }
}
