// Following is the Binary Tree node structure
/**************
class BinaryTreeNode {
    public :
    T data;
    BinaryTreeNode<T> *left;
    BinaryTreeNode<T> *right;

    BinaryTreeNode(T data) {
        this -> data = data;
        left = NULL;
        right = NULL;
    }

};
***************/

// As inorder of a BST is sorted..
vector<int> inorder(BinaryTreeNode<int> *root, vector<int> &ans)
{
    if (root == NULL)
    {
        return ans;
    }
    inorder(root->left, ans);
    ans.push_back(root->data);
    inorder(root->right, ans);
    return ans;
}
bool solve(BinaryTreeNode<int> *root, int target)
{
    vector<int> ans;
    inorder(root, ans);
    int i = 0;
    int j = ans.size() - 1;
    int sum = 0;
    while (i < j)
    {
        sum = ans[i] + ans[j];
        if (sum == target)
        {
            return true;
        }
        else if (sum < target)
        {
            i++;
        }
        else
        {
            j--;
        }
    }
    return false;
}
bool twoSumInBST(BinaryTreeNode<int> *root, int target)
{
    // Write your code here
    bool ans = solve(root, target);
    return ans;
}