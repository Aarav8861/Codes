#include<iostream>
using namespace std;

int clearbit(int n,int pos){
int mask =~(1<<pos);//compliments
return n & mask;// sets the bit as 0
}
int main()
{
    cout<<clearbit(5,2)<<endl;
    return 0;
}