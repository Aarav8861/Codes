#include <iostream>
using namespace std;
void unique(int arr[],int n)
{
    int xorsum=0;
    for(int i=0;i<n;i++)
    {
        xorsum=xorsum^arr[i];
    }
    cout<<"unique number\n"<<xorsum<<endl;
}
int main()
{
    int n;
    cout<<"enter the number of inputs\n";
    cin>>n;
    int arr[n];
    cout<<"enter the elements of array\n";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    unique(arr,n);
    return 0;
}