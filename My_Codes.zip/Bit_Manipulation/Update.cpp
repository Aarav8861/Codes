#include<iostream>
using namespace std;

int updatebit(int n,int pos,int value){
int mask= ~(1<<pos);//clears the bit
n = n & mask;
return (n | (value<<pos));//sets the  value in new bit
}
int main()
{
    cout<<updatebit(5,1,1)<<endl;
    return 0;
}