#include<iostream>
using namespace std;

int setbit(int n,int pos){
return (n | (1<<pos)); //setbit sets 1 and unset bit sets 0
}
int main()
{
    cout<<setbit(5,1)<<endl;
    return 0;
}