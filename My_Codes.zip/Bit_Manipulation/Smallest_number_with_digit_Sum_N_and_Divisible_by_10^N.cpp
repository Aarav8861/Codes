// string digitsNum(int N)
// {
//     // Code here
//     int nines = N / 9;
//     int firstdigit = N % 9;
//     string ans = "";
//     if (firstdigit != 0)
//     {
//         ans += to_string(firstdigit);
//     }
//     for (int i = 0; i < nines; i++)
//     {
//         ans += '9';
//     }
//     for (int i = 0; i < N; i++)
//     {
//         ans += '0';
//     }
//     return ans;
// }

#include <bits/stdc++.h>
using namespace std;

int maxslices(vector<int> &v)
{
    int count = 0  , maxi = -1;
    int n = v.size();

    for (int i = 0; i < n; i++)
    {
        if (maxi == i)
        {
            count++;
        }
        maxi = max(maxi, v[i]);
    }
    return count;
}

int main()
{
    vector<int> v = {2, 4, 1, 6, 5, 9, 7};
    cout << maxslices(v);
    return 0;
}
