#include <bits/stdc++.h>
using namespace std;

int lastOccurence(int arr[],int s,int e ,int k)
{
    int ans = -1;
    while(s<e)
    {
        int mid = (s+e)/2;
        if(arr[mid]==k)
        {
            ans = mid;
            s=mid+1;
        }
        else if(arr[mid]>k)
        {
            e=mid-1;
        }
        else
        {
            s=mid+1;
        }
    }
}

int BinarySearch(int arr[], int n, int k)
{
    return lastOccurence(arr, 0, n - 1, k);
}

int main()
{
    int arr[] = {1, 2, 5, 8, 8, 8, 8, 8, 10, 12, 15, 20};
    int n = sizeof(arr) / sizeof(int);
    int k;
    cin >> k;
    cout << BinarySearch(arr, n, k);
}