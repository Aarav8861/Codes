#include <iostream>
using namespace std;

int FirstOccurenece(int arr[], int s, int e, int k)
{
    int ans = -1;
    while (s <= e)
    {
        int mid = (s + e) / 2;
        if (arr[mid] > k)
        {
            e = mid - 1;
        }
        else if (arr[mid] < k)
        {
            s = mid + 1;
        }
        if (mid == k)
        {
            ans = mid;
            e = mid - 1;
        }
    }
    return ans;
}

int BinarySearch(int arr[], int n, int k)
{
    return FirstOccurenece(arr, 0, n - 1, k);
}

int main()
{
    int arr[] = {1, 2, 5, 8, 8, 8, 8, 8, 10, 12, 15, 20};
    int n = sizeof(arr) / sizeof(int);
    int k;
    cin >> k;
    cout << BinarySearch(arr, n, k);
}