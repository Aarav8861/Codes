#include <bits/stdc++.h>
using namespace std;

bool IsPossible(int arr[], int n, int m, int curr_min)
{
    int student_Used = 1;
    int pages_reading = 0;

    for (int i = 0; i < n; i++)
    {
        if (arr[i] + pages_reading > curr_min)
        {
            student_Used++;
            pages_reading = arr[i];

            if (student_Used > m)
            {
                return false;
            }
        }
        else
        {
            pages_reading += arr[i];
        }
    }
    return true;
}

int min_time(int p,int boards[],int b)
{
    int s = boards[b-1];
    int sum = 0;
    for(int i = 0 ; i < b; i++)
    {
        sum+=boards[i];
    }
    int e = sum;
    int ans = 0;
    while(s<=e)
    {
        int mid = (s+e)/2;
        bool d = can_paint(p,boards,b,mid);
        if(d)
        {
            ans = mid;
            e = mid-1;
        }
        else
        {
            s = mid+1;
        }
    }
}




int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int p, b;
        cin >> p >> b;
        int boards[b];
        for (int i = 0; i < n; i++)
        {
            cin >> boards[i];
        }
        cout << min_time(p, boards, b) << endl;
    }
}