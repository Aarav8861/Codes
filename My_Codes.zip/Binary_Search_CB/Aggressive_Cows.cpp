#include <iostream>
using namespace std;

bool CanPlaceCows(int stalls[], int n, int c, int min_sep)
{
    int last_cow = stalls[0];
    int cnt = 1;

    for (int i = 0; i < n; i++)
    {
        if (stalls[i] - last_cow >= min_sep)
        {
            last_cow = stalls[i];
            cnt++;
            if (cnt == c)
            {
                return true;
            }
        }
    }
    return false;
}
int main()
{
    int stalls[] = {1, 2, 4, 8, 9};
    int n = sizeof(stalls) / sizeof(int);
    int c = 3;
    int s = 0;
    int e = stalls[n - 1] - stalls[0];
    int ans = 0;

    while (s <= e)
    {
        int mid = (s + e) / 2;
        bool CowsRakhPaye = CanPlaceCows(stalls, n, c, mid);
        if (CowsRakhPaye)
        {
            ans = mid;
            s = mid + 1; // as we try to find T T T T T (T)-> THIS MAXIMUM TRUE VALUE;
        }
        else
        {
            e = mid - 1;
        }
    }
    cout << ans << endl;
    return 0;
}