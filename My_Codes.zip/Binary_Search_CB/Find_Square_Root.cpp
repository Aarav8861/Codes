#include <iostream>
using namespace std;

int findSquareRoot(int n)
{
    int arr[n];
    for(int i=0;i<=n;i++)
    {
        arr[i]=i;
    }
    int s=0;
    int e=n-1;
    int ans=0;
    while(s<=e)
    {
        int mid=(s+e)/2;

        if(arr[mid]*arr[mid]==n)
        {
            ans=mid;
            return ans;
        }
        else if(arr[mid]*arr[mid]>n)
        {
            e=mid-1;
        }
        else if(arr[mid]*arr[mid]<n)
        {
            ans=mid;
            s=mid+1;
        }
    }
}

int main()
{
    int n;
    cin>>n;
    cout<<findSquareRoot(n)<<endl;
}