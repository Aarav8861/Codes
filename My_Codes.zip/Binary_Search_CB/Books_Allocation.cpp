#include <iostream>
using namespace std;
#include <climits>

bool IsPossible(int arr[], int n, int m, int curr_min)
{
    int student_Used = 1;
    int pages_reading = 0;

    for (int i = 0; i < n; i++)
    {
        if (arr[i] + pages_reading > curr_min)
        {
            student_Used++;
            pages_reading = arr[i];

            if (student_Used > m)
            {
                return false;
            }
        }
        else
        {
            pages_reading += arr[i];
        }
    }
    return true;
}

int findPages(int arr[], int n, int m)
{
    long long sum = 0;
    if (n < m)
    {
        return -1;
    }

    // count the number of pages
    for (int i = 0; i < n; i++)
    {
        sum += arr[i];
    }

    int s = arr[n - 1];
    int e = sum;
    int ans = INT_MAX;

    while (s <= e)
    {
        int mid = (s + e) / 2;

        if (IsPossible(arr, n, m, mid))
        {
            ans = min(ans, mid);
            e = mid - 1; // as we try to find (T) THIS OUT OF T T T T T.
        }
        else
        {
            // it is not possible to divide at x pages
            // increase the number of pages
            s = mid + 1;
        }
    }
    return ans;
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, m;
        cin >> n >> m;

        int arr[1000];
        for (int i = 0; i < n; i++)
        {
            cin >> arr[i];
        }
        cout << findPages(arr, n, m) << endl;
    }
}