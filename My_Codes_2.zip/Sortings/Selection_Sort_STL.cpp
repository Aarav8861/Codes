#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int *arr = new int[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }

    for (int i = 0; i < n; i++)
    {
        int d = min_element(arr + i, arr + n) - arr;
        swap(arr[i], arr[d]);
    }
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << endl;
    }
}