#include <bits/stdc++.h>
using namespace std;

string extractTokenfromString(string s, int key)
{
    char *str = strtok((char *)s.c_str(), " "); // as we can only pass char array in (strtok) function, thats why we are
    // converting string object to (str).

    while (key > 1)
    {
        str = strtok(NULL, " ");
        key--;
    }
    return string(str);
}

int convertToint(string s)
{
    int val = 1;
    int intValue = 0;
    for (int i = 0; i < s.length(); i++)
    {
        intValue = intValue + (s[i] - '0') * val;
        val = val * 10;
    }
    return intValue;
}

bool lexicoCompare(pair<string, string> s1, pair<string, string> s2)
{
    return (s1.second < s2.second);
}

bool numericCompare(pair<string, string> s1, pair<string, string> s2)
{
    return (convertToint(s1.second) < convertToint(s2.second));
}

int main()
{
    int n;
    // cout<<“ENTER THE VALUE OF N\n”;
    cin >> n;

    cin.get();
    // cout<<"ENTER STRINGS\n";
    string str[100];
    // input strings.
    for (int i = 0; i < n; i++)
    {
        getline(cin, str[i]);
    }

    int key;
    // cout<<"Enter key\n";
    cin >> key;

    // cout<<extractTokenfromString(str[0],key);

    pair<string, string> strpair[100];

    for (int i = 0; i < n; i++)
    {
        strpair[i].first = str[i];
        strpair[i].second = extractTokenfromString(str[i], key);
    }

    cin.get();
    // cout<<"Enter the values of reversal & ordering\n";
    bool reversal;
    string ordering;
    cin >> reversal;
    cin.get();
    getline(cin, ordering);

    // Checking the ordering.
    if (ordering == "lexico")
    {

        sort(strpair, strpair + n, lexicoCompare);
    }
    else
    {
        sort(strpair, strpair + n, numericCompare);
    }

    // cout<<reversal<<"\n";
    // cout<<ordering;
    if (reversal == true)
    {
        for (int j = 0; j < n / 2; j++)
        {
            swap(strpair[j], strpair[n - j - 1]);
        }
    }

    // cout<<"Values after sorting is\n";
    for (int i = 0; i < n; i++)
    {
        cout << strpair[i].first;
        cout << endl;
    }
}