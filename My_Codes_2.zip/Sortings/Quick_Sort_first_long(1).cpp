#include<iostream>
using namespace std;
#include<bits/stdc++.h>
//int partition ( int A[],int start ,int end) {
//    int i = start + 1;
//    int piv = A[start] ;
//    
//    for(int j =start + 1; j <= end ; j++ )  {
//          if ( A[ j ] < piv) 
//          {
//            swap (A[i],A [ j ]);
//            i += 1;
//         }
//   }
//   swap ( A[start],A[i-1]); 
//   return i-1;                     
//}
// int partition (int A[],int start ,int end) {
    
//     int piv = A[end] ;
//     int i = (start-1);
    
//     for(int j =start; j <end ; j++ )  {
//           if ( A[ j ] < piv) 
//           {
//               i += 1;
//             swap (A[i],A [j]);
            
//         }
//    }
//    swap ( A[i+1],A[end]); 
//    return (i+1);                     
// }
 void swap(int &a, int &b) {
    int t = a;
    a = b;
    b = t;
 }
int partition(int input[],int si,int ei)
{
    int count_elements_smaller_than_pivot=0;
    int pivot=input[si];
    for(int i=si+1;i<=ei;i++)
    {
        if(input[i]<=pivot)
        {
            count_elements_smaller_than_pivot++;
        }
    }
     int pivot_index=si+count_elements_smaller_than_pivot;
    swap(input[si],input[pivot_index]);
    int i=si,j=ei;
    while(i<=pivot_index && j>=pivot_index)
    {
        if(input[i]<=pivot)
        {
            i++;
        }
        else if(input[j]>pivot)
        {
            j--;
        }
        else 
        {
            swap(input[i],input[j]);
            i++;
            j--;
        }
    }
    return pivot_index;
}
void quicksort(int input[],int si,int ei)
{
    if(si>=ei)
    {
        return;
    }
    int pivot_index=partition(input,si,ei);
    quicksort(input,si,pivot_index-1);
    quicksort(input,pivot_index+1,ei);
}
void quickSort(int input[], int size) {
quicksort(input,0,size-1);
}



int main(){
    int n;
    cin >> n;
  
    int *input = new int[n];
    
    for(int i = 0; i < n; i++) {
        cin >> input[i];
    }
    
    quickSort(input, n);
    for(int i = 0; i < n; i++) {
        cout << input[i] << " ";
    }
    
    delete [] input;

}


