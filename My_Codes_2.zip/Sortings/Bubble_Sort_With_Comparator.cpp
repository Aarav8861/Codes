#include <iostream>
using namespace std;

bool compare(int a, int b)
{
    cout << "Comparing" << a << "and" << b << endl;
    return a > b; // Every in-built sort has a swapping condition acc to which it sorts in increasing or decreasing order
                  // by using the compare function we can change the order of swapping
}

void bubbleSort(int *input, int size, bool (&cmp)(int a, int b)) // Passing a function as an argument to another function
{
    // Write your code here
    for (int i = 0; i < size - 1; i++)
    {
        int j = 0;
        while (j < size - 1 - i)
        {
            if (cmp(input[j + 1], input[j]))
            {
                int temp = input[j];
                input[j] = input[j + 1];
                input[j + 1] = temp;
            }
            j++;
        }
    }
}

int main()
{

    int t;
    cin >> t;

    while (t--)
    {
        int size;
        cin >> size;

        int *input = new int[size];

        for (int i = 0; i < size; ++i)
        {
            cin >> input[i];
        }

        bubbleSort(input, size, compare);

        for (int i = 0; i < size; ++i)
        {
            cout << input[i] << " ";
        }

        delete[] input;
        cout << endl;
    }
}