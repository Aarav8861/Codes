bool compare(Job_Sequencing a, Job_Sequencing b)
{
    return a.Profit > b.Profit;
}