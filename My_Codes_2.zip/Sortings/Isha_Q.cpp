#include <iostream>
using namespace std;
void swap(int arr[], int i, int j)
{
    int temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
}
int partition_row(int arr[][1000], int l, int r, int n, int m)
{
    int pivot = arr[r];
    int i = l - 1;
    for (int j = l; j < r; j++)
    {
        if (arr[n][j] < pivot)
        {
            i++;
            swap(arr, i, j);
        }
    }
    swap(arr, i + 1, r);
    return i + 1;
}
int partition_column(int arr[][1000], int l, int r, int n, int m)
{
    int pivot = arr[r];
    int i = l - 1;
    for (int j = l; j < r; j++)
    {
        if (arr[j][m] < pivot)
        {
            i++;
            swap(arr, i, j);
        }
    }
    swap(arr, i + 1, r);
    return i + 1;
}

void print_array_row(int arr[][1000], int n, int m)
{
    for (int i = 0; i < n; i++)
    {
        cout << arr[n][i] << " ";
    }
}

void print_array_column(int arr[][1000], int n, int m)
{
    for (int i = 0; i < m; i++)
    {
        cout << arr[i][m] << " ";
    }
}
void quicksort_row(int arr[][1000], int l, int r, int n, int m)
{
    if (l < r)
    {
        int pi = partition_row(arr, l, r, n m);
        quicksort_row(arr, l, pi - 1, n, m);
        quicksort_row(arr, pi + 1, r);
    }
}
void quicksort_column(int arr[][1000], int l, int r, int n, int m)
{
    if (l < r)
    {
        int pi = partition_column(arr, l, r, n m);
        quicksort_column(arr, l, pi - 1, n, m);
        quicksort_column(arr, pi + 1, r, n, m);
    }
}

void Helper(int arr[][1000], int n, int m)
{
    int j = 0;
    while (j > 0)
    {
        int i;
        int k;
        cout << "Enter the row to sort" << endl;
        cin >> i;
        cout << "Enter the column to sort" << endl;
        cin >> k;
        if (i <= m)
        {
            quicksort_row(arr[i][k], 0, m - 1);
            print_array_row(arr, i, k);
        }
        if (k <= n)
        {
            quicksort_column(arr[i][k], 0, n - 1);
            print_array_row(arr, i, k);
        }
    }
}

int main()
{
    int n, m;
    cin >> n >> m;
    int p[n][1000];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> p[i][j];
        }
    }
    Helper(p, n, m);
}
