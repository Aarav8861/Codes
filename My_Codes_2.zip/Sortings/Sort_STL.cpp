#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int *arr = new int[n];

    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    sort(arr, arr + n); // sorts the containers which can be an array,vector etc
    // can have three arguments start  end and the comparator function
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << endl;
    }
}