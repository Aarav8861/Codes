#include <bits/stdc++.h>
using namespace std;

bool compare(int a, int b)
{
    cout << "Comparing" << a << "and" << b << endl;
    return a > b; // Every in-built sort has a swapping condition acc to which it sorts in increasing or decreasing order
                  // by using the compare function we can change the order of swapping
}

int main()
{
    int n;
    cin >> n;
    int *arr = new int[n];

    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    sort(arr, arr + n, compare); // sorts the containers which can be an array,vector etc
    // can have three arguments start  end and the comparator function
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << endl;
    }
}