/*Structure of the Node of the BST is as
struct Node
{
    int data;
    Node *left;
    Node *right;

    Node(int val)
    {
        data = val;
        left = right = NULL;
    }
};
*/
#include <map>
void inorder(Node *root, map<int, int> &ans)
{
    if (root == NULL)
    {
        return;
    }
    inorder(root->left, ans);
    ans[root->data];
    inorder(root->right, ans);
}

int solve(Node *root1, Node *root2, int x, int count)
{
    if (root1 == NULL || root2 == NULL)
    {
        return 0;
    }
    map<int, int> ans1, ans2;
    inorder(root1, ans1);
    inorder(root2, ans2);
    for (auto i : ans1)
    {
        if (ans2.count(x - i.first))
        {
            count++;
        }
    }
    return count;
}

int countCouples(Node *root1, Node *root2, int x)
{
    // Write your code here.
    return solve(root1, root2, x, 0);
}