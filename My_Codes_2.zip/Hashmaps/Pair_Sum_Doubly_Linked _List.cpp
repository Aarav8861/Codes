/****************************************************************

    Following is the class structure of the Node class:

    class Node
    {
    public:
        int data;
        Node *next;
        Node *prev;
        Node(int data)
        {
            this->data = data;
            this->next = NULL;
            this->prev = NULL;
        }
    };

*****************************************************************/
#include <map>
bool findPair(Node *head, int k)
{
    // Write your code here.
    map<int, int> m;
    Node *temp = head;
    while (temp != NULL)
    {
        if (m.count(k - temp->data))
        {
            return true;
        }
        m[temp->data];
        temp = temp->next;
    }
    return false;
}
