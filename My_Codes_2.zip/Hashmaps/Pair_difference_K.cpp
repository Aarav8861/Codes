#include <unordered_map>
string isPairDifferenceK(vector<int> arr, int n, int k)
{
    // Write your code here.
    unordered_map<int, int> m;
    string s1 = "Yes";
    string s2 = "No";
    for (int i = 0; i < n; i++)
    {
        m[arr[i]];
        if (m.count(arr[i] - k))
        {
            return s1;
        }
    }
    return s2;
}
