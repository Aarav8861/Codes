// Majority element is an element which occurs more than floor(n/2) times.

#include <bits/stdc++.h>
int findMajorityElement(int arr[], int n)
{
    // Write your code here.
    map<int, int> m;
    for (int i = 0; i < n; i++)
    {
        m[arr[i]]++;
    }
    for (auto i : m)
    {
        if (i.second > floor(n / 2))
            return i.first;
    }
    return -1;
}