
// Approach 1
#include <bits/stdc++.h>
vector<int> findCommonElements(vector<vector<int>> &mat)
{
    // Write your code here
    vector<int> ans;
    unordered_map<int, int> mp;
    int n = mat.size(), m = mat[0].size();
    for (int i = 0; i < n; i++)
    {
        sort(mat[i].begin(), mat[i].end());
        mat[i].push_back(-1);
        for (int j = 0; j < m; j++)
        {
            if (mat[i][j] != mat[i][j + 1])
                mp[mat[i][j]]++;
        }
    }
    for (auto it : mp)
    {
        if (it.second == n)
            ans.push_back(it.first);
    }
    return ans;
}

// Approach 2

#include <unordered_map>
vector<int> findCommonElements(vector<vector<int>> &mat)
{
    // Write your code here
    unordered_map<int, int> m;
    vector<int> ans;
    for (int i = 0; i < mat[0].size(); i++)
    {
        m[mat[0][i]];
    }
    for (int i = 1; i < mat.size(); i++)
    {
        unordered_map<int, int> m1;
        for (int j = 0; j < mat[i].size(); j++)
        {
            if (m.count(mat[i][j]))
            {
                m1[mat[i][j]];
            }
        }
        m = m1;
    }
    //     for(int i = 0 ; i < ans1.size();i++)
    //     {
    //         cout << ans1[i] << " ";

    //     cout << endl;
    for (auto i : m)
    {
        ans.push_back(i.first);
    }
    return ans;
}
