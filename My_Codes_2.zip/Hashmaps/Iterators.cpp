#include <iostream>
using namespace std;
#include <map>
#include <unordered_map>
#include <string>
int main()
{
    unordered_map<string, int> m;
    m["abc"] = 1;
    m["abc2"] = 2;
    m["abc3"] = 3;
    m["abc4"] = 4;
    m["abc5"] = 5;
    m["abc6"] = 6;
    map<string, int> m1;
    m1["abc"] = 1;
    m1["abc2"] = 2;
    m1["abc3"] = 3;
    m1["abc4"] = 4;
    m1["abc5"] = 5;
    m1["abc6"] = 6;

    unordered_map<string, int>::iterator it = m.begin();
    map<string, int>::iterator it2 = m1.begin();
    while (it != m.end())
    {
        cout << "Key: " << it->first << " value: " << it->second << endl; // is implemented using pair and prints in unordered / random way
        it++;
    }
    while (it2 != m1.end())
    {
        cout << "Key: " << it2->first << " value: " << it2->second << endl; // prints in unordered / random way
        it2++;
    }

    //find using iterators
    //unordered_map<string, int>::iterator it2 = m.find("abc");

    //erase using iterators
}