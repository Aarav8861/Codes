#include <iostream>
using namespace std;
#include <unordered_map>
#include <vector>

vector <int> longestConsecutiveIncreasingSequence(int *arr, int n)
{
    // Your Code goes here
    unordered_map<int, bool> m;
    
    for (int i = 0; i < n; i++)
    {
        m[arr[i]] = true;
    }
    int ans = 0 ;
    int start = 0;
    
    // check each possible sequenece from start
    // the update the optimal length
    for (int i = 0; i < n; i++)
    {
        // if current element is the starting element of sequence
        if(m[arr[i]-1]==false)
        {
            // Then check for next element in the sequence
            int j = arr[i];
            while (m[j]==true)
            {
                j++;
            }
            
            // update optimal length if this length is more
            if((j - arr[i])>ans)
            {
                start = arr[i];
                ans = j - arr[i];
            }
            // ans= max(ans, j-arr[i]);
        }
    }
    vector<int> v ;
    v.push_back(start);
    v.push_back(start + ans -1);
    return v;
}



int main() {
    int size;
    cin >> size;

    int* arr = new int[size];

    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    vector<int> ans = longestConsecutiveIncreasingSequence(arr, size);

    for (auto i = ans.begin(); i != ans.end(); ++i)
        cout << *i << " ";

    delete[] arr;
}