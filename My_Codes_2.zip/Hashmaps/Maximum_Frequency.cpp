#include <iostream>
using namespace std;
#include <unordered_map>

int maxFreq(int *a,int n)
{
    unordered_map<int,int> m;
    for(int i=0;i<n;i++)
    {
        m[a[i]]++;
    }

    int key=0;
    int value=0;

    for(int i=0;i<n;i++)
    {
        if(m[a[i]]>value)
        {
            key=a[i];
            value=m[a[i]];
        }
    }
    return key;
}

int main()
{
    int arr[]={0,2,5,4,6,8,1,4,7,5,8,6,3,3,2,1,4,7,8,9,5,1,2,2,3,3,5,6,7};
    int n=sizeof(arr)/sizeof(int);

    cout<<"Max Freq: "<<maxFreq(arr,n);
}