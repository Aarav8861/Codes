#include <bits/stdc++.h>

int countSubarrays(int n, vector<int> &arr)
{
    unordered_map<int, int> m;

    int count = 0;

    int sum = 0;

    for (int i = 0; i < n; i++)
    {

        sum += arr[i];

        if (sum == 0)
        {

            count++;
        }
        if (m.find(sum) != m.end())
        {

            count += m[sum];
        }

        m[sum]++;
    }

    return count;
}