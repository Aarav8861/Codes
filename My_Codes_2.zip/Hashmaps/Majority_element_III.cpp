#include <unordered_map>
vector<int> countTheNumber(vector<int> &arr, int n, int k)
{
    // Write your code here.
    vector<int> ans;
    unordered_map<int, int> m;
    for (int i = 0; i < n; i++)
    {
        m[arr[i]]++;
    }
    for (auto i : m)
    {
        if (i.second >= n / k)
        {
            ans.push_back(i.first);
        }
    }
    return ans;
}