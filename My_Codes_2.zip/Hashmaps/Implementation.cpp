#include <iostream>
using namespace std;
#include <string>
template <typename T>
class MapNode
{
public:
    string key;
    T value;
    MapNode *next;

    MapNode(string key, int value)
    {
        this->key = key;
        this->value = value;
        this->next = NULL;
    }

    ~MapNode()
    {
        delete next;
    }
};

template <typename T>
class Map
{
    MapNode<T> **buckets;
    int size;
    int NumBuckets;
    int count;

public:
    Map()
    {
        size = 0;
        NumBuckets = 5;
        count = 0;
        buckets = new MapNode<T> *[NumBuckets];
        for (int i = 0; i < NumBuckets; i++)
        {
            buckets[i] = NULL;
        }
    }
    ~Map()
    {
        for (int i = 0; i < NumBuckets; i++)
        {
            delete buckets[i];
        }
        delete[] buckets;
    }
    int Size()
    {
        return count;
    }

private:
    int getBucketsIndex(string key)
    {
        int hashCode = 0;
        int currentCoeff = 1;

        for (int i = key.length() - 1; i >= 0; i--)
        {
            hashCode += key[i] * currentCoeff;
            hashCode = hashCode % NumBuckets;
            currentCoeff *= 37;
            currentCoeff = currentCoeff % NumBuckets;
        }
        return hashCode % NumBuckets;
    }

    void rehash()
    {
        MapNode<T> **Temp = buckets;
        buckets = new MapNode<T> *[2 * NumBuckets];

        for (int i = 0; i < 2 * NumBuckets; i++)
        {
            buckets[i] = NULL;
        }

        int oldBucketSize = NumBuckets;
        NumBuckets *= 2;
        count = 0;
        for (int i = 0; i < oldBucketSize; i++)
        {
            MapNode<T> *head = Temp[i];
            while (head != NULL)
            {
                string key = head->key;
                T value = head->value;
                Insert(key, value);
                head = head->next;
            }
        }

        for (int i = 0; i < oldBucketSize; i++)
        {
            MapNode<T> *head = Temp[i];
            delete head;
        }
        delete[] Temp;
    }

public:
    double getLoadFactor()
    {
        return (1.0 * count) / NumBuckets;
    }
    void Insert(string key, T value)
    {
        int BucketIndex = getBucketsIndex(key);
        MapNode<T> *head = buckets[BucketIndex];
        MapNode<T> *Temp = head;
        while (Temp = NULL)
        {
            if (Temp->key == key)
            {
                Temp->value = value;
                return;
            }
            Temp = Temp->next;
        }
        MapNode<T> *Node = new MapNode<T>(key, value);
        Node->next = head;
        buckets[BucketIndex] = Node;
        count++;

        double loadFactor = (1.0 * count) / NumBuckets;
        if (loadFactor > 0.7)
        {
            rehash();
        }
    }

    T remove(string key)
    {
        int BucketIndex = getBucketsIndex(key);
        MapNode<T> *head = buckets[BucketIndex];
        MapNode<T> *prev = NULL;
        MapNode<T> *Temp = head;
        while (Temp != NULL)
        {
            if (Temp->key == key)
            {
                if (prev == NULL)
                {
                    buckets[BucketIndex] = head->next;
                }
                else
                {
                    prev->next = Temp->next;
                }
                T value = head->value;
                Temp->next = NULL;
                delete Temp;
                count--;
                return value;
            }

            prev = Temp;
            Temp = Temp->next;
        }
        return 0;
    }

    T search(string key)
    {
        int BucketIndex = getBucketsIndex(key);
        MapNode<T> *head = buckets[BucketIndex];
        MapNode<T> *Temp = head;

        while (Temp != NULL)
        {
            if (Temp->key == key)
            {
                return Temp->value;
            }
            Temp = Temp->next;
        }
        return 0;
    }
};

int main()
{
    Map<int> map;
    for (int i = 0; i < 10; i++)
    {
        char c = '0' + i;
        string key = "abc";
        key = key + c;
        int value = i + 1;
        map.Insert(key, value);
        cout << map.getLoadFactor() << endl;
    }
    cout << map.Size() << endl;
    map.remove("abc2");
    map.remove("abc7");

    cout << map.Size() << endl;
    for (int i = 0; i < 10; i++)
    {
        char c = '0' + i;
        string key = "abc";
        key = key + c;
        cout << key << ":" << map.search(key) << endl;
    }
    cout << map.Size() << endl;
}