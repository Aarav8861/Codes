#include <map>
#include <climits>
int maximumFrequency(vector<int> &arr, int n)
{
    // Write your code here
    map<int, int> m;
    int maxfreq = 0, maxans = 0;
    for (int i = 0; i < n; i++)
    {
        m.insert(make_pair(arr[i], m[arr[i]]++));
        maxfreq = max(maxfreq, m[arr[i]]);
    }
    //     for(auto i :  m)
    //     {
    //         cout << i.first << " " << i.second << endl;
    //     }

    for (int i = 0; i < n; i++)
    {
        if (maxfreq == m[arr[i]])
        {
            return arr[i];
        }
    }
}