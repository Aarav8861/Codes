#include <map>
#include <bits/stdc++.h>
#include <algorithm>
int minSwaps(vector<int> &arr)
{
    // map<int,int>
    // Write your code here.'
    int count = 0;
    int n = arr.size();
    vector<int> arr1(n);

    for (int i = 0; i < n; i++)
    {
        arr1[i] = arr[i];
    }
    sort(arr1.begin(), arr1.end());
    for (int i = 0; i < n; i++)
    {
        auto in = find(arr1.begin(), arr1.end(), arr[i]);
        int index = in - arr1.begin();
        if (index != n)
        {
            swap(arr[index], arr[i]);
            if (arr[index] != arr[i])
            {
                count++;
                i--;
            }
        }
    }
    return count;
}