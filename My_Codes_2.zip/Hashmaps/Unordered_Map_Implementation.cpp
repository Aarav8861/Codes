#include <iostream>
using namespace std;
#include <map> 
#include <unordered_map>
#include <string>

int main()
{

   /* // 1st Way
    map<string, int> m;
    m.insert(make_pair("Apple", 100));

    pair<string, int> p;
    p.first = "Apple";
    p.second = 120;
    m.insert(p);
    m["Banana"] = 20;

    // 2.Search
    string fruit;
    cin >> fruit;

    auto it = m.find(fruit); // it returns an iterator
    if (it != m.end())
    {
        cout << "Price of" << fruit << "is" << m[fruit] << endl;
    }

    else
    {
        cout << "fruit is not present " << endl;
    }

    // upadate the price
    m[fruit] += 20;

    // Erase
    m.erase(fruit);

    // Another way to find a particular key
    // it stores unique keys only once
    if (m.count(fruit)) // It returns an integer value i.e 0 or 1
    {
        cout << "Price is " << m[fruit] << endl;
    }
    else
    {
        cout << "Couldn't find " << endl;
    }

    m["Litchi"] = 60;
    m["Pineapple"] = 80;

    // Iterate over all the key value pairs
    for (auto it = m.begin(); it != m.end(); it++)
    {
        cout << it->first << "and" << it->second << endl;
    }

    // For each loop
    for (auto p : m)
    {
        cout << p.first << ":" << p.second << endl;
    }
*/
    unordered_map<string, int> m;

    // insert
    // 1st way
    pair<string, int> p("abc", 1); // map ko banaya pair se he h
    m.insert(p);

    // 2nd way
    m["def"] = 2;

    // find
    cout << m["abc"] << endl;
    cout << m.at("def") << endl;

    //[] inserts the key if not found and sets the default value as 0
    // at gives error if key is not found

    cout << "size: " << m.size() << endl;
    cout << m["gef"] << endl; // inserts new key as gef and sets the value as 0
    cout << "size: " << m.size() << endl;

    // check presence
    if (m.count("gef") == 1)
    {
        cout << "gef is present" << endl;
    }

    // erase
    // 1st way
    m.erase("gef");
    cout << "size: " << m.size() << endl;

    // 2nd way
    m.erase(m.begin(), m.end());
    cout << "size: " << m.size() << endl;
}