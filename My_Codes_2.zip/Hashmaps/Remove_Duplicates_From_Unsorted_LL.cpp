/****************************************************************
    Following is the class structure of the Node class:
    class Node
    {
    public:
        int data;
        Node *next;
        Node(int data)
        {
            this->data = data;
            this->next = NULL;
        }
    };
*****************************************************************/
#include <unordered_map>

Node *removeDuplicates(Node *head)
{
    // Write your code here
    unordered_map<int, int> m;
    Node *temp = head;
    Node *prev = head;
    while (temp != NULL)
    {
        if (m[temp->data] == 0)
        {
            m[temp->data] = 1;
            prev = temp;
        }
        if (m[temp->data] == 1)
        {
            prev->next = temp->next;
        }
        temp = temp->next;
    }
    return head;
}