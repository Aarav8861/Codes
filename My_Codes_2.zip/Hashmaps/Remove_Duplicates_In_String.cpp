#include <iostream>
using namespace std;
#include <unordered_map>

void RemoveDuplicates(string s)
{
    unordered_map<char, int> m;
    for (int i = 0; i < s.length(); i++)
    {
        m[s[i]]==1;
    }

    for (int i = 0; i < s.length(); i++)
    {
        if (m[s[i]]==1)
        {
            cout<<s[i]<<endl;
        }
    }
}

int main()
{
    string s;
    cin>>s;
    RemoveDuplicates(s);
}