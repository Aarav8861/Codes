#include <map>
string second_repeat(vector<string> &arr, int n)
{
    // Write your code here.
    map<string, int> m;
    for (int i = 0; i < n; i++)
    {
        m[arr[i]]++;
    }
    int maxi = INT_MIN;
    int smaxi = INT_MIN;
    string smaxis;
    string maxis;
    for (auto i : m)
    {
        if (i.second > maxi)
        {
            smaxis = maxis;
            smaxi = maxi;
            maxi = i.second;
            maxis = i.first;
        }
        else if (i.second < maxi && i.second > smaxi)
        {
            smaxis = i.first;
            smaxi = i.second;
        }
    }
    return smaxis;
}