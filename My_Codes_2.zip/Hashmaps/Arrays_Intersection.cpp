#include <iostream>
using namespace std;
#include <unordered_map>

bool present(int *a, int n, int k)
{
    for (int i = 0; i < n; i++)
    {
        if (a[i] == k)
        {
            return true;
        }
    }
    return false;
}

int intersection(int *a, int n1, int *b, int n2)
{
    unordered_map<int, bool> m;
    for (int i = 0; i < n1; i++)
    {
        m[a[i]] = present(b, n2, a[i]);
    }
    int key = 0;
    for (int i = 0; i < n1; i++)
    {
        if (m[a[i]])
        {
            key = a[i];
        }
    }
    for (auto p : m)
    {
        cout << p.first << " " << p.second << endl;
    }

    return key;
}

int main()
{
    int a[] = {1, 2, 3};
    int b[] = {3, 4, 5};
    intersection(a, 3, b, 3);
}