#include <iostream>
using namespace std;
#include <unordered_map>

void intersection(int input1[], int input2[], int size1, int size2)
{
    unordered_map<int, int> m1;

    for (int i = 0; i < size1; i++)
        m1[input1[i]]++;

    for (int i = 0; i < size2; i++)
    {
        if (m1[input2[i]] > 0) // if not present will have default value 0
        {
            cout << input2[i] << endl;
            m1[input2[i]]--; // reduce its occurence by 1;
        }
    }
    for (auto p : m1)
    {
        cout << p.first << " " << p.second << endl;
    }
}

int main()
{
    int a[] = {1, 2, 3};
    int b[] = {3, 4, 5};
    intersection(a, b, 3, 3);
}
