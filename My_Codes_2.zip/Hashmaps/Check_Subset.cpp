
// Check if arr2 is a subset of arr1.

#include <map>
bool checkSubset(vector<int> &arr1, vector<int> &arr2, int n, int m)
{
    // Write your code here.
    if (m > n)
    {
        return false;
    }
    map<int, int> ma;

    for (int i = 0; i < n; i++)
    {
        ma[arr1[i]]++;
    }
    bool b = true;
    for (int i = 0; i < m; i++)
    {
        if (ma.count(arr2[i]) == 0 || ma[arr2[i]] == 0)
        {
            b = false;
            // cout << "ex" << arr2[i] << endl;
            break;
        }
        // cout << ma[arr2[i]] << endl;
        ma[arr2[i]]--;
    }
    return b;
}