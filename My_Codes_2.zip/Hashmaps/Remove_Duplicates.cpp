#include <iostream>
using namespace std;
#include <vector>
#include <unordered_map>

vector<int> removeDupliactes(int *a, int size)
{
    vector<int> v;
    unordered_map<int, bool> m;

    for (int i = 0; i < size; i++)
    {
        if (m.count(a[i]) > 0)
        {
            continue;
        }
        m[a[i]]=true;
        v.push_back(a[i]);
    }
    return v;
}

int main()
{
    int a[]={1,2,3,3,2,1,4,3,6,5,5};
    int n=sizeof(a)/sizeof(int);

    vector<int> v=removeDupliactes(a,n);
    for(int i=0;i<v.size();i++)
    {
        cout<<v[i]<<endl;
    }
}
