#include <iostream>
using namespace std;

template <class T>
class aarav
{
    int a;
    public:
    aarav(int x)
    {
        a=x;
    }
    void display();
};

template <class T>
void aarav<T> :: display()
{
    cout<<a<<endl;
}

void func(int a)
{
    cout<<"normal"<<" "<<a<<endl;  
}

template <class T>
void func(T a)
{
    cout<<"templarized"<<" "<<a<<endl;  
}

int main()
{
    aarav<float> beast(8);
    beast.display();
    func<int>(7); // the one that matches gets higher prirority...
    func(7); // the one that matches gets higher prirority...
    func(7.0); // if none matches then templarized is called..
    return 0;
}