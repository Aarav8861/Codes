#include <iostream>
using namespace std;

/* template <class a, class b>
class name {
    body.....
}*/

template <class T1,class T2>
class myclass
{
    public:
    T1 a;
    T2 b;

    myclass( T1 x,T2 y)
    {
        a=x;
        b=y;
    }

    void display()
    {
        cout<<this->a<<endl<<this->b<<endl;
    }
};

int main()
{
    myclass <int ,char> c(7,'8');
    c.display();
    return 0;
}