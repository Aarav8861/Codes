#include <iostream>
using namespace std;

/* template <class a, class b>
class name {
    body.....
}*/

template <class T1=int,class T2=float>
class myclass
{
    public:
    T1 a;
    T2 b;

    myclass( T1 x,T2 y)
    {
        a=x;
        b=y;
    }

    void display()
    {
        cout<<"the value of a is"<<this->a<<endl;
        cout<<"the value of a is"<<this->b<<endl;
    }
};

int main()
{
    myclass <> c(7,69.69);
    c.display();

    myclass <float,char> d(1.7,'c');
    c.display();
    return 0;
}