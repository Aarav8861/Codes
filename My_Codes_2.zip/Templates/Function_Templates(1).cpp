#include <iostream>
using namespace std;


template <class T1,class T2>
float functemp(T1 a,T2 b)
{
    return (a+b)/2.0;
}


void swap(int &a,int &b)
{
    int temp=a;
    a=b;
    b=temp;
}
int main()
{
   cout<<functemp<float,float>(4.0,4.2);

   int x,y;
   cin>>x>>y;
   swap(x,y);
   cout<<x<<endl<<y<<endl;
    return 0;
}