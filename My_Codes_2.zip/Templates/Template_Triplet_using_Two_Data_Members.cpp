#include <iostream>
using namespace std;

template <class T,class V>
class Pair
{
    T x;
    V y;
    
    public:
    void setX(T x)
    {
        this->x=x;
    }
    T getX()
    {
        return x;
    }
    void setY(V y)
    {
        this->y=y;
    }
    V gety()
    {
        return y;
    }
};
                                                  //   ------------------------------------
int main()                                        //   |        X  p2   |        Y        |
{                                                 //   | -------------- |                 |
    Pair<Pair<int,double>,char> p1;           //p1->   | |   X  |  Y  | |                 |
    p1.setY('c');                                 //   | |------|-----| |                 |
    Pair<int,double>p2;                           //   |                |                 |
    p2.setX(1);                                   //   |----------------|-----------------|
    p2.setY(10.2);
    p1.setX(p2);
    cout<<p1.getX().getX()<<" "<<p1.getX().gety()<<" "<<p1.gety();
}