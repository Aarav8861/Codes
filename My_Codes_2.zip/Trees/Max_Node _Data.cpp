#include <iostream>
#include "Tree_Class.h"
#include <queue>
using namespace std;

TreeNode<int> *takeinput()
{
    int rootData;
    cout << "Enter Data" << endl;
    cin >> rootData;
    TreeNode<int> *root = new TreeNode<int>(rootData);

    queue<TreeNode<int> *> pendingNodes;
    pendingNodes.push(root);

    while (!pendingNodes.empty())
    {
        TreeNode<int> *front = pendingNodes.front();
        pendingNodes.pop();
        int n;
        cout << "Enter the num of children of " << front->data << endl;
        cin >> n;
        for (int i = 0; i < n; i++)
        {
            int childData;
            cout << "Enter " << i << "th child of " << front->data << endl;
            cin >> childData;
            TreeNode<int> *child = new TreeNode<int>(childData);
            front->children.push_back(child);
            pendingNodes.push(child);
        }
    }
    return root;
}
void print(TreeNode<int> *root)
{
    if (root == NULL)
        return;
    queue<TreeNode<int> *> pendingNodes;
    pendingNodes.push(root);
    while (!pendingNodes.empty())
    {
        TreeNode<int> *front = pendingNodes.front();
        cout << front->data << ":";
        pendingNodes.pop();
        for (int i = 0; i < front->children.size(); i++) //sees childs
        {
            if (i == front->children.size() - 1)
            {
                cout << front->children[i]->data;
            }
            else
            {
                cout << front->children[i]->data << ",";
            }
            pendingNodes.push(front->children[i]);
        }
        cout << endl;
    }
}
TreeNode<int>* maxDataNode(TreeNode<int>* root) {
    // Write your code here

     if(root==NULL)
        return NULL;
    TreeNode<int>* max=root;
    
     for(int i=0;i<root->children.size();i++){
        TreeNode<int>* max1= maxDataNode(root->children[i]);
         if(max->data<max1->data)
            max=max1;
         
    }
    return max;
}
int main()
{
    TreeNode<int> *root = takeinput();
    print(root);
    cout<<maxDataNode(root)->data;

}