#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main()
{
    //Syntax
    //vector<data_type> name(size,value)
    vector<int> v;
    v.push_back(1);
    v.push_back(2);
    v.push_back(3);

    //2D vector
    //initialised a grid with -1
    //vector<vector<int>> grid(n,vector<int>(m,-1));


    for(int i=0;i<v.size();i++)
    {
        cout<<v[i]<<endl;
    }
    //iterators
    vector<int>::iterator it;
    for(it=v.begin();it!=v.end();it++)
    {
        cout<<*it<<endl;
    }

    //for  each loop
    for(auto element : v)
    {
        cout<<element<<endl;
    }

    v.pop_back(); //1 2

    vector<int> v2 (3,50);
      for(auto element : v2)
    {
        cout<<element<<endl;
    }//50 50 50

    swap(v,v2);

      for(auto element : v)
    {
        cout<<element<<endl;
    }

      for(auto element : v2)
    {
        cout<<element<<endl;
    }

    sort(v.begin(),v.end());

}
