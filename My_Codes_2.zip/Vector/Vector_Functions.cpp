#include <bits/stdc++.h>
using namespace std;

int main()
{
    vector<int> d{1, 2, 3, 4, 5};
    // Push Back O(1) for most of the time.
    d.push_back(16);

    // Pop Back / Removes the last element O(1)
    d.pop_back();

    // Insert some elements in the middle.
    d.insert(d.begin() + 3, 4, 100);

    // Erase some elements in the middle.
    d.erase(d.begin() + 2);
    d.erase(d.begin() + 2, d.begin() + 5);

    // Size
    cout << d.size() << endl;
    cout << d.capacity() << endl;

    // We avoid the shrink
    d.resize(18); // If size is increasing more memory will be allocated.
    // if elements already present more than the resize size then the fucntion will do nothing.
    cout << d.capacity() << endl;

    // remove all elements of the vector , doesn't delete the memory occupied by the array.
    d.clear(); // Only makes all the entries 0;
    cout << "capacity not changed " << d.capacity() << endl;

    // empty
    if (d.empty())
    {
        cout << "This is an empty vector" << endl;
    }
    cout << d.size() << endl;

    for (int x : d)
    {
        cout << x << ",";
    }
    d.push_back(10);
    d.push_back(11);
    d.push_back(12);
    d.push_back(13);

    cout << d.front() << endl;
    cout << d.back() << endl;

    // Reserve
    int n;
    cin >> n;
    vector<int> v;

    // This takes very much time as the push_back function keeps on doubling the size.
    // Hence we use the reserve function to reserve the size before hand.
    v.reserve(100);
    for (int i = 0; i < n; i++)
    {
        int no;
        cin >> no;
        v.push_back(no);
        cout << "Changing Capacity " << v.capacity() << endl;
    }
    cout << "Capacity " << v.capacity() << endl;
    for (int x : v)
    {
        cout << x << ",";
    }
    cout << endl;
}