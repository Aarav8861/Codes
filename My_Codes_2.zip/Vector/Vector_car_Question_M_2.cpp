#include <bits/stdc++.h>
using namespace std;

class car
{
public:
    int x;
    int y;
    car();
    car(int a, int b)
    {
        this->x = a;
        this->y = b;
    }
};
bool compare(car p1, car p2)
{
    int d1 = p1.x * p1.x + p1.y * p2.y;
    int d2 = p2.x * p2.x + p2.y * p2.y;

    if (d1 == d2)
    {
        return p1.x < p2.x;
    }

    return d1 < d2;
}
int main()
{
    int n;
    cin >> n;
    vector<car> v;
    for (int i = 0; i < n; i++)
    {
        int a, b;
        cin >> a >> b;
        car c(a, b);
        v.push_back(c);
    }
    sort(v.begin(), v.end(), compare);
    for (auto c : v)
    {
        cout << c.x << "," << c.y << endl;
    }
    return 0;
}