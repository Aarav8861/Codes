#include <iostream>
using namespace std;
int main()
{
    char ch ='a';
    char *cptr=&ch;
    cout<<cptr<<"\n";
    cptr++;
    cout<<cptr<<"\n";
    return 0;
}