#include  <iostream>
using namespace std;
int main()
{
    int a=10;
    int *aptr=&a;
    int **bptr=&aptr;
    cout<<aptr<<"\n";
    cout<<*aptr<<"\n"; 
    cout<<bptr<<"\n";
    cout<<*bptr<<"\n";
    cout<<**bptr<<"\n";
    return 0;
}
