#include <iostream>
using namespace std;
int main()
{
    int i=10;
    int * p=&i;
    cout<<p<<endl;
    cout<<*p<<endl;
    /**p++; // starts pointing towards the next integer 
    cout<<p<<endl; // next integer address
    cout<<*p<<endl; // garbage value at that address*/
    /**++p;
    cout<<p<<endl;
    cout<<*p<<endl;*/
    int a=++*p;
    cout<<a<<endl;
    cout<<p<<endl;
    cout<<*p<<endl;
    a=(*p)++;
    cout<<a<<endl;
    cout<<p<<endl;
    cout<<*p<<endl;
    return 0;
}