#include  <iostream>
using namespace std;
void swap(int *a,int *b)
{
    int temp;
    temp=*a;
    *a=*b;
    *b=temp;
}
int main()
{
    int a,b;
    int *ptr1=&a;
    int *ptr2=&b;
    cin>>a>>b;
    swap(ptr1,ptr2);
    cout<<a<<b;
    return 0;
}