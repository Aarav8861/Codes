#include <iostream>
using namespace std;

int main()
{
    int a=10;
    int *aptr;
    aptr=&a;
    cout<<&a<<"\n";
    cout<<aptr<<"\n";
    cout<<*aptr<<"\n";
    return 0;
}
