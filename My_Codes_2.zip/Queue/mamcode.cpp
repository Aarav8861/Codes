/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <queue>
#include <stack>
#include <string>
using namespace std;

int main()
{
    int arr[26] = {0};
    string s;
    cin >> s;

    queue<char> q;
    for (int i = 0; i < s.size(); i++)
    {
        arr[s[i] - 97]++;
        if (arr[i] == 1)
        {
            q.push(s[i]);
        }
        /*else if (arr[i] > 1)
        {
            q.push('-1');
        }*/
    }
    while (!q.empty())
    {
        cout << q.front();
        q.pop();
    }

    return 0;
}
