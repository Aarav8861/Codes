#include <iostream>
#include <list>
using namespace std;

class queue
{
private:
    int cs;
    list<int> l;

public:
    void push(int data)
    {
        l.push_back(data);
        cs++;
    }
    void pop()
    {
        if (!isempty())
        {
            l.pop_front();
            cs--;
        }
    }
    bool isempty()
    {
        return cs == 0;
    }
    int front()
    {
        return l.front();
    }
};

int main()
{
}