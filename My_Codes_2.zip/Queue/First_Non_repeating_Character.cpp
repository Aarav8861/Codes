#include <iostream>
#include <map>
#include <queue>
using namespace std;

int main()
{
    char ch;
    cin >> ch;
    queue<char> q;
    map<char, int> m;
    while (ch != '.')
    {
        if (m.count(ch))
        {
            m[ch]++;
        }
        else
            m.insert(make_pair(ch, 1));
        q.push(ch);
        while (!q.empty())
        {
            if (m[q.front()] == 1)
            {
                cout << q.front() << endl;
                break;
            }
            else
            {
                q.pop();
            }
        }
        if (q.empty())
        {
            cout << "-1" << endl;
        }
        cin >> ch;
    }
}
