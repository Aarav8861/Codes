#include <iostream>
using namespace std;

class student
{
    protected:
    int roll_number;
    public:
    void set_roll_number(int a)
    {
        roll_number=a;
    }

    void get_roll_number()
    {
        cout<<"Your roll number is "<<roll_number<<endl;
    }
};

class test:virtual public student
{
    protected :
    float maths;
    float physics;

    public:
    int set_marks (int m1,int m2)
    {
        maths=m1;
        physics=m2;
    }

    void get_marks()
    {
        cout<<"Maths marks are "<<maths<<endl;
        cout<<"Physics marks are "<<physics<<endl;
    }
};
class sports:virtual public student
{
    protected :
    float score;

    public:
    int set_score (int sc)
    {
        score=sc;
    }

    void get_score()
    {
        cout<<"scores are "<<score<<endl;
    }
};

class result : virtual public test,public sports
{
    protected:
    float total;

    public:
    void display()
    {
        total=maths+physics+score;
        get_roll_number();
        get_marks();
        get_score();
        cout<<"Your total marks are "<<total<<endl;
    }
};

int main()
{
    result aarav;
    aarav.set_roll_number(1);
    aarav.set_marks(100,100);
    aarav.set_score(100);
    aarav.display();
    return 0;

}