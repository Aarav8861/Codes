#include <iostream>
using namespace std;

class base1
{
    public:
    void greet()
    {
        cout<<"How are you"<<endl;
    }
};

class base2
{
    public:
    void greet();
};

void base2::greet()
{
    cout<<"Badiya huan tu suna";
}

class derived : public base1,public base2
{
    public:
    void greet()
    {
        base2 :: greet();
    }

};

/*int main()
{
    base1 b1;
    b1.greet();
    base2 b2;
    b2.greet();
    derived d;
    d.greet();
    return 0;
}*/

class b
{
    public:
    void say()
    {
        cout<<"Hello world"<<endl;
    }
};

class d : public b
{
    public : 
    void say()  // agar derived class mein pahle se he h toh voh override kaar dega base class vale ko....
    {
        cout<<"Hey there"<<endl;
    }
};

int main()
{
    d d;
    d.say();
    d.b::say();
    return 0;
}