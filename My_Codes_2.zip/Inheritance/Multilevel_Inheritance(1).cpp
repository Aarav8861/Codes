#include <iostream>
using namespace std;

class student
{
    protected:
    int roll_number;
    public:
    void set_roll_number(int);
    void get_roll_no();
};

void student :: set_roll_number(int r)
{
    roll_number=r;
}
void student::get_roll_no()
{
    cout<<"Roll no of the student is "<<roll_number<<endl;
}

class exam : public  student
{
    protected :
    float maths;
    float physics;
    public:

    void set_marks(float,float);
    void get_marks();
};

void exam :: set_marks(float m1,float m2)
{
    maths =m1;
    physics=m2;
}
void exam ::get_marks()
{
    cout<<"Marks of student in maths are "<<maths<<endl;
    cout<<"Marks of student in physics are "<<physics<<endl;
}

class result:public exam
{
    public:
    void get_result()
    {
        get_roll_no();
        cout<<"Percentage of student is "<<(maths+physics)/2<<endl;
    }
};

int main()
{
    result aarav;
    aarav.set_roll_number(1);
    aarav.set_marks(100,100);
    aarav.get_result();
    return 0;
}