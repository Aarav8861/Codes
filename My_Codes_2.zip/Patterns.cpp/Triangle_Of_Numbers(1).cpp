#include <iostream>
using namespace std;

int main()
{
    int n;
    cin>>n;
    int i=1;
    while(i<=n)
    {
        int spaces=1;
        while(spaces<=n-i)
        {
            cout<<" ";
            spaces++;
        }
        int j=1;
        int var=i;
        while(j<=i)
        {
            cout<<var;
            j++;
            var++;
        }
        int k=2*i-2;
        int r=1;
        while(r<=i-1)
        {
            cout<<k;
            k--;
            r++;
        }
        cout<<endl;
        i++;
        }
}