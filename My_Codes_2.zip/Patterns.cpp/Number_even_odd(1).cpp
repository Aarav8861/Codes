#include<iostream>
using namespace std;

int main()
{
    int n;
    cin>>n;
    
    int i=1;
    while(i<=n)
    {
        if(i%2==0)
        {
            int j=(n-i)+1;
            while(j>=1)
            {
                cout<<j;
                j--;
            }
        }
        else
        {
            int j=1;
            while(j<=(n-i)+1)
            {
                cout<<j;
                j++;
            }
        }
        cout<<endl;
        i++;
    }
}