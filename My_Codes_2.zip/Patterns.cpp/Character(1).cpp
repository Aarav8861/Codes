#include<iostream>
using namespace std;


int main()
{
    int n;
    cin>>n;
    int i=1;
    while(i<=n)
    {
        int j=1;
        char var=i+64;
        while(j<=i)
        {
            cout<<var;
            var++;
            j++;
        }
        cout<<endl;
        i++;
    }
}
