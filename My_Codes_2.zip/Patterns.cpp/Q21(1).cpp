#include<iostream>
using namespace std;

int main()
{
    int n;
    cin>>n;
    int i=1;
    int k=((n*(n+1))/2);
    while(i<=n)
    {
        
        int j=1;
        {
            int var=n-1;
            int q=i;
            while(j<=i)
            {
                cout<<q<<" ";
                q=q+var;
                j++;
                var--;
                
            }
        }
        cout<<endl;
        i++;
    }
}
