#include<iostream>
using namespace std;

int main()
{
    int n;
    cin>>n;
    int i=1;
    while(i<=n)
    {
        int j=1;
        while(j<=i)
        {
            if(j%2==0)
            {
                cout<<"0";
                j++;
            }
            else
            {
                cout<<"1";
                j++;
            }
        }
        cout<<endl;
        i++;
    }
}
