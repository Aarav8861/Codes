/*#include<iostream>
using namespace std;

int main()
{
	int n;
	cin>>n;
	int i=1;
	while(i<=n)
	{
		if(i==1 || i==n)
		{
			int j=1;
			while(j<=n)
			{
				cout<<"*";
				j++;
			}
		}

		else
		{
			int spaces=1;
			while(spaces<=n-i)
			{
				cout<<" ";
				spaces++;
			}
			int star=1;
			while(star<=1)
			{
				cout<<"*";
                star++;
			}
			spaces=(n-i)+1;
			while(spaces<=n)
			{
				cout<<" ";
				spaces++;
			}
		}
		cout<<endl;
		i++;
	}
}*/








#include<iostream>
using namespace std;

int main()
{
    int n;
    cin>>n;
    int i=1;
    while(i<=n)
    {
        if(i==1 || i==n)
        {
            int j=1;
            while(j<=(3*n)+1)
            {
                cout<<"*";
                j++;
            }
        }

        else
        {
            int spaces =1;
            while(spaces<=i-1)
            {
                cout<<" ";
                spaces++;
            }
            int j=1;
            while(j<=1)
            {
                cout<<"*";
                j++;
            }
        }
        cout<<endl;
        i++;
    }
}