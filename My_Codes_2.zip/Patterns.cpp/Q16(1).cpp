#include<iostream>
using namespace std;

int main()
{
    int n;
    cin>>n;
    int i=1;
    while(i<=n)
    {
        int j=1;
        int var=(2*i)-1;
        while(j<=(n-i)+1)
        {
            cout<<var;
            var+=2;
            j++;
        }
        
        cout<<endl;
        i++;
    }
}
