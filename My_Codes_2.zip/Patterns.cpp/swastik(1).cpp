#include <iostream>
using namespace std;

int main() 
{
    int n;
    cin>>n;
    int k=(n+1)/2;
    
    int i=1;
    while(i<=k)
    {
        if(i==1)
        {
            int j=1;
            while(j<=1)
            {
                cout<<"*";
                j++;
            }
            int spaces =1;
            while(spaces<=k/2)
            {
                cout<<" ";
                spaces++;
            }
            j=1;
            while(j<=k)
            {
                cout<<"*";
                j++;
            }
        }
        else if(i==k)
        {
            int j=1;
            while(j<=n)
            {
                cout<<"*";
                j++;
            }
        }
        else 
        {
            int j=1;
            while(j<=1)
            {
                cout<<"*";
                j++;
            }
            int spaces =1;
            while(spaces<=k/2)
            {
                cout<<" ";
                spaces++;
            }
            j=1;
            while(j<=1)
            {
                cout<<"*";
                j++;
            }
        }
     cout<<endl;
     i++;
    }
    int q=1;
        while(q<=k-1)
        {
            if(q==k-1)
            {
                int j=1;
            while(j<=k)
            {
                cout<<"*";
                j++;
            }
            int spaces =1;
            while(spaces<=k/2)
            {
                cout<<" ";
                spaces++;
            }
                j=1;
            while(j<=1)
            {
                cout<<"*";
                j++;
            }
            }
            else
            {
                int spaces =1;
            while(spaces<=k-1)
            {
                cout<<" ";
                spaces++;
            }
               int j=1;
            while(j<=1)
            {
                cout<<"*";
                j++;
            }
                 spaces =1;
            while(spaces<=k/2)
            {
                cout<<" ";
                spaces++;
            }
                 j=1;
            while(j<=1)
            {
                cout<<"*";
                j++;
            }

            }
            cout<<endl;
            q++;
        }
	return 0;
}