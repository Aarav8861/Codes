#include <iostream>
#include <string>
using namespace std;

class cwh
{
protected:
    string title;
    float rating;

public:
    cwh(string s, float r)
    {
        title = s;
        rating = r;
    }

    virtual void display()
    {
        cout << "null" << endl;
    }
};

class cwhvideos : public cwh
{
public:
    float videolength;
    cwhvideos(string s, float r, float vdl) : cwh(s, r)
    {
        videolength = vdl;
    }
    void display()
    {
        cout << "these are best videos\n";
        cout << "Title:" << title << endl;
        cout << "videolength:" << videolength << "minutes" << endl;
        cout << "rating:" << rating << "out of 5 stars\n\n\n"
             << endl;
    }
};

class cwhtext : public cwh
{
public:
    int words;
    cwhtext(string s, float r, int w) : cwh(s, r)
    {
        words = w;
    }
    void display()
    {
        cout << "these are best videos\n";
        cout << "Title:" << title << endl;
        cout << "Word count:" << words << "words" << endl;
        cout << "rating:" << rating << "out of 5 stars\n\n\n"
             << endl;
    }
};

int main()
{
    cwhvideos video("C++", 4.8, 4.6);
    video.display();
    cwhtext text("c++", 4.2, 433);
    text.display();

    cwh *pointer;
    pointer = &video;
    pointer->display();
    pointer = &text; // we cannot initialise constructor here...
    pointer->display();

    return 0;
}