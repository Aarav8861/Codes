#include <iostream>
using namespace std;

class base{
    public:
    int var_base;
    void display()
    {
        cout<<" base class called\n"<<var_base<<endl;
    }
};

    class derived:public base
    {
        public:
        int var_derived;
        void display()
        {
            cout<<"derived class ki base vali value called\n"<<var_base<<endl;
            cout<<"derived called\n"<<var_derived<<endl;
        }
    };

    int main()
    {
        base *base_class_pointer;
        base obj_base;
        derived obj_derived;
        base_class_pointer = &obj_derived;
        base_class_pointer->var_base=2;

        //base_class_pointer->var_derived;
        base_class_pointer->display();


        derived * derived_class_pointer;
        derived_class_pointer=&obj_derived;

        derived_class_pointer->var_base=3;
        derived_class_pointer->var_derived=4;
        derived_class_pointer->display();
        return 0;

    }
