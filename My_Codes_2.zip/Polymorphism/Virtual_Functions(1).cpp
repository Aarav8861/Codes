#include <iostream>
using namespace std;

class base
{
    public:
    int var_base=4;
    virtual void display()
    {
        cout<<"base is called\n"<<var_base<<endl;
    }
};

class derived:public base{
    public:
    int var_derived=44;
    void display()
    {
        cout<<" derived vala base is called\n"<<var_base<<endl;
        cout<<"derived is called\n"<<var_derived<<endl;
    }
};
int main()
{
    base *base_class_pointer;
    base obj1;
    derived obj2;
    base_class_pointer=&obj2;
       //cannot input values outside the class....
    base_class_pointer->var_base=6;
    base_class_pointer->display();

    return 0;
}