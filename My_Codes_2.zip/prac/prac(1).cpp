#include <iostream>
using namespace std;


class shape
{
    protected:
    int x;
    int y;

    public:
    shape(int i,int j)
    {
        this->x=i;
        this->y=j;
    }

   virtual void displayArea()=0;
};


class rectangle : public shape
{
    public:
    rectangle(int a,int b):shape(a,b)
    {
    }

    void displayArea()
    {
        cout<<"Area of reactangle is"<<x*y;
    }

};
class triangle : public shape
{
    public:
    triangle(int a,int b):shape(a,b)
    {
    }

    void displayArea()
    {
        cout<<"Area of triangle is"<<(x*y)/2;
    }
};
class circle: public shape
{
    public:
    circle(int a,int b=0):shape(a,b)
    {
    }

    void displayArea()
    {
        cout<<"Area of reactangle is"<<3.14*x*x;
    }
};

int main()
{
    rectangle r(2,4);
    shape *s=&r;

    s->displayArea();
return 0;
}