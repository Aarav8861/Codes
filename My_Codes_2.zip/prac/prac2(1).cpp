#include <iostream>
#include <string>
using namespace std;

class ticketbooking
{
    string name;
    string walletnumber;
    string creditcard;
    string ccv;
    double amount;

public:
    void setname(string n)
    {
        this->name = n;
    }
    void setwalletnumber(string w)
    {
        this->walletnumber = w;
    }
    void setcreditcard(string cc)
    {
        this->creditcard = cc;
    }
    void setccv(string c)
    {
        this->ccv = c;
    }
    void setamount(double a)
    {
        this->amount = a;
    }

    void makepayment(double amounts)
    {
        cout << "Payment made using cash" << amount << endl;
    }
    void makepayment(string walletnumbers, double amounts)
    {
        cout << "Payment made using wallet number" << walletnumber << "And amount is : " << amount << endl;
    }
    void makepayment(string creditcards, string c, string name, double amounts)
    {
        cout << "Payent made using creditcard having number" << c << "And your amount is : " << amount << endl;
    }
};
int main()
{
    /* ticketbooking t;
    char choice;
    int amt;
    string walletnumber;
    string cn = {0};
    string creditcardnumber;
    string name;
    cout << "Press \n";
    cout << "1 for cash payment\n";
    cout << "2 for wallet number\n";
    cout << "3 for credit card\n";

    cin >> choice;

    switch (choice)
    {
    case 1:
    {
        cout << "Enter the amount\n";
        cin >> amt;
        t.setamount(amt);
        t.makepayment(amt);
        break;
    }
    case 2:
    {
        cout << "Enter the wallet number\n";
        cin >> walletnumber;
        cout << "Enter the amount\n";
        cin >> amt;
        t.setamount(amt);
        t.setwalletnumber(walletnumber);
        t.makepayment(walletnumber, amt);
        break;
    }
    case 3:
    {
        cout << "Enter the wallet number\n";
        cin >> creditcardnumber;
        cout << "Enter the name\n";
        cin >> name;
        cout << "Enter the amount\n";
        cin >> amt;
        t.setamount(amt);
        t.makepayment(cn, creditcardnumber, name, amt);
        break;
    }
    }*/
    int n;
    double amt;
    string str, str1, nm;
    ticketbooking t;
    cout << "Payment methods\n";
    cout << "1.Cash payment\n";
    cout << "2.Wallet payment\n";
    cout << "3.Credit card payment\n";
    cout << "Enter your option:\n";
    cin >> n;
    switch (n)
    {
    case 1:
    {
        cout << "Enter the amount :\n";
        cin >> amt;
        t.setamount(amt);
        t.makepayment(amt);
        break;
    }
    case 2:
    {
        cout << "Enter the amount :\n";
        cin >> amt;
        cout << "Enter the wallet number:\n";
        cin >> str;
        t.setamount(amt);
        t.setwalletnumber(str);
        t.makepayment(str, amt);
        break;
    }
    case 3:
    {
        cout << "Enter the amount :\n";
        cin >> amt;
        cout << "Enter the credit card number:\n";
        cin >> str;
        cout << "Enter the ccv number:\n";
        cin >> str1;
        cout << "Enter name:\n";
        cin >> nm;
        t.setamount(amt);
        ;
        t.setcreditcard(str);
        t.setccv(str1);
        t.setname(nm);
        t.makepayment(str, str1, nm, amt);
    }
    }

    return 0;
}