#include <iostream>
#include <string>
using namespace std;

class Student
{
    protected:
    string name;
    string address;
    char grade;
    string nameofschool;
    
    public:
    Student(string a,string b,char c,string d)
    {
        this->name=a;
        this->address=b;
        this->grade=c;
        this->nameofschool=d;
    }

    void display()
    {
        cout<<"Name : "<<name<<"\n";
        cout<<"Address : "<<address<<"\n";
        cout<<"Grade : "<<grade<<"\n";
        cout<<"Name of school : "<<nameofschool<<"\n";
    }

};

class ScienceStudent:public Student
{
    protected:
    int scienceMarks;
    string scienceName;
    string practSchedule;

    public:
    ScienceStudent(string a,string b,char c,string d,int s,string sc,string p):Student(a,b,c,d)
    {
        this->scienceMarks=s;
        this->scienceName=sc;
        this->practSchedule=p;
    }

    void display()
    {
        cout<<"ScienceMarks : "<<scienceMarks<<"\n";
        cout<<"science name : "<<scienceName<<"\n";
        cout<<"Practical schedule : "<<practSchedule<<"\n";
    }
};

class GUScienceStudent:public ScienceStudent
{
    string scienceProjectDetails;
    string guideName;
    string subjectsOpted;

    public:
    GUScienceStudent();
    GUScienceStudent(string a,string b,char c,string d,int s,string sc,string p,string pd,string gn,string so):ScienceStudent(a,b,c,d,s,sc,p)
    {

        this->scienceProjectDetails=pd;
        this->guideName=gn;
        this->subjectsOpted=so;
    }

    void display()
    {

        Student :: display();
        ScienceStudent :: display();
        cout<<"Science Project Details : "<<scienceProjectDetails<<"\n";
        cout<<"Guide Name : "<<guideName<<"\n";
        cout<<"Subjects Opted : "<<subjectsOpted<<"\n";

    }
};

int main()
{

    GUScienceStudent gu("Aarav","246",'A',"Heritage school Jammu",100,"bio","FridayAN,4hours","Cloning","Kumari","Genetics,Bioinformatics");
    gu.display();
return 0;
}