#include <iostream>
using namespace std;

int divisible(int n,int a,int b)
{
    int c,c1,c2;
    c=n/a;
    c1=n/b;
    c2=n/(a*b);
    return c+c1-c2;
}
int main()
{
    int n,a,b;
    cin>>n>>a>>b;
   cout<<divisible( n,a,b);
    return 0;
}