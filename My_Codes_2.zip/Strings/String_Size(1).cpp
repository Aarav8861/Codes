#include <iostream>
using namespace std;
#include <algorithm>
#include <string>

int main()
{
    string s1;
    s1="aarav is beast";
    cout<<s1.size();//terminator /0 is also included
    return 0;
}