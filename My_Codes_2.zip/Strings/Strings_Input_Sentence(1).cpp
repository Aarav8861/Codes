#include <iostream>
using namespace std;
#include <string>

int main()
{

string str;
getline(cin,str);
cout<<str;
return 0;
}
