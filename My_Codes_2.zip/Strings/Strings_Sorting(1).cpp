#include <iostream>
using namespace std;
#include <algorithm>
#include <string>

int main()
{
    string s1="seventyfive";
    sort(s1.begin(),s1.end());
    cout<<s1<<"\n";
    return 0;
}