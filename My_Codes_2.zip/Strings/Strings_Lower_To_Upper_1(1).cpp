#include <iostream>
using namespace std;
#include <string>

int main()
{
    string str = " aarav is beast";
    cout<<'a'-'A'<<endl;
    for(int i=0;i<=str.length();i++)
    {
        if(str[i]>='a' && str[i]<='z')
        {
            str[i]=str[i]-32;
        }
    }
    cout<<str;
    return 0;
}