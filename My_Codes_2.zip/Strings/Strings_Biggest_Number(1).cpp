#include <iostream>
using namespace std;
#include <algorithm>
#include <string>

int main()
{
    string s1="4572";
    sort(s1.begin(),s1.end(),greater<int>());
    cout<<s1<<"\n";
    return 0;
}