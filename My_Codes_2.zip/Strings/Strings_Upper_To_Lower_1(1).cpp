#include <iostream>
using namespace std;
#include <string>

int main()
{
    string str = " AARAV IS beast";
    cout<<'A'-'a'<<endl;
    for(int i=0;i<=str.length();i++)
    {
        if(str[i]>='A' && str[i]<='Z')
        {
            str[i]=str[i]+32;
        }
    }
    cout<<str;
    return 0;
}