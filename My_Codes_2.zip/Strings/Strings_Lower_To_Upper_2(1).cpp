#include <iostream>
using namespace std;
#include <algorithm>
#include <string>

int main()
{
    string str = "aarav is BEAST";
    transform(str.begin(),str.end(),str.begin(),::toupper);
    cout<<str;
    return 0;
}