#include <iostream>
#include <cstring>
using namespace std;

void printSubstrings(char input[])
{
    // Write your code here
    int len = strlen(input);
    for (int k = 0; k < len; k++)
    {
        for (int i = k; i < len; i++)
        {
            for (int j = k; j <= i; j++)
            {
                cout << input[j];
            }
            cout << endl;
        }
    }
}

int main()
{
    int size = 1e6;
    char str[size];
    cin >> str;
    printSubstrings(str);
}