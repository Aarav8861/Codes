#include <iostream>
using namespace std;
#include <string>

int main()
{

string str;
cin>>str;
cout<<str;
return 0;
}
