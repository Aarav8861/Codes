#include <iostream>
using namespace std;
#include <algorithm>
#include <string>

int main()
{
    string s1,s2;
    s1="aarav is beast";
    s2="aarav";
    s1.clear();
    if(s1.empty());
    cout<<"string is empty\n";
    if(s2.empty());
    cout<<"string is not empty\n";
    return 0;
}