#include <iostream>
using namespace std;
#include <string>

int main()
{
    string str(5,'a');
    cout<<str;
    return 0;
}