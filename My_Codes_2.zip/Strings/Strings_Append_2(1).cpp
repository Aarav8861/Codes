#include <iostream>
using namespace std;
#include <algorithm>
#include <string>

int main()
{
    string s1,s2;
    s1="aa";
    s2="rav";
    cout<<s1+s2;
    //s1=s1+s2;
    //cout<<s1;
    return 0;
}