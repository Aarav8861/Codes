#include <iostream>
using namespace std;
#include <algorithm>
#include <string>

int main()
{
    string s1;
    s1 = "aarav is beast";
    s1.insert(8, " the");
    cout << s1;
    return 0;
}