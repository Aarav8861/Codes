#include <iostream>
using namespace std;
#include <algorithm>
#include <string>

int main()
{
    string s1;
    s1="1";
    int x;
    x=stoi(s1);
    cout<<x+2<<"\n";
    return 0;
}