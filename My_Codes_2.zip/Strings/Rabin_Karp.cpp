#include <map>
#include <string>
vector<int> stringMatch(string &str, string &pat)
{
    vector<int> v;
    int n = pat.size();
    for (int i = 0; i < str.size(); i++)
    {
        bool b = true;
        if (str[i] == pat[0])
        {
            if (str.substr(i, n) == pat)
            {
                v.push_back(i);
            }
        }
    }
    return v;
}
