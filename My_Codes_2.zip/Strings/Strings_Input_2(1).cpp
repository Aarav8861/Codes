#include <iostream>
using namespace std;
#include <string>

int main()
{
    string str = " aarav is beast";
    cout<<str;
    return 0;
}