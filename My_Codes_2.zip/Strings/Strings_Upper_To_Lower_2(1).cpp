#include <iostream>
using namespace std;
#include <algorithm>
#include <string>

int main()
{
    string str = " AARAV IS BEAST";
    transform(str.begin(),str.end(),str.begin(),::tolower);
    cout<<str;
    return 0;
}