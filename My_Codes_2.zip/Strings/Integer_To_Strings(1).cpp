#include <iostream>
using namespace std;
#include <algorithm>
#include <string>

int main()
{
    string s1;
    int x=1;
    s1=to_string(x);
    cout<<s1+"2"<<"\n";
    return 0;
}