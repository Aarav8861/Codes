#include <iostream>
using namespace std;
#include <algorithm>
#include <string>

int main()
{
    string s1, s2;
    getline(cin, s1);
    getline(cin, s2);
    cout << s1.compare(s2); // compare means minus
    if (s1.compare(s2) == 0)
        cout << "strings are equal";
    else if (s1.compare(s2) < 0)
        cout << "string s2 is greater";
    else
        cout << "string s1 is greater";
    return 0;
}