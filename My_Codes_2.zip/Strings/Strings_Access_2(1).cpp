#include <iostream>
using namespace std;
#include <algorithm>
#include <string>

int main()
{
    string s1;
    s1="aarav is beast";
    for (int i = 0; i <=s1.size(); i++)
    {
        cout<<s1[i];
    }
    return 0; 
}