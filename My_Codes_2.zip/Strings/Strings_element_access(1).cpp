#include <iostream>
using namespace std;
#include <algorithm>
#include <string>

int main()
{
    string s1;
    s1="aarav";
    cout<<s1[0];
    return 0;
}