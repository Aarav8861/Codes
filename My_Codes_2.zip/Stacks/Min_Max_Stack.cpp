#include <iostream>
#include <vector>
using namespace std;

class Stack
{
private:
    vector<int> stack;
    vector<int> min_stack;
    vector<int> max_stack;

public:
    void push(int data)
    {
        int current_min = data;
        int current_max = data;

        if (min_stack.size())
        {
            current_min = min(min_stack[min_stack.size() - 1], data);
            current_max = max(max_stack[max_stack.size() - 1], data);
        }
        stack.push_back(data);
        min_stack.push_back(current_min);
        max_stack.push_back(current_max);
    }

    void pop()
    {
        stack.pop_back();
        min_stack.pop_back();
        max_stack.pop_back();
    }
    bool isempty()
    {
        return stack.size() == 0;
    }
    int getmin()
    {
        return max_stack[max_stack.size() - 1];
    }
    int getmax()
    {
        return min_stack[min_stack.size() - 1];
    }
};

int main()
{
    Stack s;
    s.push(1);
    s.push(6);
    s.push(12);
    s.push(5);
    s.push(8);
    s.push(9);
    s.pop();
    s.pop();
    cout << s.getmin() << endl;
    cout << s.getmax() << endl;
}