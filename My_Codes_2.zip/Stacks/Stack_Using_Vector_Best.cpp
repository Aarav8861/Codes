#include <bits/stdc++.h>
using namespace std;

class Stack
{
private:
    vector<int> v;

public:
    void push(int element)
    {
        v.push_back(element);
    }
    void pop()
    {
        if (!isempty())
            v.pop_back();
    }
    int top()
    {
        return v[v.size() - 1];
    }
    bool isempty()
    {
        return v.size() == 0;
    }
};

int main()
{
    Stack s1;
    for (int i = 0; i < 5; i++)
        s1.push(i * i);
    while (!s1.isempty())
    {
        cout << s1.top() << endl;
        s1.pop();
    }
    return 0;
}