#include <iostream>
using namespace std;
#include <queue>
class Stack
{
    int size;
    queue<int> q1;
    queue<int> q2;

public:
    Stack()
    {
        size = 0;
    }

    void push(int val)
    {
        q2.push(val);
        size++;
        while (!q1.empty())
        {
            q2.push(q1.front());
            q1.pop();
        }

        queue<int> temp = q1;
        q1 = q2;
        q2 = temp;
    }

    int pop()
    {
        int n = q1.front();
        q1.pop();
        size--;
        return n;
    }
    int top()
    {
        return q1.front();
    }
    int Size()
    {
        return size;
    }
    bool empty()
    {
        return size == 0;
    }
};

int main()
{
    Stack s1;
    s1.push(1);
    s1.push(2);
    s1.push(3);
    s1.push(4);
    s1.push(5);

    cout << s1.pop() << endl;
    cout << s1.pop() << endl;
    cout << s1.Size() << endl;
    cout << s1.empty() << endl;
}