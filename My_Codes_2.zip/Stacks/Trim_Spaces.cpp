#include <iostream>
#include <cstring>
using namespace std;
#include <stack>
void trimSpaces(char input[])
{
    stack<char> s;
    for(int i=0;input[i]!='\0';i++)
    {
        if(input[i] != ' ')
        {
            s.push(input[i]);
        }
    }
    s.push('\0');
    int i=0;
    stack<char> q;
    while(!s.empty())
    {
        q.push(s.top());
        s.pop();
    }
    int n =q.size();
    while(!q.empty())
    {
        input[i]=q.top();
        q.pop();
        i++;
    }
    
}


int main() {
    char input[1000000];
    cin.getline(input, 1000000);
    trimSpaces(input);
    cout << input << endl;
}

