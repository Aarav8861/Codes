#include <iostream>
using namespace std;
#include <stack>

int rain_water(int *a, int n)
{
    stack<int> st;
    int ans=0;
    for (int i = 0; i < n; i++)
    {
        while (!st.empty() && a[st.top() < a[i]])
        {
            int curr = st.top();
            st.pop();
            if (st.empty())
            {
                break;
            }
            int diff = i - st.top() - 1;
            ans += (min(a[st.top()], a[i]) - a[curr]) * diff;
        }
        st.push(i);
    }
    return ans;
}

int main()
{
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    cout<<rain_water(arr,n);
}
