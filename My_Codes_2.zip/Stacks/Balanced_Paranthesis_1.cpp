#include <bits/stdc++.h>
using namespace std;

bool isvalid(char *s)
{
    stack<char> st;
    for (int i = 0; s[i] != '\0'; i++)
    {
        char c = s[i];
        if (c == '(')
        {
            st.push(c);
        }
        else if (c == ')')
        {
            if (st.empty() || st.top() != '(')
            {
                return false;
            }
            st.pop();
        }
    }
    return st.empty();
}

int main()
{
    char s[] = "((a+b)+(c-d+f))";
    cout << isvalid(s) << endl;
}