#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;
    Node(int data)
    {
        this->data = data;
        this->next = NULL;
    }
};

Node *evenAfterOdd(Node *head)
{
    // write your code here
    if (head == NULL || head->next == NULL)
    {
        return head;
    }
    Node *oddhead = NULL;
    Node *oddtail = NULL;
    Node *evenhead = NULL;
    Node *eventail = NULL;

    Node *temp = head;
    while (temp != NULL)
    {
        if (temp->data % 2 != 0)
        {
            if (oddhead == NULL)
            {
                oddhead = temp;
                oddtail = temp;
            }
            else
            {
                oddtail->next = temp;
                oddtail = temp;
            }
        }
        else
        {
            if (evenhead == NULL)
            {
                evenhead = temp;
                eventail = temp;
            }
            else
            {
                eventail->next = temp;
                eventail = temp;
            }
        }
        temp = temp->next;
    }
    if (oddtail == NULL)
    {
        return evenhead;
    }
    else
    {
        oddtail->next = evenhead;
    }
    if (evenhead != NULL)
    {
        eventail->next = NULL;
    }
    return oddhead;
}
Node *takeinput()
{
    int data;
    cin >> data;
    Node *head = NULL, *tail = NULL;
    while (data != -1)
    {
        Node *newnode = new Node(data);
        if (head == NULL)
        {
            head = newnode;
            tail = newnode;
        }
        else
        {
            tail->next = newnode;
            tail = newnode;
        }
        cin >> data;
    }
    return head;
}

void print(Node *head)
{
    Node *temp = head;
    while (temp != NULL)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        Node *head = takeinput();
        head = evenAfterOdd(head);
        print(head);
    }
    return 0;
}