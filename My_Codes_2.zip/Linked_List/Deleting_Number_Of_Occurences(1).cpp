#include <bits/stdc++.h>
using namespace std;


class Node
{
    public:
        int data;
        Node* next;
};


Node* push(Node* head, int new_data)
{
    Node* new_node = new Node();
    new_node->data = new_data;
    new_node->next = head;
    head = new_node;
    return head;
}


Node* deleteKey(Node *head,int x)
{

    Node *tmp = head;

    while (head->data == x)
    {
        head = head->next;
    }
    while (tmp->next != NULL)
    {
        if (tmp->next->data == x)
        {
            tmp->next = tmp->next->next;
        }
        else
        {
            tmp = tmp->next;
        }
    }
    return head;
}


void printList(Node* node)
{
    while (node->next != NULL)
    {
        cout << node->data << " ";
        node = node->next;
    }
    cout << node->data;
}


int main()
{


    Node* head = NULL;
    head = push(head, 6);
    head = push(head, 3);
    head = push(head, 3);
    head = push(head, 1);
    head = push(head, 8);
    head = push(head, 1);
    head = push(head, 1);
    head = push(head, 1);


    int key = 1 ;

    cout << "Created Linked List:\n ";
    printList(head);


    head = deleteKey(head, key);
    cout << "\nLinked List after Deletion is:\n";

    printList(head);

    return 0;
}