#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;

    Node(int data)
    {
        this->data = data;
        this->next = NULL;
    }
};

void print(Node *&head)
{
    Node *temp = head;
    while (temp != NULL)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}
Node *input(Node *head)
{
    int data;
    cin >> data;
    Node *tail = NULL;
    while (data != -1)
    {
        Node *newNode = new Node(data);
        if (head == NULL)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail->next = newNode;
            tail = newNode;
        }
        cin >> data;
    }
    return head;
}
bool cycledetection(Node *head)
{
    Node *fast = head;
    Node *slow = head;
    while (fast != NULL || fast->next != NULL)
    {
        fast = fast->next->next;
        slow = slow->next;
        if (fast == slow)
        {
            return true;
        }
    }
    return false;
}
Node *Cycleremoval(Node *head)
{
    Node *fast = head;
    Node *slow = head;
    while (fast != NULL || fast->next != NULL)
    {
        fast = fast->next->next;
        slow = slow->next;
        if (fast == slow)
        {
            slow = head;
        }
        Node *prev = NULL;
        while (fast != slow)
        {
            prev = fast;
            fast = fast->next;
            slow = slow->next;
        }
        prev->next = NULL;
        return head;
    }
}
int main()
{
    Node *head = NULL;
    head = input(head);
    print(head);
    int i, data;
    cin >> i >> data;
    print(head);

    return 0;
}