#include <iostream>

using namespace std;

class Node
{
public:
    int data;
    Node *next;

    Node(int data)
    {
        this->data = data;
        this->next = NULL;
    }
};

void print(Node *head)
{
    Node *temp = head;
    while (temp != NULL)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}
Node *input(Node *head)
{
    int data;
    cin >> data;
    Node *tail = NULL;
    while (data != -1)
    {
        Node *newNode = new Node(data);
        if (head == NULL)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail->next = newNode;
            tail = newNode;
        }
        cin >> data;
    }
    return head;
}
Node *deleteNodeRec(Node *head, int pos)
{
    //Write your code here
    if (head == NULL)
    {
        return head;
    }
    if (pos == 0)
    {
        head = head->next;
    }
    else
    {
        Node *x = deleteNodeRec(head->next, pos - 1);
        head->next = x;
    }
    return head;
}
int main()
{
    Node *head = NULL;
    head = input(head);
    print(head);
    int data;
    cin >> data;
    head = deleteNodeRec(head, data);
    print(head);

    return 0;
}