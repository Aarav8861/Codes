#include <iostream>
using namespace std;

struct Node
{
    int data;
    struct Node *next;
};

void linkedlistdisplay(struct Node *ptr)
{
    while (ptr != NULL)
    {
        cout << "Element= " << ptr->data << endl;
        ptr = ptr->next;
    }
}

struct Node *deleting_first_node(struct Node *head)
{
    struct Node *p;
    p = head;
    head = head->next;
    free(p);
    return head;
}

struct Node *deleting_atindex(struct Node *head, int index)
{
    struct Node *p = head;
    int i;
    while (i != index-1)
    {
        p = p->next;
        i++;
    }
    struct Node *q;
    q = p->next;
    p->next = q->next;
    free(q);
    return head;
}

struct Node *deleteing_last(struct Node *head)
{
    int i, j;
    struct Node *p = head;
    struct Node *q = head->next;
    while (q->next != NULL)
    {
        q = q->next;
        p = p->next;
    }

    p->next = NULL;
    free(q);
    return head;
}

struct Node *delete_with_value(struct Node *head, int value)
{
    struct Node *p = head;
    while (p->next->data != value && p->next != NULL)
    {
        p = p->next;
    }
    if (p->next->data == value)
    {
        struct Node *q = p->next;
        p->next = q->next;
        free(q);
    }
    return head;
}

int main()
{
    struct Node *head;
    struct Node *head;
    struct Node *head;
    struct Node *head;
    struct Node *head;
    struct Node *head;
    struct Node *sec;
    struct Node *third;
    struct Node *fourth;
    struct Node *fifth;

    head = (struct Node *)malloc(sizeof(struct Node));
    sec = (struct Node *)malloc(sizeof(struct Node));
    third = (struct Node *)malloc(sizeof(struct Node));
    fourth = (struct Node *)malloc(sizeof(struct Node));
    fifth = (struct Node *)malloc(sizeof(struct Node));

    head->data = 7;
    head->next = sec;

    sec->data = 11;
    sec->next = third;

    third->data = 41;
    third->next = fourth;

    fourth->data = 66;
    fourth->next = fifth;

    fifth->data = 44;
    fifth->next = NULL;

    // head=deleting_first_node(head);
    // linkedlistTraversal(head);
    // linkedlistTraversal(head);
    // cout << "Before deletion" << endl;

    // delete_with_value(head, 66);
    // linkedlistTraversal(head);
    cout << "1. delete first" << endl
         << "2. delete at index" << endl
         << "3. delete last" << endl
         << "4. delete a  value" << endl
         << "5. exit" << endl;
    int i;
    cin >> i;
    cout << "Before deletion" << endl;
    linkedlistdisplay(head);
    switch (i)
    {
    case 1 /* constant-expression */:
        head = deleting_first_node(head);
        cout << "after deletion" << endl;
        linkedlistdisplay(head);
        /* code */
        break;
    case 2 /* constant-expression */:
        int index;
        cout << "Enter index" << endl;
        cin >> index;
        head=deleting_atindex(head, index);
        cout << "after deletion" << endl;
        linkedlistdisplay(head);
        /* code */
        break;
    case 3 /* constant-expression */:
        deleteing_last(head);
        cout << "after deletion" << endl;
        linkedlistdisplay(head);
        /* code */
        break;
    case 4 /* constant-expression */:
        int value;

        cout << "Enter value u want to delete" << endl;
        cin >> value;
        delete_with_value(head, value);
        cout << "after deletion" << endl;
        linkedlistdisplay(head);
        /* code */
        break;

    case 5:
        exit(1);
    }

    return 0;
}