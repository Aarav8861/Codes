#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;
    Node(int data)
    {
        this->data = data;
        this->next = NULL;
    }
};

Node *takeInput(Node *head)
{
    int data;
    cin >> data;
    Node *tail = NULL;
    while (data != -1)
    {
        Node *newNode = new Node(data);
        if (head == NULL)
        {
            head = newNode;
            tail = head;
        }
        else
        {
            tail->next = newNode;
            tail = newNode;
        }
        cin >> data;
    }
    tail->next = head;
    return head;
}
Node *deletion(Node *head, int i)
{
    if (i == 0)
    {
        Node *temp = head;
        while (temp->next != head)
        {
            temp = temp->next;
        }
        temp->next = head->next;
        head = head->next;
        return head;
    }
    int count = 0;
    Node *temp = head;
    Node *prev = NULL;
    while (temp->next != NULL && count < i - 1)
    {
        prev = temp;
        temp = temp->next;
        count++;
    }
    if (temp->next == head)
    {
        prev->next = head;
        return head;
    }
    Node *a = temp->next;
    temp->next = temp->next->next;
    delete a;
    return head;
}

void print(Node *head)
{
    Node *temp = head;
    while (temp->next != head)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << temp->data << endl;
}

int main()
{
    Node *head = NULL;
    head = takeInput(head);
    print(head);
    int i, data;
    cin >> i;
    head = deletion(head, i);
    print(head);
}