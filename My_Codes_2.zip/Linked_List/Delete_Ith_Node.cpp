#include <iostream>

using namespace std;

class Node
{
public:
    int data;
    Node *next;

    Node(int data)
    {
        this->data = data;
        this->next = NULL;
    }
};

void print(Node *head)
{
    Node *temp = head;
    while (temp != NULL)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}
Node *input(Node *head)
{
    int data;
    cin >> data;
    Node *tail = NULL;
    while (data != -1)
    {
        Node *newNode = new Node(data);
        if (head == NULL)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail->next = newNode;
            tail = newNode;
        }
        cin >> data;
    }
    return head;
}
Node *deletion(Node *head, int i)
{
    Node *temp = head;
    int count = 0;
    if (head == NULL)
    {
        return head;
    }
    if (i == 0)
    {
        head = head->next;
        return head;
    }
    while (temp != NULL && count < i - 1)
    {
        temp = temp->next;
        count++;
    }
    if (temp == NULL || temp->next == NULL)
    {
        return head;
    }
    Node *a = temp->next;
    temp->next = temp->next->next;
    delete a;
    return head;
}
int main()
{
    Node *head = NULL;
    head = input(head);
    print(head);
    int i;
    cin >> i;
    head = deletion(head, i);
    print(head);

    return 0;
}