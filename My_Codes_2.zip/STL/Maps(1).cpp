#include <iostream>
#include <string>
#include <map>
using namespace std;

// Map is an assosciative array...
int main()
{
    map <string,int> maps;
    maps["Aarav"]=100;
    maps["Rohit"]=56;
    maps["Rohan"]=84;

    maps.insert({{"kaju",85},{"barfi",75}});

    cout<<maps.empty()<<endl; 
    cout<<maps.size()<<endl;

    map<string,int> :: iterator itr;
    for(itr=maps.begin();itr!=maps.end();itr++)
    {
        cout<<(*itr).first<<" "<<(*itr).second<<" "<<endl;
    }
    return 0;

}