#include <iostream>
#include <list>
using namespace std;

void display( list <int> &v)
{
      list <int> :: iterator iter;
    iter=v.begin();
    for(int i=0;i<v.size();i++)
    {
    cout<<*iter<<" ";
    iter++;
    }cout<<endl;
}
int main()
{
    list <int> list1; //list of 0 Length
    list1.push_back(5);
    list1.push_back(9);
    list1.push_back(11);
    list1.push_back(2);
    list1.push_back(7);
    display(list1);



    //removing elements from the list
    //list1.remove(5);
    //list1.pop_front();
    //list1.pop_back();

    
    list1.sort();
    list <int> list2(3); //Empty list of size 3
    list <int> :: iterator iter;
    iter=list2.begin();
    *iter=45;
    iter++;
    *iter=6;
    iter++;
    *iter=8;
    iter++;
    display(list2);
    list2.sort();
    list1.merge(list2);
    display(list1);

    return 0;                       
    
}

