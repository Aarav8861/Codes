#include <bits/stdc++.h>
using namespace std;


void allindexes(vector<int> v,int n,vector<int> &ans,int i)
{
    if(i>=v.size())
    {
        return;
    }
    if(v[i] == n)
    {
        ans.push_back(i);
    }
    allindexes(v,n,ans,i+1);
    return;
}

int main()
{
    vector<int> v = {1,2,4,2,3,5,4,3,3,2,7,6,2,6,4,2};
    vector<int> ans;
    allindexes(v,2,ans,0);
    for(auto i:ans)
    {
        cout << i << " " ;
    }
    cout << endl;
    return 0;
}