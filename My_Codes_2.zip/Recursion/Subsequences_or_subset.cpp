#include <iostream>
using namespace std;

void substring(string str, string ans = "")
{
    if (str.length() == 0)
    {
        cout << ans << endl;
        return;
    }

    char ch = str[0];
    string rem = str.substr(1);
    substring(rem, ans);
    substring(rem, ans + ch);
}
int main()
{
    string str;
    cin >> str;
    substring(str);
    cout << endl;
    return 0;
}


