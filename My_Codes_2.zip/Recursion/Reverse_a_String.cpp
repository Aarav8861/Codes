#include <iostream>

using namespace std;
#include <string>

string reverse(string str)
{
    if (str.length() == 0)
        return "";

    string rem = reverse(str.substr(1));
    cout << str[0];
}
int main()
{
    string str;
    cin >> str;
    reverse(str);
    return 0;
}