#include <iostream>
using namespace std;
string remove(string str)
{
    if (str.length() == 0)
    {
        return "";
    }
    char ch = str[0];
    string rem = remove(str.substr(1));
    if (ch == rem[0])
        return rem;
    else
    {
        return (ch + rem);
    }
}

int main()
{
    string str;
    cin >> str;
    cout << remove(str);
    return 0;
}