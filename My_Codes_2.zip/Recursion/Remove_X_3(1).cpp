#include <iostream>
using namespace std;

int length(char s[])
{
    if(s[0]=='\0')
    {
        return 0;
    }
    int ans=length(s+1);
    return 1+ans;
}
void removeX(char s[])
{
    if(s[0]=='\0')
    {
        return ;
    }
    if(s[0]=='x')
    {
        for(int i=0;s[i]!='\0';i++)
        {
            s[i]=s[i+1];
        }
        removeX(s);
    }
    else
    {
        removeX(s+1);
    }
}

int main()
{
    char s[100];
    cin>>s;
    cout<<length(s)<<endl;
    removeX(s);
    cout<<s<<endl;
    cout<<length(s)<<endl;
}