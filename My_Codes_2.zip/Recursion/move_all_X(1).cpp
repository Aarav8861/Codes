#include <iostream>

using namespace std;

string moveallx(string str)
{
    if(str.length()==0)
    return 0;
    

    char ch=str[0];
    string rem=moveallx(str.substr(1));

    if(str[0]=='x')
    return (rem+ch);

    else 
    return (ch+rem);
}

int main()
{
    string str;
    cin>>str;
    cout<<moveallx(str);
    return 0;
}