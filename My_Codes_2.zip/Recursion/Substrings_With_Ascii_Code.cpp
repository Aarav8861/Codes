#include <iostream>
using namespace std;

void ascii(string str, string ans = "")
{
    if (str.length() == 0)
    {
        cout << ans << endl;
        return;
    }

    char ch = str[0];
    string rem = str.substr(1);
    int code = ch;

    ascii(rem, ans);
    ascii(rem, ans + ch);
    ascii(rem, ans + to_string(code));
}

int main()
{
    string str;
    cin >> str;
    ascii(str);
    return 0;
}