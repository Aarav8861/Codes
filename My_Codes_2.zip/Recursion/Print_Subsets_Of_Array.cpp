#include <iostream>
using namespace std;
void helper(int input[], int n,int si,int output[],int m) {
	// Write your code here
    if(si==n)
    {
        for(int i=0;i<m;i++)
        {
            cout<<output[i]<<" ";
        }
        cout<<endl;
        return;
    }
    int newoutput[100],i;
        helper(input,n,si+1,output,m);
    for(i=0;i<m;i++)
    {
        newoutput[i]=output[i];
    }
    
    newoutput[i]=input[si];
    helper(input,n,si+1,newoutput,m+1);
     
}

void printSubsetsOfArray(int input[], int size) {
	// Write your code here
    int output[100];
    helper(input,size,0,output,0);
}

int main() {
  int input[1000],length;
  cin >> length;
  for(int i=0; i < length; i++)
  	cin >> input[i];
  printSubsetsOfArray(input, length);
}
