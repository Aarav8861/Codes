#include <iostream>
using namespace std;

int length(char input[])
{
    int count=0;
    for(int i=0;input[i]!='\0';i++)
    {
        count++;
    }
    return count;
}
void helper(char input[],int start)
{
    if(input[start] == '\0')
    {
        return;
    }
    
    helper(input,start+1);
    int len=length(input);
    if(input[start]=='x')
    {
     int i;
        for(i=start;i<len;i++)
        {
            input[i]=input[i+1];
        }
        input[i-1]='\0';
    }
}

void removeX(char input[]) {
    
    helper(input,0);
}


int main() {
    char input[100];
    cin.getline(input, 100);
    removeX(input);
    cout << input << endl;
}
