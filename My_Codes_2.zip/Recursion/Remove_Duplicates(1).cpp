
#include <iostream>
using namespace std;
void removeDuplicates(char *input) {
    if(input[1]=='\0')
    {
        return;
    }
        for(int i=1;input[i]!='\0';i++)
        {
            if(input[0]==input[i] && input[i]!=input[i+1])
            {
                for(int j=i;input[j]!='\0';j++)
                {
                    input[j]=input[j+1];
                }
            }
            else if(input[0]==input[i] && input[i]==input[i+1])
            {
                for(int j=i;input[j]!='\0';j++)
                {
                    input[j]=input[j+1];
                }
                i--;
            }
        }
        removeDuplicates(input+1);

}

int main() {
    char s[100000];
    cin >> s;
    removeDuplicates(s);
    cout << s << endl;
}