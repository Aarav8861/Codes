#include <iostream>
using namespace std;

int length(char input[])
{
    int count = 0;
    for (int i = 0; input[i] != '\0'; i++)
    {
        count++;
    }
    return count;
}
int stringToNumber(char input[], int last)
{
    if (last == 0)
        return input[last] - '0';

    int ans = stringToNumber(input, last - 1);
    int b = input[last] - '0';
    return ans * 10 + b;
}
int stringToNumber(char input[])
{
    // Write your code here
    int len = length(input);
    return stringToNumber(input, len - 1);
}

int main()
{
    char input[50];
    cin >> input;
    cout << stringToNumber(input) << endl;