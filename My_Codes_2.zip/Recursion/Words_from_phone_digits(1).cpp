#include <iostream>
using namespace std;

string keypad[]={"","","abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};

void phonewords(string str,string ans="")
{
    if(str.length()==0)
    {
        cout<<ans<<endl;
        return;
    }

    char ch=str[0];
    string code=keypad[ch-'0'];
    string rem=str.substr(1);

    phonewords(rem,ans);

    for(int i=0;i<code.length();i++)
    {
        phonewords(rem,ans+code[i]);
    }

}
int main()
{
    string str;
    cin>>str;
    phonewords(str);
    return 0;
}