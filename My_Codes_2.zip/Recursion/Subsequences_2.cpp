#include <iostream>
using namespace std;


int size(string str,string output[])
{
    if(str.size()==0)
    {
        output[0]="";
        return 1;
    }

    string smallstring = str.substr(1);
    int ans = size(smallstring,output);
    for(int i=0;i<ans;i++)
    {
        output[i+ans]=str[0]+output[i];
    }
    return 2*ans;
}

int main ()
{
    string str;
    cin>>str;
    string output[100];
    int count = size(str,output);
    for(int i=0;i<count;i++)
    {
        cout<<output[i]<<endl;
    }
}