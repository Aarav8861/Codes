#include <iostream>
using namespace std;
#include <math.h>
int length(char input[])
{
    int count = 0;
    for (int i = 0; input[i] != '\0'; i++)
    {
        count++;
    }
    return count;
}
int stringToNumber(char input[], int start)
{
    int len = length(input);
    if (input[start + 1] == '\0')
        return input[start] - '0';

    int ans = stringToNumber(input, start + 1);
    int b = input[start] - '0';
    return ans + b * pow(10, len - start - 1);
}
int stringToNumber(char input[])
{
    // Write your code here
    return stringToNumber(input, 0);
}

int main()
{
    char input[50];
    cin >> input;
    cout << stringToNumber(input) << endl;
}
