#include <iostream>
using namespace std;
#include <climits>

int knapsack(int n,int val[],int wt[],int W)
{
    if(n==0 || W==0)
    return 0;

    if(wt[n-1]>W)
    return knapsack(n-1,val,wt,W);
   
    return max(knapsack(n-1,val,wt,W-wt[n-1]) + val[n-1], knapsack(n-1,val,wt,W));
}
int main()
{
    int n,W;
       cin>>n>>W;
    int val[n];
    int wt[n];
 
      for(int i=0;i<n;i++)
    {
        cin>>val[i];
        cin>>wt[i];
    }
    cout<<knapsack(n,val,wt,W);
}