
#include <iostream>
using namespace std;

int length(char input[])
{
    int count = 0;
    for(int i =0 ; input[i]!='\0';i++)
    {
        count++;
    }
    return count;
}
void helper(char input[],int start)
{
    if(input[start+1] == '\0')
    {
        return ;
    }
    helper(input,start+1);
    int len = length(input);
    if(input[start]==input[start+1])
    {
        for(int i=len-1;i>start;i--)
        {
            input[i+1]=input[i];
        }
        input[start+1]='*';
        len++;
        input[len]='\0';
        
    }
}
void pairStar(char input[]) {
    // Write your code here
    helper(input,0);

}

int main() {
   char input[100];
   cin.getline(input, 100);
   pairStar(input);
   cout << input << endl;
}
