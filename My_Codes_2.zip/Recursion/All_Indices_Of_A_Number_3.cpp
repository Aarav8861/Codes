#include <bits/stdc++.h>
using namespace std;

int storeall(int arr[], int n, int i, int key, int out[], int j)
{
    if (i == n)
        return j;

    if (arr[i] == key)
    {
        out[j] = i;
        return storeall(arr, n, i + 1, key, out, j + 1);
    }
    else
    {
        return storeall(arr, n, i + 1, key, out, j);
    }
}

int main()
{
    int n;
    cin >> n;

    int *input = new int[n];

    for (int i = 0; i < n; i++)
    {
        cin >> input[i];
    }

    int x;

    cin >> x;

    int *output = new int[n];

    int size = storeall(input, n, 0, x, output, 0);
    for (int i = 0; i < size; i++)
    {
        cout << output[i] << " ";
    }

    delete[] input;

    delete[] output;
}