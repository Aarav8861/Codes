/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

bool sort(int arr[],int n)
{
      if(n==0 || n==1)
    {
        return true;
    }
    
    bool is_smaller_sorted=sort(arr+1,n-1);
    if(!is_smaller_sorted)
    return false;
    
    if(arr[0]<arr[1])
    {
        return true;
    }
    else
    return false;
}

#include <iostream>

using namespace std;

int main()
{
    int n;
    cin >> n;
    
    int *arr=new int [n];
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    cout<<sort(arr,n);
    return 0;
}
