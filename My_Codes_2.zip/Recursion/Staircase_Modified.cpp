#include <iostream>
using namespace std;
int staircase(int n, int k)
{
    if (n < 0)
    {
        return 0;
    }
    if (n == 0)
    {
        return 1;
    }
    int ans = 0;
    for (int i = 1; i <= k; i++)
    {
        ans += staircase(n - i, k);
    }
    return ans;
}

int main()
{
    int n, k, output;
    cin >> n >> k;
    output = staircase(n, k);
    cout << output << endl;
}
