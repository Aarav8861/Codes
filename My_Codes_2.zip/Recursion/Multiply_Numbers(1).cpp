int multiplyNumbers(int m, int n) {
    // Write your code here
    if(n==0)
    {
        return 0;
    }
    int ans=multiplyNumbers(m,n-1); //Assume it works
    return (ans+m);
}


#include <iostream>
using namespace std;

int main() {
    int m, n;
    cin >> m >> n;
    cout << multiplyNumbers(m, n) << endl;
}
