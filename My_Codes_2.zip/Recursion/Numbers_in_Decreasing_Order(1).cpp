#include <iostream>
using namespace std;

void dorder(int n)
{
    if(n==0)
    return;
    cout<<n<<" ";
    dorder(n-1);
}
int main()
{
    int n;
    cin>>n;
    dorder(n);
    return 0;
}