
/*#include <iostream>
using namespace std;
void removeConsecutiveDuplicates(char *input) {
    /* Don't write main().
    * Don't read input, it is passed as function argument.
    * Change in the given string itself.
    * No need to return or print anything
    * Taking input and printing output is handled automatically.
    */
/*if(input[1]=='\0')
{
    return;
}
if(input[0]==input[1])
{
    for(int i=1;input[i]!='\0';i++)
    {
        input[i]=input[i+1];
    }
    removeConsecutiveDuplicates(input);
}
else
{
    removeConsecutiveDuplicates(input+1);
}
}

int main() {
char s[100000];
cin >> s;
removeConsecutiveDuplicates(s);
cout << s << endl;
}*/
#include <bits/stdc++.h>
using namespace std;

void removeConsecutiveDuplicates(int *arr, int start, int n)
{
    if (start == n - 1)
    {
        return;
    }
    if (arr[start] == arr[start + 1])
    {
        for (int i = start + 1; i < n; i++)
        {
            arr[i] = arr[i + 1];
        }
        removeConsecutiveDuplicates(arr, start, n);
    }
    else
        removeConsecutiveDuplicates(arr, start + 1, n);
}

void removeDuplicates(int *arr, int n)
{
    removeConsecutiveDuplicates(arr, 0, n);
}

int main()
{
    int arr[] = {1, 2, 2, 3, 4, 5, 5, 4};
    int n = sizeof(arr) / sizeof(int);
    removeDuplicates(arr, n);

    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
}