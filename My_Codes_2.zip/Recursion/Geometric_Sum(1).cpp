
#include <iostream>
#include <math.h>
#include <iomanip>
double geometricSum(int k) {
    // Write your code here
    
    if(k==0)
    {
        return 1;
    }
    double sum=geometricSum(k-1); //Assume it will bring
    return (1/pow(2,k))+sum;
}

using namespace std;

int main() {
    int k;
    cin >> k;
    cout << fixed << setprecision(5);
    cout << geometricSum(k) << endl;   
}
