#include <iostream>
#include <string>
using namespace std;

string getstring(int num)
{
    if(num==2)
        return "abc";
    if(num==3)
        return "def";
    if(num==4)
        return "ghi";
    if(num==5)
        return "jkl";
    if(num==6)
        return "mno";
    if(num==7)
        return "pqrs";
    if(num==8)
        return "tuv";
    if(num==9)
        return "wxyz";
    return "";
}
void Keypad(int num,string output){
    /*
    Given an integer number print all the possible combinations of the keypad. You do not need to return anything just print them.
    */
    if(num==0)
    {
        cout<<output<<endl;
        return;
    }
    int lastDigit=num%10;
    int SmallNumber=num/10;
    string options= getstring(lastDigit);
    for(int i=0;i<options.size();i++)
    {
      Keypad(SmallNumber,options[i]+output);
    }
}

int main(){
    int num;
    cin >> num;

    Keypad(num,"");

    return 0;
}
