#include <iostream>
using namespace std;

int friendspairing(int n)
{
    if (n == 0 || n == 1 || n == 2)
        return n;

    return (1 * friendspairing(n - 1)) + (friendspairing(n - 2) * (n - 1)); //
    // This means that the first person can go alone so he is chosen in 1 way * f(n-1) for others 
    // and other case is he can choose a pair in n-1C1 (P&c) ways * others go in n-2 ways.
}
int main()
{
    int n;
    cin >> n;
    cout << friendspairing(n);
    return 0;
}