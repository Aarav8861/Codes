#include <bits/stdc++.h>
using namespace std;

int stringtoint(string str, int n)
{
    if (n == 0)
        return 0;

    int a = str[n - 1] - '0';
    int ans = stringtoint(str, n - 1);
    return ans * 10 + a;
}

int main()
{
    string str;
    cin >> str;
    int n = str.length();
    cout << stringtoint(str, n) << endl;
}