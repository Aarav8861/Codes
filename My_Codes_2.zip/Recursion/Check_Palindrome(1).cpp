int length(char input[])
{
    int count = 0;
    for (int i = 0; input[i] != '\0'; i++)
    {
        count++;
    }
    return count;
}
bool helper(char input[], int start, int end)
{
    int count = length(input);
    if (start >= end)
    {
        return true;
    }
    if (input[start] != input[end])
    {
        return false;
    }
    else
    {
        return helper(input, start + 1, end - 1);
    }
}
bool checkPalindrome(char input[])
{
    // Write your code here
    int count = length(input);
    return helper(input, 0, count - 1);
}
#include <iostream>
using namespace std;

int main()
{
    char input[50];
    cin >> input;

    if (checkPalindrome(input))
    {
        cout << "true" << endl;
    }
    else
    {
        cout << "false" << endl;
    }
}
