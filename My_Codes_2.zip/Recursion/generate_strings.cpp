#include <iostream>
using namespace std;

void generate_string(char *inp, char *out, int i, int j)
{
    // base case
    if (inp[i] == '\0')
    {
        out[j] = '\0';
        cout << out << endl;
        return;
    }
    // recursion case
    // for one element
    if (inp[i] == '0')
    {
        return generate_string(inp, out, i + 1, j);
    }

    int digit = inp[i] - '0';
    char ch = digit + 'A' - 1;
    out[j] = ch;
    generate_string(inp, out, i + 1, j + 1);

    // for two elents at a time
    if (inp[i + 1] != '\0')
    {
        int second_no = inp[i + 1] - '0';
        int no = digit * 10 + second_no;
        if (no <= 26)
        {
            ch = no + 'A' - 1;
            out[j] = ch;
            generate_string(inp, out, i + 2, j + 1);
        }
    }
    return;
}

int main()
{
    char a[100];
    cin >> a;
    char out[100];
    generate_string(a, out, 0, 0);
    return 0;
}
