#include <bits/stdc++.h>
using namespace std;

char keypad[][10] = {"", ".+@$", "abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz"};

void phoneKeypad(char input[], char output[], int i, int j)
{
    if (input[i] == '\0')
    {
        output[j] = '\0';
        cout << output << "\n";
        return;
    }
    int digit = input[i] - '0';
    if (digit == 0)
    {
        phoneKeypad(input, output, i + 1, j);
    }

    for (int k = 0; keypad[digit][k] != '\0'; k++)
    {
        output[j] = keypad[digit][k];
        phoneKeypad(input, output, i + 1, j + 1);
    }
}

int main()
{
    char input[1000000], output[1000000];
    cin >> input;
    phoneKeypad(input, output, 0, 0);
    int n = sizeof(output) / sizeof(int);
    for (int i = 0; i < n; i++)
    {
        cout << output[i];
    }
}