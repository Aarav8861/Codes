#include <iostream>
using namespace std;

int iorder(int n)
{
    if(n==0)
    return 0;
    iorder(n-1);
    cout<<n<<" ";
}
int main()
{
    int n;
    cin>>n;
    iorder(n);
    return 0;
}