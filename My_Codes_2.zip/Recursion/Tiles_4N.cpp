// Question : Given a wall of size 4 * N Tiles of size 4 * 1 or 1 * 4 find the number of ways in which you can build the wall

#include <bits/stdc++.h>
using namespace std;

int wall(int n)
{
    if (n <= 3)
        return 1;
    return wall(n - 1) + wall(n - 4);
}

int main()
{
    int n;
    cin >> n;
    cout << wall(n) << endl;
}