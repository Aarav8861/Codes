#include <bits/stdc++.h>
using namespace std;

bool fibonacci(int arr[], int n)
{
    if (n == 0 || n == 1)
        return true;

    return (arr[n] > arr[n - 1] && fibonacci(arr - 1, n - 1));
}
int main()
{
    int n;
    cin >> n;
    int arr[n];
    for (int i = 0; i < n; i++)
        cin >> arr[i];

    cout << fibonacci(arr, n) << endl;
    return 0;
}
