#include<iostream>
using namespace std;

int main()
{
    int n;
    cin>>n;
    int sum=0;
    int a=1;
    int b=1;
    int c=0;
    if(n>=3){
    for(int i = 3;i<=n;i++)
    {
            c=a+b;
            a=b;
            b=c;
    }
        cout<<c;
    }
    else
    {
        cout<<"1";
    }
}
