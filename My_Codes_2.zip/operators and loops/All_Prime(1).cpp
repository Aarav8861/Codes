#include <iostream>
using namespace std;

int prime(int n)
{
    int i=2;
    while(i<=n)
    {
        int count=2;
        while(count<i){
        if(i%count==0)
        {
            i++;
            break;
        }
        else 
        {
            count++;
        }
        
        }
         if(count==i)
        {
            cout<<i<<endl;
             i++;
        }
    }
}


int main()
{
    int n;
    cin>>n;
    prime(n);
}
