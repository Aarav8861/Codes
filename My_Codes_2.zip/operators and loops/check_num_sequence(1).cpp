#include<iostream>
using namespace std;

int main()
{
 
    char n;
    int alpha=0,space=0,num=0;
  
    while(n!='$')
    {   
         if(n>='a' && n<='z'){
        alpha++;
    }
        else if(n>='0'&& n<='9'){   
        num++;
    }
        else if (n==' '|| n=='\n'||n=='\t')
    {
            space++;
        }
              n=cin.get();
    }
    cout<<alpha<<" "<<num<<" "<<space-1<<endl;
    
}