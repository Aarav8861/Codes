#include<iostream>
using namespace std;

int main() 

{
    int n;
    cin>>n;
    
    long long d=0;
    for( long i=1;n!=0;i=i*10)
    {
        int rem=n%10;
        d=d*10+rem;
        n=n/10;
    }
    cout<<d;
}
