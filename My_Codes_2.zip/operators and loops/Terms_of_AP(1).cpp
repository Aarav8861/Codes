#include<iostream>
using namespace std;

int main() 
{
    int x;
    cin>>x;
    
    for(int i=1;i<=x;i++)
    {
        int d=3*i+2;
        
        if(d%4==0)
        {
            x++;
        }
        
        else
        {
            cout<<d<<" ";
        }
    }
	
}
