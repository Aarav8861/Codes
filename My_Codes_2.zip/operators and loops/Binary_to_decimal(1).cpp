#include<iostream>
using namespace std;
#include <math.h>

int main() 
{
    int n;
    cin>>n;
    int ans=0;
    for( int pv=1;n!=0;pv=2*pv)
    {
        int d=n%10;
        ans+=d*pv;
        n=n/10;
    }
    cout<<ans;
    return 0;
}