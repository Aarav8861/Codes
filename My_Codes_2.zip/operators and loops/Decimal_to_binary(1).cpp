#include<iostream>
using namespace std;

int main() 
{
    int  n;
    cin>>n;
    long long ans=0;
    
    for(long pv=1;n!=0;pv=pv*10)
    {
        int rem=n%2;
        ans+=pv*rem;
        n=n/2;
    }
    cout<<ans;
}
