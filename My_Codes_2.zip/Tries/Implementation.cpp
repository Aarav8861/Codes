#include <iostream>
using namespace std;
#include "Trie.h"

int main()
{
    Trie T;
    T.insertWord("and");
    T.insertWord("are");
    T.insertWord("dot");

    cout << T.search("and") << endl;

    T.removeWord("and");
    cout << T.search("and") << endl;
}