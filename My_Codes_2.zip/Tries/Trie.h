#include "TrieNode.h"
#include <string>

class Trie
{
    TrieNode *root;

public:
    Trie()
    {
        root = new TrieNode('\0');
    }

private:
    void insertWord(TrieNode *root, string word)
    {
        if (word.length() == 0)
        {
            root->IsTerminal = true;
            return;
        }

        int index = word[0] - 'a';
        TrieNode *child;
        if (root->children[index] != NULL)
        {
            child = root->children[index];
        }
        else
        {
            child = new TrieNode(word[0]);
            root->children[index] = child;
        }
        insertWord(child, word.substr(1));
    }
    bool search(TrieNode *root, string word)
    {
        if (root->children[word[0] - 'a'] == NULL)
            return false;

        if (word.size() == 1)
        {
            return root->children[word[0] - 'a']->IsTerminal;
        }

        return search(root->children[word[0] - 'a'], word.substr(1));
    }
    void removeWord(TrieNode *root, string word)
    {
        if (word.length() == 0)
        {
            root->IsTerminal = false;
        }
        int index = word[0] - 'a';
        TrieNode *child;
        if (root->children[index] != NULL)
        {
            child = root->children[index];
        }
        else
        {
            return;
        }
        removeWord(child, word.substr(1));

        //Remove child node if it is useless
        if (child->IsTerminal == false)
        {
            for (int i = 0; i < 26; i++)
            {
                if (child->children[i] != NULL)
                {
                    return;
                }
            }
            delete child;
            root->children[index] = NULL;
        }
    }

public:
    bool search(string word)
    {
        return search(root, word);
    }
    void insertWord(string word)
    {
        insertWord(root, word);
    }
    void removeWord(string word)
    {
        removeWord(root, word);
    }
};
